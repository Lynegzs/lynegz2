# ♻️ ATRAPA Y RECICLA

**Juego Educativo de Clasificación de Residuos con Visión Artificial, Control por Gestos de Mano y Música 100% Libre de Derechos**

---

## 📋 Descripción

**Atrapa y Recicla** es una aplicación web interactiva y educativa diseñada para enseñar la correcta separación en la fuente de residuos sólidos. El juego utiliza **visión por computadora en tiempo real** mediante **MediaPipe Hands** y la cámara web del dispositivo para convertir la mano del jugador en un cursor virtual con detección del gesto de pinza (🤏) para atrapar, desplazar y depositar los residuos en sus respectivos contenedores. Cuenta además con un sintetizador de música procedural en tiempo real **100% libre de derechos de autor (royalty-free)**.

---

## 🎮 Mecánica de Juego

1. **Cámara Obligatoria**: El juego requiere acceso a la cámara web para procesar el movimiento de la mano. No se transmiten ni graban imágenes (100% privacidad local).
2. **Calibración Guiada**:
   - Detección de mano.
   - Movimiento horizontal (izquierda a derecha).
   - Movimiento vertical (arriba a abajo).
   - Verificación de gesto de pinza con confirmación visual.
3. **Control por Gestos**:
   - **Mano abierta (🖐️)**: Mover el cursor virtual sobre la pantalla.
   - **Pinza pulgar + índice (🤏)**: Agarrar el residuo actual.
   - **Arrastrar**: Desplazar el residuo hacia el contenedor correspondiente.
   - **Soltar (🖐️)**: Abrir los dedos para depositar el residuo.
4. **Límites Físicos y Clamping**:
   - El residuo y el cursor están estrictamente confinados mediante una función matemática de límite (`limitarResiduo`), teniendo en cuenta el ancho y alto real del objeto. Es imposible que el residuo salga del área visible o desaparezca.
5. **Detección de Entrega y Puntuación**:
   - Si se suelta sobre el contenedor correcto: **+1 Punto**, sonido armónico mayor.
   - Si se suelta sobre el contenedor incorrecto: **+1 Error**, sonido de advertencia y explicación educativa.
   - Si se suelta fuera de cualquier contenedor: El residuo regresa suavemente al centro sin penalización ni error.
   - **Protección contra doble respuesta**: Cada ronda procesa un único resultado garantizado.
   - **10 Rondas** con selección aleatoria no repetitiva.

---

## 🗑️ Categorías y Residuos Oficiales

| Contenedor | Tipo | Residuos Incluidos |
|---|---|---|
| 🟢 **Verde** | Orgánicos | 🍌 Cáscara de banana, 🍎 Manzana mordida, 🍽️ Restos de comida |
| 🔵 **Azul** | Reciclables | 🧴 Botella de plástico, 🥫 Lata, 🍾 Botella de vidrio, 📦 Caja de cartón, 📰 Periódico |
| ⚫ **Gris** | No aprovechables | 🧻 Servilleta usada, 🪟 Vidrio roto |
| 🔴 **Rojo** | Peligrosos | 🔋 Pila, 💉 Jeringa |

---

## 🚀 Ejecución Local

Dado que la API `navigator.mediaDevices.getUserMedia` requiere un contexto seguro (`localhost` o `https://`), el juego no puede ejecutarse directamente desde `file:///`.

### Opción 1: Servidor Vite (Recomendado)
```bash
# Instalar dependencias
npm install

# Iniciar servidor de desarrollo
npm run dev
```
Abre en tu navegador:
`http://localhost:3000`

### Opción 2: Servidor Python HTTP (Para archivos estáticos / dist)
```bash
# Construir archivos estáticos
npm run build

# Iniciar servidor estático
cd dist
python -m http.server 8000
```
Abre en tu navegador:
`http://localhost:8000`

---

## 🛠️ Tecnologías Empleadas

- **React 19 + TypeScript**: Arquitectura modular orientada a componentes.
- **Vite 6**: Empaquetado optimizado de alto rendimiento.
- **Tailwind CSS v4**: Estilos utilitarios y diseño adaptativo.
- **MediaPipe Hands / Camera Utils**: Red neuronal convolucional en navegador para detección de 21 landmarks de la mano a 30+ FPS.
- **Web Audio API**: Sintetizador de sonido procedural libre de dependencias externas.
