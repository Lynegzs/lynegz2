/**
 * Core type definitions for Atrapa y Recicla
 */

export type GameState = 
  | 'MENU' 
  | 'CAMARA' 
  | 'CALIBRACION' 
  | 'JUGANDO' 
  | 'RESULTADO' 
  | 'FINAL';

export type GameMode = 'levels' | 'infinite';

export type WasteCategory = 'verde' | 'azul' | 'gris' | 'rojo';

export interface WasteItem {
  id: number;
  nombre: string;
  categoria: WasteCategory;
  emoji: string;
  descripcion?: string;
}

export interface CategoryInfo {
  id: WasteCategory;
  nombre: string;
  etiqueta: string;
  descripcion: string;
  colorHex: string;
  bgTailwind: string;
  borderTailwind: string;
  badgeTailwind: string;
  tipo: string;
}

export interface HandLandmark {
  x: number;
  y: number;
  z: number;
}

export interface HandDetectionData {
  detected: boolean;
  rawX: number;
  rawY: number;
  smoothX: number;
  smoothY: number;
  isPinching: boolean;
  pinchDistance: number;
  landmarks: HandLandmark[] | null;
  confidence: number;
}

export interface BoundingBox {
  left: number;
  top: number;
  right: number;
  bottom: number;
  width: number;
  height: number;
}

export interface RoundResult {
  round: number;
  item: WasteItem;
  chosenCategory: WasteCategory;
  isCorrect: boolean;
  explanation?: string;
}

export interface GameLevel {
  levelNumber: number;
  title: string;
  subtitle: string;
  difficulty: 'Muy Fácil' | 'Fácil' | 'Media' | 'Media-Alta' | 'Intermedia' | 'Avanzada' | 'Experto' | 'Muy Difícil' | 'Maestro' | 'Leyenda';
  description: string;
  items: WasteItem[];
}

export type MedalTier = 'bronze' | 'silver' | 'gold' | 'diamond';

export interface Medal {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  icon: string;
  tier: MedalTier;
  tierLabel: string;
  accentColor: string;
  borderColor: string;
  bgGradient: string;
  targetValue?: number;
  statKey?: keyof UserStats;
  unit?: string;
  category?: 'hito' | 'racha' | 'maestria' | 'especial';
  unlockedAt?: string;
}

export interface UserStats {
  totalCorrect: number;
  bestStreak: number;
  currentStreak: number;
  totalGames: number;
  totalLevelsCleared: number;
  cleanSheetLevels: number;
  toxicWasteSorted: number;
  fastestSortSeconds: number;
  totalScore: number;
  unlockedMedalIds: string[];
  unlockedDates: Record<string, string>;
  bestInfiniteScore?: number;
  bestInfiniteStreak?: number;
  totalInfiniteSorted?: number;
}
