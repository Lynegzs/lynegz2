/**
 * Streak multiplier system:
 * Rewards consecutive correct sorting without errors with scaled point multipliers.
 */

export interface StreakTierInfo {
  streak: number;
  multiplier: number;
  nextTierStreak: number | null;
  itemsToNextTier: number;
  pointsForNextItem: number;
  label: string;
}

/**
 * Calculates point multiplier based on current consecutive correct streak
 * - 0 to 1: 1.0x (10 pts)
 * - 2: 1.5x (15 pts)
 * - 3: 2.0x (20 pts)
 * - 4: 2.5x (25 pts)
 * - 5 to 7: 3.0x (30 pts)
 * - 8 to 9: 4.0x (40 pts)
 * - 10+: 5.0x (50 pts - MAX RACHA)
 */
export function calculateStreakMultiplier(streak: number): number {
  if (streak >= 10) return 5.0;
  if (streak >= 8) return 4.0;
  if (streak >= 5) return 3.0;
  if (streak >= 4) return 2.5;
  if (streak >= 3) return 2.0;
  if (streak >= 2) return 1.5;
  return 1.0;
}

export function getStreakTierInfo(streak: number): StreakTierInfo {
  const multiplier = calculateStreakMultiplier(streak);
  let nextTierStreak: number | null = null;
  let label = 'Normal';

  if (streak < 2) {
    nextTierStreak = 2;
    label = 'Inicio';
  } else if (streak < 3) {
    nextTierStreak = 3;
    label = '¡En racha!';
  } else if (streak < 4) {
    nextTierStreak = 4;
    label = '¡Racha doble!';
  } else if (streak < 5) {
    nextTierStreak = 5;
    label = '¡Imparable!';
  } else if (streak < 8) {
    nextTierStreak = 8;
    label = '¡Super racha!';
  } else if (streak < 10) {
    nextTierStreak = 10;
    label = '¡Mega racha!';
  } else {
    nextTierStreak = null;
    label = '¡Racha legendaria!';
  }

  const itemsToNextTier = nextTierStreak !== null ? Math.max(0, nextTierStreak - streak) : 0;
  const pointsForNextItem = Math.round(10 * calculateStreakMultiplier(streak + 1));

  return {
    streak,
    multiplier,
    nextTierStreak,
    itemsToNextTier,
    pointsForNextItem,
    label
  };
}
