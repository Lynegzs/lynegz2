/**
 * MediaPipe Hands integration & Real-time Gesture Engine
 * Robust, concurrency-locked, and single-stream architecture.
 */

export interface DualHandData {
  p1: {
    detected: boolean;
    normX: number; // 0..1 relative to Player 1's left viewport
    normY: number; // 0..1
    isPinching: boolean;
    pinchDistance: number;
  };
  p2: {
    detected: boolean;
    normX: number; // 0..1 relative to Player 2's right viewport
    normY: number; // 0..1
    isPinching: boolean;
    pinchDistance: number;
  };
}

export interface HandTrackerCallbacks {
  onHandUpdate: (data: {
    detected: boolean;
    normX: number; // 0..1 (mirrored for natural movement)
    normY: number; // 0..1
    isPinching: boolean;
    pinchDistance: number;
    landmarks: Array<{ x: number; y: number; z: number }> | null;
  }) => void;
  onDualHandUpdate?: (data: DualHandData) => void;
  onError?: (err: Error) => void;
  onStatusUpdate?: (status: { cameraReady: boolean; modelLoading: boolean; error?: string }) => void;
}

const MEDIAPIPE_HANDS_VERSION = '0.4.1675469240';

export class HandTracker {
  private videoElement: HTMLVideoElement | null = null;
  private canvasElement: HTMLCanvasElement | null = null;
  private handsInstance: any = null;
  private isRunning: boolean = false;
  private isProcessingFrame: boolean = false;
  private animationFrameId: number | null = null;
  private callbacks: HandTrackerCallbacks | null = null;

  // Smoothing states (Single Player)
  private smoothedX: number = 0.5;
  private smoothedY: number = 0.5;
  private lastDetected: boolean = false;
  private wasPinching: boolean = false;
  private consecutiveMissingFrames: number = 0;

  // Dual Player states
  private isDualMode: boolean = false;
  private p1SmoothedX: number = 0.5;
  private p1SmoothedY: number = 0.5;
  private p1WasPinching: boolean = false;
  private p1MissingFrames: number = 0;

  private p2SmoothedX: number = 0.5;
  private p2SmoothedY: number = 0.5;
  private p2WasPinching: boolean = false;
  private p2MissingFrames: number = 0;

  // Thresholds
  private pinchStartThreshold: number = 0.085;
  private pinchReleaseThreshold: number = 0.11;

  // Facing mode: 'user' for front/selfie camera, 'environment' for rear camera
  private currentFacingMode: 'user' | 'environment' = 'user';

  constructor() {}

  public async initialize(
    video: HTMLVideoElement,
    canvas: HTMLCanvasElement | null,
    callbacks: HandTrackerCallbacks
  ): Promise<boolean> {
    this.videoElement = video;
    this.canvasElement = canvas;
    this.callbacks = callbacks;

    // 1. Check browser mediaDevices support
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      throw new Error('Tu navegador no soporta acceso a la cámara web mediante getUserMedia.');
    }

    try {
      // 2. Request webcam stream FIRST so the live image appears on screen immediately
      if (!this.videoElement.srcObject) {
        let stream: MediaStream | null = null;
        try {
          stream = await navigator.mediaDevices.getUserMedia({
            video: {
              width: { ideal: 1280 },
              height: { ideal: 720 },
              frameRate: { ideal: 60, min: 30 },
              facingMode: this.currentFacingMode
            },
            audio: false
          });
        } catch (constraintErr) {
          console.warn('Constraint getUserMedia failed, attempting fallback { video: true }:', constraintErr);
          stream = await navigator.mediaDevices.getUserMedia({
            video: true,
            audio: false
          });
        }

        this.videoElement.srcObject = stream;
      }

      // Ensure video is properly configured for inline autoplay without browser blocking
      this.videoElement.muted = true;
      (this.videoElement as any).defaultMuted = true;
      this.videoElement.playsInline = true;
      this.videoElement.setAttribute('playsinline', 'true');
      this.videoElement.setAttribute('webkit-playsinline', 'true');
      this.videoElement.setAttribute('muted', '');
      this.videoElement.setAttribute('autoplay', '');

      try {
        await this.videoElement.play();
      } catch (playErr) {
        console.warn('Initial video.play() deferred, waiting for loaded metadata:', playErr);
      }

      // Wait until video has valid dimensions or times out smoothly
      await this.waitForVideoReady(this.videoElement);

      if (this.canvasElement && this.videoElement.videoWidth > 0) {
        this.canvasElement.width = this.videoElement.videoWidth;
        this.canvasElement.height = this.videoElement.videoHeight;
      }

      this.callbacks?.onStatusUpdate?.({ cameraReady: true, modelLoading: true });

      // 3. Wait for MediaPipe scripts loaded from CDN
      await this.waitForMediaPipe();

      const win = window as any;
      if (!win.Hands) {
        throw new Error('No se pudo cargar la librería MediaPipe Hands.');
      }

      // Defensive initialization of data download container to prevent undefined property errors
      if (!win.createMediapipeSolutionsPackedAssets) {
        win.createMediapipeSolutionsPackedAssets = { dataFileDownloads: {} };
      } else if (!win.createMediapipeSolutionsPackedAssets.dataFileDownloads) {
        win.createMediapipeSolutionsPackedAssets.dataFileDownloads = {};
      }

      // 4. Initialize or reuse Hands singleton
      if (!this.handsInstance) {
        this.handsInstance = new win.Hands({
          locateFile: (file: string) =>
            `https://cdn.jsdelivr.net/npm/@mediapipe/hands@${MEDIAPIPE_HANDS_VERSION}/${file}`
        });

        this.handsInstance.setOptions({
          maxNumHands: this.isDualMode ? 2 : 1,
          modelComplexity: 1,
          minDetectionConfidence: 0.5,
          minTrackingConfidence: 0.5
        });

        this.handsInstance.onResults((results: any) => {
          this.processResults(results);
        });

        // Explicitly initialize WASM and packed models before sending frames
        if (typeof this.handsInstance.initialize === 'function') {
          await this.handsInstance.initialize();
        }
      }

      this.callbacks?.onStatusUpdate?.({ cameraReady: true, modelLoading: false });

      // 5. Start self-governed animation frame loop with strict concurrency locking
      this.isRunning = true;
      this.startProcessingLoop();

      return true;
    } catch (err: any) {
      this.callbacks?.onStatusUpdate?.({ cameraReady: false, modelLoading: false, error: err.message });
      if (this.callbacks?.onError) {
        this.callbacks.onError(err);
      }
      throw err;
    }
  }

  private drawVideoBackground: boolean = false;

  public setCanvas(canvas: HTMLCanvasElement | null) {
    this.canvasElement = canvas;
    if (this.canvasElement && this.videoElement && this.videoElement.videoWidth > 0) {
      this.canvasElement.width = this.videoElement.videoWidth;
      this.canvasElement.height = this.videoElement.videoHeight;
    }
  }

  public setDrawVideoBackground(enabled: boolean) {
    this.drawVideoBackground = enabled;
  }

  public setDualHandMode(enabled: boolean) {
    this.isDualMode = enabled;
    if (this.handsInstance) {
      try {
        this.handsInstance.setOptions({
          maxNumHands: enabled ? 2 : 1,
          modelComplexity: 1,
          minDetectionConfidence: 0.5,
          minTrackingConfidence: 0.5
        });
      } catch (e) {
        console.warn('Error setting dual hand mode options:', e);
      }
    }
  }

  public getFacingMode(): 'user' | 'environment' {
    return this.currentFacingMode;
  }

  public async switchCamera(): Promise<'user' | 'environment'> {
    this.currentFacingMode = this.currentFacingMode === 'user' ? 'environment' : 'user';
    if (this.videoElement && this.videoElement.srcObject) {
      const stream = this.videoElement.srcObject as MediaStream;
      stream.getTracks().forEach((track) => track.stop());
      this.videoElement.srcObject = null;
    }
    let newStream: MediaStream | null = null;
    try {
      newStream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 1280 },
          height: { ideal: 720 },
          frameRate: { ideal: 60, min: 30 },
          facingMode: this.currentFacingMode
        },
        audio: false
      });
    } catch (e) {
      console.warn('Fallback switch camera constraint to { video: true }', e);
      newStream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: false
      });
    }

    if (this.videoElement) {
      this.videoElement.srcObject = newStream;
      this.videoElement.muted = true;
      (this.videoElement as any).defaultMuted = true;
      this.videoElement.playsInline = true;
      try {
        await this.videoElement.play();
      } catch (err) {
        console.warn('Switch camera play deferred:', err);
      }
      await this.waitForVideoReady(this.videoElement);
      if (this.canvasElement && this.videoElement.videoWidth > 0) {
        this.canvasElement.width = this.videoElement.videoWidth;
        this.canvasElement.height = this.videoElement.videoHeight;
      }
    }
    return this.currentFacingMode;
  }

  private waitForVideoReady(video: HTMLVideoElement, timeoutMs = 8000): Promise<void> {
    return new Promise((resolve, reject) => {
      if (video.readyState >= 2 && video.videoWidth > 0 && video.videoHeight > 0) {
        resolve();
        return;
      }

      const timer = setTimeout(() => {
        cleanup();
        // Resolve anyway to attempt continuing if frames arrive late
        resolve();
      }, timeoutMs);

      const onLoaded = () => {
        if (video.videoWidth > 0 && video.videoHeight > 0) {
          cleanup();
          resolve();
        }
      };

      const cleanup = () => {
        clearTimeout(timer);
        video.removeEventListener('loadeddata', onLoaded);
        video.removeEventListener('canplay', onLoaded);
      };

      video.addEventListener('loadeddata', onLoaded);
      video.addEventListener('canplay', onLoaded);
    });
  }

  private startProcessingLoop() {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }

    const frameTick = async () => {
      if (!this.isRunning) return;

      if (
        this.videoElement &&
        this.videoElement.readyState >= 2 &&
        !this.videoElement.paused &&
        this.videoElement.videoWidth > 0 &&
        this.handsInstance &&
        !this.isProcessingFrame
      ) {
        this.isProcessingFrame = true;
        try {
          await this.handsInstance.send({ image: this.videoElement });
        } catch (err) {
          // Log transient frame error without crashing application
          console.warn('MediaPipe send frame error:', err);
        } finally {
          this.isProcessingFrame = false;
        }
      }

      if (this.isRunning) {
        this.animationFrameId = requestAnimationFrame(frameTick);
      }
    };

    this.animationFrameId = requestAnimationFrame(frameTick);
  }

  private async waitForMediaPipe(maxWaitMs = 12000): Promise<void> {
    const startTime = Date.now();
    while (Date.now() - startTime < maxWaitMs) {
      const win = window as any;
      if (win.Hands) return;
      await new Promise((r) => setTimeout(r, 100));
    }
    throw new Error('Tiempo de espera agotado al descargar los modelos de visión de MediaPipe.');
  }

  private processResults(results: any) {
    const rawHands = results.multiHandLandmarks || [];
    const hasHand = rawHands.length > 0;

    // Draw on active canvas (video + landmark skeleton)
    this.drawLandmarksOnCanvas(results);

    // 1. DUAL PLAYER HAND TRACKING
    if (this.isDualMode && this.callbacks?.onDualHandUpdate) {
      const handsInfo = rawHands.map((landmarks: any) => {
        const thumb = landmarks[4];
        const index = landmarks[8];
        const midX = (thumb.x + index.x) / 2;
        const midY = (thumb.y + index.y) / 2;
        const screenX = this.currentFacingMode === 'user' ? 1 - midX : midX;

        const dx = thumb.x - index.x;
        const dy = thumb.y - index.y;
        const dz = (thumb.z - index.z) * 0.6;
        const pinchDist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        return { landmarks, midX, midY, screenX, pinchDist };
      });

      let h1: any = null;
      let h2: any = null;

      if (handsInfo.length === 1) {
        if (handsInfo[0].screenX < 0.5) {
          h1 = handsInfo[0];
        } else {
          h2 = handsInfo[0];
        }
      } else if (handsInfo.length >= 2) {
        // Sort leftmost to rightmost (player 1 on left, player 2 on right)
        handsInfo.sort((a: any, b: any) => a.screenX - b.screenX);
        h1 = handsInfo[0];
        h2 = handsInfo[1];
      }

      // Player 1
      let p1Detected = !!h1;
      if (h1) {
        this.p1MissingFrames = 0;
        const targetX = Math.max(0, Math.min(1, h1.screenX / 0.5));
        const targetY = Math.max(0, Math.min(1, h1.midY));
        this.p1SmoothedX = this.p1SmoothedX * 0.65 + targetX * 0.35;
        this.p1SmoothedY = this.p1SmoothedY * 0.65 + targetY * 0.35;

        if (this.p1WasPinching) {
          if (h1.pinchDist > this.pinchReleaseThreshold) this.p1WasPinching = false;
        } else {
          if (h1.pinchDist < this.pinchStartThreshold) this.p1WasPinching = true;
        }
      } else {
        this.p1MissingFrames++;
        if (this.p1MissingFrames > 3) {
          p1Detected = false;
          this.p1WasPinching = false;
        } else {
          p1Detected = true;
        }
      }

      // Player 2
      let p2Detected = !!h2;
      if (h2) {
        this.p2MissingFrames = 0;
        const targetX = Math.max(0, Math.min(1, (h2.screenX - 0.5) / 0.5));
        const targetY = Math.max(0, Math.min(1, h2.midY));
        this.p2SmoothedX = this.p2SmoothedX * 0.65 + targetX * 0.35;
        this.p2SmoothedY = this.p2SmoothedY * 0.65 + targetY * 0.35;

        if (this.p2WasPinching) {
          if (h2.pinchDist > this.pinchReleaseThreshold) this.p2WasPinching = false;
        } else {
          if (h2.pinchDist < this.pinchStartThreshold) this.p2WasPinching = true;
        }
      } else {
        this.p2MissingFrames++;
        if (this.p2MissingFrames > 3) {
          p2Detected = false;
          this.p2WasPinching = false;
        } else {
          p2Detected = true;
        }
      }

      this.callbacks.onDualHandUpdate({
        p1: {
          detected: p1Detected,
          normX: Math.max(0, Math.min(1, this.p1SmoothedX)),
          normY: Math.max(0, Math.min(1, this.p1SmoothedY)),
          isPinching: this.p1WasPinching,
          pinchDistance: h1 ? h1.pinchDist : 1.0
        },
        p2: {
          detected: p2Detected,
          normX: Math.max(0, Math.min(1, this.p2SmoothedX)),
          normY: Math.max(0, Math.min(1, this.p2SmoothedY)),
          isPinching: this.p2WasPinching,
          pinchDistance: h2 ? h2.pinchDist : 1.0
        }
      });
      return;
    }

    // 2. SINGLE PLAYER HAND TRACKING
    if (!hasHand) {
      this.consecutiveMissingFrames++;
      // Allow 3 grace frames before dropping detection to prevent momentary flickers
      if (this.consecutiveMissingFrames > 3) {
        this.lastDetected = false;
        this.wasPinching = false;
        this.callbacks?.onHandUpdate({
          detected: false,
          normX: this.smoothedX,
          normY: this.smoothedY,
          isPinching: false,
          pinchDistance: 1.0,
          landmarks: null
        });
      }
      return;
    }

    this.consecutiveMissingFrames = 0;
    const landmarks = results.multiHandLandmarks[0];

    // Landmark 4: Thumb tip, Landmark 8: Index finger tip
    const thumb = landmarks[4];
    const index = landmarks[8];
    // Midpoint between thumb and index finger tip for precise interaction
    const midX = (thumb.x + index.x) / 2;
    const midY = (thumb.y + index.y) / 2;

    // Mirror horizontal axis only when using front 'user' selfie camera
    const rawTargetX = this.currentFacingMode === 'user' ? 1 - midX : midX;
    const rawTargetY = midY;

    // Movement smoothing formula from specs: cursorX = cursorX * 0.65 + newX * 0.35
    this.smoothedX = this.smoothedX * 0.65 + rawTargetX * 0.35;
    this.smoothedY = this.smoothedY * 0.65 + rawTargetY * 0.35;

    // Calculate pinch distance in 2D/3D normalized space
    const dx = thumb.x - index.x;
    const dy = thumb.y - index.y;
    const dz = (thumb.z - index.z) * 0.6;
    const pinchDistance = Math.sqrt(dx * dx + dy * dy + dz * dz);

    // Hysteresis for stable pinch detection (prevents fluttering)
    let isPinching = this.wasPinching;
    if (isPinching) {
      if (pinchDistance > this.pinchReleaseThreshold) {
        isPinching = false;
      }
    } else {
      if (pinchDistance < this.pinchStartThreshold) {
        isPinching = true;
      }
    }
    this.wasPinching = isPinching;
    this.lastDetected = true;

    this.callbacks?.onHandUpdate({
      detected: true,
      normX: Math.max(0, Math.min(1, this.smoothedX)),
      normY: Math.max(0, Math.min(1, this.smoothedY)),
      isPinching,
      pinchDistance,
      landmarks
    });
  }

  private drawLandmarksOnCanvas(results: any) {
    if (!this.canvasElement) return;
    const ctx = this.canvasElement.getContext('2d');
    if (!ctx) return;

    const w = this.canvasElement.width;
    const h = this.canvasElement.height;

    ctx.save();
    ctx.clearRect(0, 0, w, h);

    // Mirror horizontally so the canvas acts as a live mirror
    ctx.save();
    ctx.translate(w, 0);
    ctx.scale(-1, 1);

    // 1. Draw live webcam frame if requested
    if (this.drawVideoBackground && this.videoElement && this.videoElement.readyState >= 2) {
      try {
        ctx.drawImage(this.videoElement, 0, 0, w, h);
      } catch {}
    }

    // 2. Draw Center divider if in dual mode
    if (this.isDualMode) {
      ctx.save();
      ctx.setLineDash([8, 8]);
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(w / 2, 0);
      ctx.lineTo(w / 2, h);
      ctx.stroke();
      ctx.restore();
    }

    // 3. Draw landmarks and connectors on top
    const hands = results.multiHandLandmarks || [];
    const win = window as any;

    hands.forEach((landmarks: any) => {
      const thumb = landmarks[4];
      const index = landmarks[8];
      const midX = (thumb.x + index.x) / 2;
      // In mirrored space, screenX:
      const screenX = this.currentFacingMode === 'user' ? 1 - midX : midX;
      const isPlayer1 = this.isDualMode ? screenX < 0.5 : true;

      const connectorColor = isPlayer1 ? '#38bdf8' : '#f97316';
      const landmarkColor = isPlayer1 ? '#10b981' : '#fbbf24';
      const pinchColor = isPlayer1 ? '#22c55e' : '#ec4899';

      if (win.drawConnectors && win.HAND_CONNECTIONS) {
        win.drawConnectors(ctx, landmarks, win.HAND_CONNECTIONS, {
          color: connectorColor,
          lineWidth: 2.2
        });
        win.drawLandmarks(ctx, landmarks, {
          color: landmarkColor,
          lineWidth: 1.5,
          radius: 3.2
        });
      } else {
        // Fallback connector drawing
        ctx.strokeStyle = connectorColor;
        ctx.lineWidth = 2;
        ctx.fillStyle = landmarkColor;

        for (let i = 0; i < landmarks.length; i++) {
          const pt = landmarks[i];
          ctx.beginPath();
          ctx.arc(pt.x * w, pt.y * h, 3, 0, 2 * Math.PI);
          ctx.fill();
        }
      }

      // Highlight pinch connection (thumb tip to index tip)
      if (thumb && index) {
        const dx = thumb.x - index.x;
        const dy = thumb.y - index.y;
        const dz = (thumb.z - index.z) * 0.6;
        const pinchDistance = Math.sqrt(dx * dx + dy * dy + dz * dz);
        const isCurrentlyPinching = pinchDistance < this.pinchStartThreshold;

        ctx.beginPath();
        ctx.moveTo(thumb.x * w, thumb.y * h);
        ctx.lineTo(index.x * w, index.y * h);
        ctx.strokeStyle = isCurrentlyPinching ? pinchColor : 'rgba(244, 63, 94, 0.7)';
        ctx.lineWidth = isCurrentlyPinching ? 4 : 2;
        ctx.stroke();

        // Midpoint pinch indicator dot
        const midPointX = ((thumb.x + index.x) / 2) * w;
        const midPointY = ((thumb.y + index.y) / 2) * h;
        ctx.beginPath();
        ctx.arc(midPointX, midPointY, isCurrentlyPinching ? 7 : 4, 0, 2 * Math.PI);
        ctx.fillStyle = isCurrentlyPinching ? pinchColor : 'rgba(244, 63, 94, 0.85)';
        ctx.fill();
      }
    });

    ctx.restore(); // Restore mirrored coordinates
    ctx.restore(); // Restore canvas context
  }

  public setPinchSensitivity(threshold: number) {
    this.pinchStartThreshold = threshold;
    this.pinchReleaseThreshold = threshold + 0.025;
  }

  public pause() {
    this.isRunning = false;
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
  }

  public resume() {
    if (!this.isRunning && this.videoElement && this.handsInstance) {
      this.isRunning = true;
      this.startProcessingLoop();
    }
  }

  public stop() {
    this.isRunning = false;
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
    if (this.videoElement && this.videoElement.srcObject) {
      try {
        const stream = this.videoElement.srcObject as MediaStream;
        stream.getTracks().forEach((track) => track.stop());
      } catch {}
      this.videoElement.srcObject = null;
    }
  }
}
