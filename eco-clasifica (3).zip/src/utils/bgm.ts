/**
 * Procedural Royalty-Free Background Music Synthesizer (BGM)
 * 100% libre de derechos de autor y sin dependencias externas.
 * Generado en tiempo real con Web Audio API.
 * 
 * Incluye 10 canciones únicas (1 por cada nivel) y un motor inteligente para
 * el Modo Infinito con reproducción aleatoria sin repetición consecutiva.
 */

export type BgmTrackId =
  | 'level_1'
  | 'level_2'
  | 'level_3'
  | 'level_4'
  | 'level_5'
  | 'level_6'
  | 'level_7'
  | 'level_8'
  | 'level_9'
  | 'level_10';

export interface BgmTrackInfo {
  id: BgmTrackId;
  level: number;
  name: string;
  emoji: string;
  bpm: number;
  description: string;
  style: string;
}

export const BGM_TRACKS: BgmTrackInfo[] = [
  {
    id: 'level_1',
    level: 1,
    name: 'Aventura Ecológica',
    emoji: '🍃',
    bpm: 120,
    description: 'Melodía alegre, optimista y enérgica para comenzar el viaje de reciclaje.',
    style: 'Pop Acústico / Eco Adventure'
  },
  {
    id: 'level_2',
    level: 2,
    name: 'Ritmo Verde',
    emoji: '🌿',
    bpm: 104,
    description: 'Groove relajante con acordes suaves y ambiente distendido.',
    style: 'Chill Lo-Fi / Groove'
  },
  {
    id: 'level_3',
    level: 3,
    name: 'Electro Arcade',
    emoji: '🕹️',
    bpm: 130,
    description: 'Ritmo rápido estilo arcade retro 8-bits con arpegios brillantes.',
    style: 'Chiptune / Retro 8-Bit'
  },
  {
    id: 'level_4',
    level: 4,
    name: 'Mares Limpios',
    emoji: '🌊',
    bpm: 112,
    description: 'Compás playero y tropical que evoca la pureza de los océanos.',
    style: 'Bossa Nova / Brisa Marina'
  },
  {
    id: 'level_5',
    level: 5,
    name: 'Bosque Mágico',
    emoji: '🌲',
    bpm: 116,
    description: 'Fantasía mística inspirada en los bosques antiguos y la naturaleza viva.',
    style: 'Celta / Fantasía Ambiental'
  },
  {
    id: 'level_6',
    level: 6,
    name: 'Planeta Funk',
    emoji: '🕺',
    bpm: 124,
    description: 'Bajo dinámico y percusión sincopada que llena de ritmo la pantalla.',
    style: 'Neo-Funk / Disco Groove'
  },
  {
    id: 'level_7',
    level: 7,
    name: 'Ciudad Solar',
    emoji: '☀️',
    bpm: 128,
    description: 'Ondas futuristas y sintetizadores de energía limpia y renovable.',
    style: 'Synthwave / Retro Futurista'
  },
  {
    id: 'level_8',
    level: 8,
    name: 'Mundo Cristal',
    emoji: '💎',
    bpm: 110,
    description: 'Campanas cristalinas y marimba etérea para máxima concentración.',
    style: 'Dream Pop / Ambient Melódico'
  },
  {
    id: 'level_9',
    level: 9,
    name: 'Viento Andino',
    emoji: '🏔️',
    bpm: 122,
    description: 'Escala pentatónica y flautas sintetizadas que soplan desde las cumbres.',
    style: 'Andina / Épica de Montaña'
  },
  {
    id: 'level_10',
    level: 10,
    name: 'Héroes del Reciclaje',
    emoji: '🏆',
    bpm: 134,
    description: 'Himno heroico culminante y victorioso para el nivel final.',
    style: 'Himno Triunfal / Clímax Épico'
  }
];

// Fórmulas matemáticas de frecuencias exactas (A4 = 440 Hz)
const SEMITONES: Record<string, number> = {
  'C': 0, 'C#': 1, 'Db': 1, 'D': 2, 'D#': 3, 'Eb': 3, 'E': 4,
  'F': 5, 'F#': 6, 'Gb': 6, 'G': 7, 'G#': 8, 'Ab': 8, 'A': 9,
  'A#': 10, 'Bb': 10, 'B': 11
};

const FREQ_CACHE: Record<string, number> = {};

function getNoteFrequency(note: string): number {
  if (FREQ_CACHE[note]) return FREQ_CACHE[note];
  const match = note.match(/^([A-G][#b]?)([0-8])$/);
  if (!match) return 440;
  const key = match[1];
  const octave = parseInt(match[2], 10);
  const semitone = SEMITONES[key] ?? 0;
  const midi = (octave + 1) * 12 + semitone;
  const freq = 440 * Math.pow(2, (midi - 69) / 12);
  FREQ_CACHE[note] = freq;
  return freq;
}

interface NoteEvent {
  note: string;
  step: number;     // 0 a 31 (2 compases de 16 semicorcheas)
  duration: number; // duración en pasos de semicorchea
  velocity?: number; // 0.0 a 1.0
}

interface TrackSequence {
  bpm: number;
  scaleType: 'sine' | 'triangle' | 'square';
  melody: NoteEvent[];
  bass: NoteEvent[];
  chords: { step: number; notes: string[]; duration: number }[];
  drums: { step: number; type: 'kick' | 'snare' | 'hihat' }[];
}

// 10 Pistas Musicales Procedurales Originales (Copyright-Free / 100% Royalty-Free)
const SEQUENCES: Record<BgmTrackId, TrackSequence> = {
  // PISTA 1: Aventura Ecológica (Pop Acústico C - G - Am - F)
  level_1: {
    bpm: 120,
    scaleType: 'triangle',
    melody: [
      { note: 'E4', step: 0, duration: 2, velocity: 0.22 },
      { note: 'G4', step: 2, duration: 2, velocity: 0.24 },
      { note: 'A4', step: 4, duration: 2, velocity: 0.26 },
      { note: 'C5', step: 6, duration: 4, velocity: 0.28 },
      { note: 'D5', step: 10, duration: 2, velocity: 0.25 },
      { note: 'C5', step: 12, duration: 4, velocity: 0.24 },
      { note: 'B4', step: 16, duration: 2, velocity: 0.22 },
      { note: 'D5', step: 18, duration: 2, velocity: 0.25 },
      { note: 'G4', step: 20, duration: 2, velocity: 0.22 },
      { note: 'A4', step: 22, duration: 4, velocity: 0.26 },
      { note: 'G4', step: 26, duration: 2, velocity: 0.23 },
      { note: 'E4', step: 28, duration: 4, velocity: 0.20 }
    ],
    bass: [
      { note: 'C2', step: 0, duration: 2, velocity: 0.35 },
      { note: 'C2', step: 2, duration: 2, velocity: 0.30 },
      { note: 'G2', step: 4, duration: 2, velocity: 0.32 },
      { note: 'C3', step: 6, duration: 2, velocity: 0.28 },
      { note: 'G2', step: 8, duration: 2, velocity: 0.35 },
      { note: 'G2', step: 10, duration: 2, velocity: 0.30 },
      { note: 'D3', step: 12, duration: 2, velocity: 0.32 },
      { note: 'G2', step: 14, duration: 2, velocity: 0.28 },
      { note: 'A2', step: 16, duration: 2, velocity: 0.35 },
      { note: 'A2', step: 18, duration: 2, velocity: 0.30 },
      { note: 'E3', step: 20, duration: 2, velocity: 0.32 },
      { note: 'A2', step: 22, duration: 2, velocity: 0.28 },
      { note: 'F2', step: 24, duration: 2, velocity: 0.35 },
      { note: 'F2', step: 26, duration: 2, velocity: 0.30 },
      { note: 'C3', step: 28, duration: 2, velocity: 0.32 },
      { note: 'G2', step: 30, duration: 2, velocity: 0.28 }
    ],
    chords: [
      { step: 0, notes: ['C4', 'E4', 'G4'], duration: 7 },
      { step: 8, notes: ['B3', 'D4', 'G4'], duration: 7 },
      { step: 16, notes: ['A3', 'C4', 'E4'], duration: 7 },
      { step: 24, notes: ['A3', 'C4', 'F4'], duration: 7 }
    ],
    drums: [
      { step: 0, type: 'kick' }, { step: 8, type: 'kick' }, { step: 16, type: 'kick' }, { step: 24, type: 'kick' },
      { step: 4, type: 'snare' }, { step: 12, type: 'snare' }, { step: 20, type: 'snare' }, { step: 28, type: 'snare' },
      { step: 2, type: 'hihat' }, { step: 6, type: 'hihat' }, { step: 10, type: 'hihat' }, { step: 14, type: 'hihat' },
      { step: 18, type: 'hihat' }, { step: 22, type: 'hihat' }, { step: 26, type: 'hihat' }, { step: 30, type: 'hihat' }
    ]
  },

  // PISTA 2: Ritmo Verde (Chill Lo-Fi Fmaj7 - Dm7 - Gm7 - C7)
  level_2: {
    bpm: 104,
    scaleType: 'sine',
    melody: [
      { note: 'A4', step: 0, duration: 3, velocity: 0.22 },
      { note: 'C5', step: 3, duration: 3, velocity: 0.24 },
      { note: 'E5', step: 6, duration: 4, velocity: 0.25 },
      { note: 'D5', step: 10, duration: 4, velocity: 0.20 },
      { note: 'F4', step: 16, duration: 3, velocity: 0.22 },
      { note: 'A4', step: 19, duration: 3, velocity: 0.23 },
      { note: 'G4', step: 22, duration: 4, velocity: 0.22 },
      { note: 'C5', step: 26, duration: 6, velocity: 0.25 }
    ],
    bass: [
      { note: 'F2', step: 0, duration: 4, velocity: 0.35 },
      { note: 'C3', step: 4, duration: 2, velocity: 0.28 },
      { note: 'F2', step: 6, duration: 2, velocity: 0.30 },
      { note: 'D2', step: 8, duration: 4, velocity: 0.35 },
      { note: 'A2', step: 12, duration: 2, velocity: 0.28 },
      { note: 'G2', step: 16, duration: 4, velocity: 0.35 },
      { note: 'D3', step: 20, duration: 2, velocity: 0.28 },
      { note: 'C2', step: 24, duration: 4, velocity: 0.35 },
      { note: 'G2', step: 28, duration: 4, velocity: 0.28 }
    ],
    chords: [
      { step: 0, notes: ['F3', 'A3', 'C4', 'E4'], duration: 7 },
      { step: 8, notes: ['D3', 'F3', 'A3', 'C4'], duration: 7 },
      { step: 16, notes: ['G3', 'Bb3', 'D4', 'F4'], duration: 7 },
      { step: 24, notes: ['C3', 'E3', 'G3', 'Bb3'], duration: 7 }
    ],
    drums: [
      { step: 0, type: 'kick' }, { step: 10, type: 'kick' }, { step: 16, type: 'kick' }, { step: 26, type: 'kick' },
      { step: 8, type: 'snare' }, { step: 24, type: 'snare' },
      { step: 4, type: 'hihat' }, { step: 12, type: 'hihat' }, { step: 20, type: 'hihat' }, { step: 28, type: 'hihat' }
    ]
  },

  // PISTA 3: Electro Arcade (Chiptune Em - C - Am - D)
  level_3: {
    bpm: 130,
    scaleType: 'square',
    melody: [
      { note: 'E4', step: 0, duration: 1, velocity: 0.18 },
      { note: 'G4', step: 1, duration: 1, velocity: 0.18 },
      { note: 'B4', step: 2, duration: 1, velocity: 0.20 },
      { note: 'E5', step: 3, duration: 2, velocity: 0.22 },
      { note: 'D5', step: 5, duration: 1, velocity: 0.19 },
      { note: 'B4', step: 6, duration: 2, velocity: 0.19 },
      { note: 'C5', step: 8, duration: 2, velocity: 0.20 },
      { note: 'A4', step: 10, duration: 2, velocity: 0.19 },
      { note: 'G4', step: 12, duration: 4, velocity: 0.21 },
      { note: 'A4', step: 16, duration: 1, velocity: 0.18 },
      { note: 'C5', step: 17, duration: 1, velocity: 0.18 },
      { note: 'E5', step: 18, duration: 2, velocity: 0.22 },
      { note: 'G5', step: 20, duration: 2, velocity: 0.24 },
      { note: 'F5', step: 22, duration: 2, velocity: 0.20 },
      { note: 'D5', step: 24, duration: 2, velocity: 0.19 },
      { note: 'B4', step: 26, duration: 2, velocity: 0.19 },
      { note: 'E5', step: 28, duration: 4, velocity: 0.22 }
    ],
    bass: [
      { note: 'E2', step: 0, duration: 2, velocity: 0.32 },
      { note: 'E2', step: 2, duration: 2, velocity: 0.25 },
      { note: 'B2', step: 4, duration: 2, velocity: 0.28 },
      { note: 'E2', step: 6, duration: 2, velocity: 0.25 },
      { note: 'C2', step: 8, duration: 2, velocity: 0.32 },
      { note: 'C2', step: 10, duration: 2, velocity: 0.25 },
      { note: 'G2', step: 12, duration: 2, velocity: 0.28 },
      { note: 'C2', step: 14, duration: 2, velocity: 0.25 },
      { note: 'A2', step: 16, duration: 2, velocity: 0.32 },
      { note: 'A2', step: 18, duration: 2, velocity: 0.25 },
      { note: 'E3', step: 20, duration: 2, velocity: 0.28 },
      { note: 'A2', step: 22, duration: 2, velocity: 0.25 },
      { note: 'D2', step: 24, duration: 2, velocity: 0.32 },
      { note: 'D2', step: 26, duration: 2, velocity: 0.25 },
      { note: 'A2', step: 28, duration: 2, velocity: 0.28 },
      { note: 'B2', step: 30, duration: 2, velocity: 0.28 }
    ],
    chords: [
      { step: 0, notes: ['E3', 'G3', 'B3'], duration: 7 },
      { step: 8, notes: ['C3', 'E3', 'G3'], duration: 7 },
      { step: 16, notes: ['A2', 'C3', 'E3'], duration: 7 },
      { step: 24, notes: ['D3', 'F#3', 'A3'], duration: 7 }
    ],
    drums: [
      { step: 0, type: 'kick' }, { step: 4, type: 'snare' }, { step: 8, type: 'kick' }, { step: 12, type: 'snare' },
      { step: 16, type: 'kick' }, { step: 20, type: 'snare' }, { step: 24, type: 'kick' }, { step: 28, type: 'snare' },
      { step: 2, type: 'hihat' }, { step: 6, type: 'hihat' }, { step: 10, type: 'hihat' }, { step: 14, type: 'hihat' },
      { step: 18, type: 'hihat' }, { step: 22, type: 'hihat' }, { step: 26, type: 'hihat' }, { step: 30, type: 'hihat' }
    ]
  },

  // PISTA 4: Mares Limpios (Bossa Nova / Brisa Marina Dmaj7 - Bm7 - Em7 - A7)
  level_4: {
    bpm: 112,
    scaleType: 'sine',
    melody: [
      { note: 'F#4', step: 0, duration: 3, velocity: 0.22 },
      { note: 'A4', step: 3, duration: 2, velocity: 0.23 },
      { note: 'D5', step: 5, duration: 3, velocity: 0.25 },
      { note: 'C#5', step: 8, duration: 4, velocity: 0.22 },
      { note: 'B4', step: 12, duration: 3, velocity: 0.20 },
      { note: 'F#4', step: 16, duration: 3, velocity: 0.22 },
      { note: 'G4', step: 19, duration: 2, velocity: 0.23 },
      { note: 'B4', step: 21, duration: 3, velocity: 0.24 },
      { note: 'A4', step: 24, duration: 4, velocity: 0.22 },
      { note: 'E5', step: 28, duration: 4, velocity: 0.24 }
    ],
    bass: [
      { note: 'D2', step: 0, duration: 4, velocity: 0.32 },
      { note: 'A2', step: 4, duration: 3, velocity: 0.28 },
      { note: 'B2', step: 8, duration: 4, velocity: 0.32 },
      { note: 'F#2', step: 12, duration: 3, velocity: 0.28 },
      { note: 'E2', step: 16, duration: 4, velocity: 0.32 },
      { note: 'B2', step: 20, duration: 3, velocity: 0.28 },
      { note: 'A2', step: 24, duration: 4, velocity: 0.32 },
      { note: 'E3', step: 28, duration: 3, velocity: 0.28 }
    ],
    chords: [
      { step: 0, notes: ['D3', 'F#3', 'A3', 'C#4'], duration: 7 },
      { step: 8, notes: ['B2', 'D3', 'F#3', 'A3'], duration: 7 },
      { step: 16, notes: ['E3', 'G3', 'B3', 'D4'], duration: 7 },
      { step: 24, notes: ['A2', 'C#3', 'E3', 'G3'], duration: 7 }
    ],
    drums: [
      { step: 0, type: 'kick' }, { step: 6, type: 'kick' }, { step: 16, type: 'kick' }, { step: 22, type: 'kick' },
      { step: 8, type: 'snare' }, { step: 24, type: 'snare' },
      { step: 2, type: 'hihat' }, { step: 4, type: 'hihat' }, { step: 10, type: 'hihat' }, { step: 14, type: 'hihat' },
      { step: 18, type: 'hihat' }, { step: 20, type: 'hihat' }, { step: 26, type: 'hihat' }, { step: 30, type: 'hihat' }
    ]
  },

  // PISTA 5: Bosque Mágico (Celta / Fantasía Ambiental Am - Em - F - G)
  level_5: {
    bpm: 116,
    scaleType: 'triangle',
    melody: [
      { note: 'A4', step: 0, duration: 2, velocity: 0.22 },
      { note: 'C5', step: 2, duration: 2, velocity: 0.24 },
      { note: 'B4', step: 4, duration: 2, velocity: 0.22 },
      { note: 'E5', step: 6, duration: 4, velocity: 0.26 },
      { note: 'D5', step: 10, duration: 2, velocity: 0.23 },
      { note: 'B4', step: 12, duration: 4, velocity: 0.21 },
      { note: 'C5', step: 16, duration: 2, velocity: 0.23 },
      { note: 'E5', step: 18, duration: 2, velocity: 0.25 },
      { note: 'F5', step: 20, duration: 4, velocity: 0.26 },
      { note: 'E5', step: 24, duration: 2, velocity: 0.24 },
      { note: 'D5', step: 26, duration: 2, velocity: 0.22 },
      { note: 'B4', step: 28, duration: 4, velocity: 0.20 }
    ],
    bass: [
      { note: 'A2', step: 0, duration: 4, velocity: 0.35 },
      { note: 'E3', step: 4, duration: 3, velocity: 0.28 },
      { note: 'E2', step: 8, duration: 4, velocity: 0.35 },
      { note: 'B2', step: 12, duration: 3, velocity: 0.28 },
      { note: 'F2', step: 16, duration: 4, velocity: 0.35 },
      { note: 'C3', step: 20, duration: 3, velocity: 0.28 },
      { note: 'G2', step: 24, duration: 4, velocity: 0.35 },
      { note: 'D3', step: 28, duration: 3, velocity: 0.28 }
    ],
    chords: [
      { step: 0, notes: ['A3', 'C4', 'E4'], duration: 7 },
      { step: 8, notes: ['G3', 'B3', 'E4'], duration: 7 },
      { step: 16, notes: ['A3', 'C4', 'F4'], duration: 7 },
      { step: 24, notes: ['B3', 'D4', 'G4'], duration: 7 }
    ],
    drums: [
      { step: 0, type: 'kick' }, { step: 8, type: 'kick' }, { step: 16, type: 'kick' }, { step: 24, type: 'kick' },
      { step: 4, type: 'snare' }, { step: 12, type: 'snare' }, { step: 20, type: 'snare' }, { step: 28, type: 'snare' },
      { step: 2, type: 'hihat' }, { step: 6, type: 'hihat' }, { step: 10, type: 'hihat' }, { step: 14, type: 'hihat' },
      { step: 18, type: 'hihat' }, { step: 22, type: 'hihat' }, { step: 26, type: 'hihat' }, { step: 30, type: 'hihat' }
    ]
  },

  // PISTA 6: Planeta Funk (Neo-Funk / Disco Groove Gm - Bb - C - Dm)
  level_6: {
    bpm: 124,
    scaleType: 'triangle',
    melody: [
      { note: 'G4', step: 0, duration: 2, velocity: 0.25 },
      { note: 'Bb4', step: 2, duration: 2, velocity: 0.26 },
      { note: 'D5', step: 4, duration: 3, velocity: 0.28 },
      { note: 'C5', step: 8, duration: 2, velocity: 0.24 },
      { note: 'Bb4', step: 10, duration: 2, velocity: 0.24 },
      { note: 'G4', step: 12, duration: 3, velocity: 0.22 },
      { note: 'F4', step: 16, duration: 2, velocity: 0.23 },
      { note: 'G4', step: 18, duration: 2, velocity: 0.26 },
      { note: 'Bb4', step: 20, duration: 2, velocity: 0.27 },
      { note: 'C5', step: 22, duration: 3, velocity: 0.28 },
      { note: 'D5', step: 26, duration: 4, velocity: 0.29 }
    ],
    bass: [
      { note: 'G2', step: 0, duration: 2, velocity: 0.38 },
      { note: 'G2', step: 3, duration: 2, velocity: 0.32 },
      { note: 'Bb2', step: 6, duration: 2, velocity: 0.34 },
      { note: 'Bb2', step: 8, duration: 2, velocity: 0.38 },
      { note: 'C3', step: 11, duration: 2, velocity: 0.32 },
      { note: 'D3', step: 14, duration: 2, velocity: 0.34 },
      { note: 'C2', step: 16, duration: 2, velocity: 0.38 },
      { note: 'E2', step: 19, duration: 2, velocity: 0.32 },
      { note: 'F2', step: 22, duration: 2, velocity: 0.34 },
      { note: 'D2', step: 24, duration: 2, velocity: 0.38 },
      { note: 'A2', step: 27, duration: 2, velocity: 0.32 },
      { note: 'D3', step: 30, duration: 2, velocity: 0.34 }
    ],
    chords: [
      { step: 0, notes: ['G3', 'Bb3', 'D4'], duration: 6 },
      { step: 8, notes: ['F3', 'Bb3', 'D4'], duration: 6 },
      { step: 16, notes: ['G3', 'C4', 'E4'], duration: 6 },
      { step: 24, notes: ['F3', 'A3', 'D4'], duration: 6 }
    ],
    drums: [
      { step: 0, type: 'kick' }, { step: 6, type: 'kick' }, { step: 10, type: 'kick' }, { step: 16, type: 'kick' }, { step: 22, type: 'kick' }, { step: 26, type: 'kick' },
      { step: 4, type: 'snare' }, { step: 12, type: 'snare' }, { step: 20, type: 'snare' }, { step: 28, type: 'snare' },
      { step: 2, type: 'hihat' }, { step: 6, type: 'hihat' }, { step: 8, type: 'hihat' }, { step: 10, type: 'hihat' },
      { step: 14, type: 'hihat' }, { step: 18, type: 'hihat' }, { step: 22, type: 'hihat' }, { step: 24, type: 'hihat' },
      { step: 26, type: 'hihat' }, { step: 30, type: 'hihat' }
    ]
  },

  // PISTA 7: Ciudad Solar (Synthwave / Retro Futurista Dm - Bb - F - C)
  level_7: {
    bpm: 128,
    scaleType: 'square',
    melody: [
      { note: 'D5', step: 0, duration: 3, velocity: 0.22 },
      { note: 'F5', step: 3, duration: 3, velocity: 0.24 },
      { note: 'E5', step: 6, duration: 2, velocity: 0.22 },
      { note: 'C5', step: 8, duration: 4, velocity: 0.23 },
      { note: 'A4', step: 12, duration: 4, velocity: 0.20 },
      { note: 'Bb4', step: 16, duration: 2, velocity: 0.22 },
      { note: 'D5', step: 18, duration: 2, velocity: 0.24 },
      { note: 'F5', step: 20, duration: 4, velocity: 0.26 },
      { note: 'G5', step: 24, duration: 4, velocity: 0.25 },
      { note: 'A5', step: 28, duration: 4, velocity: 0.27 }
    ],
    bass: [
      { note: 'D2', step: 0, duration: 2, velocity: 0.35 },
      { note: 'D2', step: 2, duration: 2, velocity: 0.30 },
      { note: 'A2', step: 4, duration: 2, velocity: 0.32 },
      { note: 'D3', step: 6, duration: 2, velocity: 0.30 },
      { note: 'Bb1', step: 8, duration: 2, velocity: 0.35 },
      { note: 'Bb1', step: 10, duration: 2, velocity: 0.30 },
      { note: 'F2', step: 12, duration: 2, velocity: 0.32 },
      { note: 'Bb2', step: 14, duration: 2, velocity: 0.30 },
      { note: 'F2', step: 16, duration: 2, velocity: 0.35 },
      { note: 'F2', step: 18, duration: 2, velocity: 0.30 },
      { note: 'C3', step: 20, duration: 2, velocity: 0.32 },
      { note: 'F2', step: 22, duration: 2, velocity: 0.30 },
      { note: 'C2', step: 24, duration: 2, velocity: 0.35 },
      { note: 'C2', step: 26, duration: 2, velocity: 0.30 },
      { note: 'G2', step: 28, duration: 2, velocity: 0.32 },
      { note: 'C3', step: 30, duration: 2, velocity: 0.30 }
    ],
    chords: [
      { step: 0, notes: ['D3', 'F3', 'A3'], duration: 7 },
      { step: 8, notes: ['D3', 'F3', 'Bb3'], duration: 7 },
      { step: 16, notes: ['C3', 'F3', 'A3'], duration: 7 },
      { step: 24, notes: ['C3', 'E3', 'G3'], duration: 7 }
    ],
    drums: [
      { step: 0, type: 'kick' }, { step: 8, type: 'kick' }, { step: 16, type: 'kick' }, { step: 24, type: 'kick' },
      { step: 4, type: 'snare' }, { step: 12, type: 'snare' }, { step: 20, type: 'snare' }, { step: 28, type: 'snare' },
      { step: 2, type: 'hihat' }, { step: 6, type: 'hihat' }, { step: 10, type: 'hihat' }, { step: 14, type: 'hihat' },
      { step: 18, type: 'hihat' }, { step: 22, type: 'hihat' }, { step: 26, type: 'hihat' }, { step: 30, type: 'hihat' }
    ]
  },

  // PISTA 8: Mundo Cristal (Dream Pop / Ambient Melódico E - B - C#m - A)
  level_8: {
    bpm: 110,
    scaleType: 'sine',
    melody: [
      { note: 'G#4', step: 0, duration: 2, velocity: 0.22 },
      { note: 'B4', step: 2, duration: 2, velocity: 0.24 },
      { note: 'E5', step: 4, duration: 4, velocity: 0.26 },
      { note: 'D#5', step: 8, duration: 4, velocity: 0.22 },
      { note: 'C#5', step: 12, duration: 4, velocity: 0.20 },
      { note: 'E5', step: 16, duration: 2, velocity: 0.23 },
      { note: 'G#5', step: 18, duration: 3, velocity: 0.26 },
      { note: 'F#5', step: 21, duration: 3, velocity: 0.23 },
      { note: 'E5', step: 24, duration: 4, velocity: 0.24 },
      { note: 'B4', step: 28, duration: 4, velocity: 0.21 }
    ],
    bass: [
      { note: 'E2', step: 0, duration: 4, velocity: 0.32 },
      { note: 'B2', step: 4, duration: 3, velocity: 0.28 },
      { note: 'B2', step: 8, duration: 4, velocity: 0.32 },
      { note: 'F#2', step: 12, duration: 3, velocity: 0.28 },
      { note: 'C#2', step: 16, duration: 4, velocity: 0.32 },
      { note: 'G#2', step: 20, duration: 3, velocity: 0.28 },
      { note: 'A2', step: 24, duration: 4, velocity: 0.32 },
      { note: 'E3', step: 28, duration: 3, velocity: 0.28 }
    ],
    chords: [
      { step: 0, notes: ['E3', 'G#3', 'B3'], duration: 7 },
      { step: 8, notes: ['D#3', 'F#3', 'B3'], duration: 7 },
      { step: 16, notes: ['E3', 'G#3', 'C#4'], duration: 7 },
      { step: 24, notes: ['E3', 'A3', 'C#4'], duration: 7 }
    ],
    drums: [
      { step: 0, type: 'kick' }, { step: 10, type: 'kick' }, { step: 16, type: 'kick' }, { step: 26, type: 'kick' },
      { step: 8, type: 'snare' }, { step: 24, type: 'snare' },
      { step: 4, type: 'hihat' }, { step: 12, type: 'hihat' }, { step: 20, type: 'hihat' }, { step: 28, type: 'hihat' }
    ]
  },

  // PISTA 9: Viento Andino (Andina Pentatónica Cm - Ab - Eb - Bb)
  level_9: {
    bpm: 122,
    scaleType: 'triangle',
    melody: [
      { note: 'C5', step: 0, duration: 2, velocity: 0.23 },
      { note: 'Eb5', step: 2, duration: 2, velocity: 0.25 },
      { note: 'F5', step: 4, duration: 2, velocity: 0.26 },
      { note: 'G5', step: 6, duration: 4, velocity: 0.28 },
      { note: 'Bb5', step: 10, duration: 2, velocity: 0.25 },
      { note: 'G5', step: 12, duration: 4, velocity: 0.24 },
      { note: 'F5', step: 16, duration: 2, velocity: 0.23 },
      { note: 'Eb5', step: 18, duration: 2, velocity: 0.23 },
      { note: 'C5', step: 20, duration: 4, velocity: 0.25 },
      { note: 'Bb4', step: 24, duration: 4, velocity: 0.22 },
      { note: 'C5', step: 28, duration: 4, velocity: 0.24 }
    ],
    bass: [
      { note: 'C2', step: 0, duration: 4, velocity: 0.35 },
      { note: 'G2', step: 4, duration: 3, velocity: 0.30 },
      { note: 'Ab2', step: 8, duration: 4, velocity: 0.35 },
      { note: 'Eb2', step: 12, duration: 3, velocity: 0.30 },
      { note: 'Eb2', step: 16, duration: 4, velocity: 0.35 },
      { note: 'Bb2', step: 20, duration: 3, velocity: 0.30 },
      { note: 'Bb1', step: 24, duration: 4, velocity: 0.35 },
      { note: 'F2', step: 28, duration: 3, velocity: 0.30 }
    ],
    chords: [
      { step: 0, notes: ['C3', 'Eb3', 'G3'], duration: 7 },
      { step: 8, notes: ['C3', 'Eb3', 'Ab3'], duration: 7 },
      { step: 16, notes: ['Bb2', 'Eb3', 'G3'], duration: 7 },
      { step: 24, notes: ['Bb2', 'D3', 'F3'], duration: 7 }
    ],
    drums: [
      { step: 0, type: 'kick' }, { step: 6, type: 'kick' }, { step: 12, type: 'kick' }, { step: 16, type: 'kick' }, { step: 22, type: 'kick' }, { step: 28, type: 'kick' },
      { step: 8, type: 'snare' }, { step: 24, type: 'snare' },
      { step: 2, type: 'hihat' }, { step: 4, type: 'hihat' }, { step: 10, type: 'hihat' }, { step: 14, type: 'hihat' },
      { step: 18, type: 'hihat' }, { step: 20, type: 'hihat' }, { step: 26, type: 'hihat' }, { step: 30, type: 'hihat' }
    ]
  },

  // PISTA 10: Héroes del Reciclaje (Himno Triunfal Clímax G - D - Em - C)
  level_10: {
    bpm: 134,
    scaleType: 'triangle',
    melody: [
      { note: 'D5', step: 0, duration: 2, velocity: 0.25 },
      { note: 'G5', step: 2, duration: 3, velocity: 0.28 },
      { note: 'A5', step: 5, duration: 1, velocity: 0.26 },
      { note: 'B5', step: 6, duration: 4, velocity: 0.30 },
      { note: 'A5', step: 10, duration: 2, velocity: 0.25 },
      { note: 'G5', step: 12, duration: 4, velocity: 0.26 },
      { note: 'F#5', step: 16, duration: 2, velocity: 0.24 },
      { note: 'G5', step: 18, duration: 2, velocity: 0.26 },
      { note: 'A5', step: 20, duration: 4, velocity: 0.28 },
      { note: 'B5', step: 24, duration: 2, velocity: 0.29 },
      { note: 'C6', step: 26, duration: 2, velocity: 0.30 },
      { note: 'B5', step: 28, duration: 4, velocity: 0.28 }
    ],
    bass: [
      { note: 'G2', step: 0, duration: 2, velocity: 0.38 },
      { note: 'G2', step: 2, duration: 2, velocity: 0.32 },
      { note: 'D3', step: 4, duration: 2, velocity: 0.35 },
      { note: 'G3', step: 6, duration: 2, velocity: 0.30 },
      { note: 'D2', step: 8, duration: 2, velocity: 0.38 },
      { note: 'D2', step: 10, duration: 2, velocity: 0.32 },
      { note: 'A2', step: 12, duration: 2, velocity: 0.35 },
      { note: 'D3', step: 14, duration: 2, velocity: 0.30 },
      { note: 'E2', step: 16, duration: 2, velocity: 0.38 },
      { note: 'E2', step: 18, duration: 2, velocity: 0.32 },
      { note: 'B2', step: 20, duration: 2, velocity: 0.35 },
      { note: 'E3', step: 22, duration: 2, velocity: 0.30 },
      { note: 'C2', step: 24, duration: 2, velocity: 0.38 },
      { note: 'C2', step: 26, duration: 2, velocity: 0.32 },
      { note: 'G2', step: 28, duration: 2, velocity: 0.35 },
      { note: 'C3', step: 30, duration: 2, velocity: 0.30 }
    ],
    chords: [
      { step: 0, notes: ['G3', 'B3', 'D4'], duration: 7 },
      { step: 8, notes: ['F#3', 'A3', 'D4'], duration: 7 },
      { step: 16, notes: ['G3', 'B3', 'E4'], duration: 7 },
      { step: 24, notes: ['G3', 'C4', 'E4'], duration: 7 }
    ],
    drums: [
      { step: 0, type: 'kick' }, { step: 8, type: 'kick' }, { step: 16, type: 'kick' }, { step: 24, type: 'kick' },
      { step: 4, type: 'snare' }, { step: 12, type: 'snare' }, { step: 20, type: 'snare' }, { step: 28, type: 'snare' },
      { step: 2, type: 'hihat' }, { step: 6, type: 'hihat' }, { step: 10, type: 'hihat' }, { step: 14, type: 'hihat' },
      { step: 18, type: 'hihat' }, { step: 22, type: 'hihat' }, { step: 26, type: 'hihat' }, { step: 30, type: 'hihat' }
    ]
  }
};

export class BgmEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private isPlaying: boolean = false;
  private currentTrackId: BgmTrackId = 'level_1';
  private volume: number = 0.25;
  private schedulerIntervalId: number | null = null;

  // Timing del scheduler
  private currentStep: number = 0;
  private nextStepTime: number = 0;
  private readonly lookaheadMs: number = 25;
  private readonly scheduleAheadSec: number = 0.12;

  // Ciclos de repetición de la frase musical (para avanzar canción en modo infinito)
  private currentLoopCount: number = 0;
  private readonly LOOPS_BEFORE_TRANSITION: number = 8; // ~32 a 40 segundos por canción

  // Modo Infinito: Cola aleatoria sin repetición consecutiva
  private isInfiniteMode: boolean = false;
  private infinitePlaylist: BgmTrackId[] = [];
  private lastPlayedTrackId: BgmTrackId | null = null;

  // Listeners para sincronización de UI en React
  private listeners: Set<() => void> = new Set();

  constructor() {
    if (typeof window !== 'undefined') {
      try {
        const savedVolume = localStorage.getItem('atrapa_bgm_volume');
        if (savedVolume !== null) {
          const parsed = parseFloat(savedVolume);
          if (!isNaN(parsed) && parsed >= 0 && parsed <= 1) {
            this.volume = parsed;
          }
        }
        const savedTrack = localStorage.getItem('atrapa_bgm_track') as BgmTrackId;
        if (savedTrack && SEQUENCES[savedTrack]) {
          this.currentTrackId = savedTrack;
        }
      } catch {
        // Ignorar fallas de localStorage
      }
    }
  }

  private initContext(): AudioContext | null {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
        this.masterGain = this.ctx.createGain();
        this.masterGain.gain.setValueAtTime(this.volume, this.ctx.currentTime);
        this.masterGain.connect(this.ctx.destination);
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify(): void {
    this.listeners.forEach((fn) => {
      try {
        fn();
      } catch {}
    });
  }

  public getIsPlaying(): boolean {
    return this.isPlaying;
  }

  public getIsInfiniteMode(): boolean {
    return this.isInfiniteMode;
  }

  public getCurrentTrack(): BgmTrackInfo {
    return BGM_TRACKS.find((t) => t.id === this.currentTrackId) || BGM_TRACKS[0];
  }

  public getVolume(): number {
    return this.volume;
  }

  public setVolume(vol: number): void {
    const clamped = Math.max(0, Math.min(1, vol));
    this.volume = clamped;
    if (this.ctx && this.masterGain) {
      this.masterGain.gain.setValueAtTime(clamped, this.ctx.currentTime);
    }
    try {
      localStorage.setItem('atrapa_bgm_volume', clamped.toString());
    } catch {}
    this.notify();
  }

  public setTrack(trackId: BgmTrackId, keepInfiniteState: boolean = false): void {
    if (!keepInfiniteState) {
      this.isInfiniteMode = false;
    }
    this.lastPlayedTrackId = this.currentTrackId;
    this.currentTrackId = trackId;
    this.currentLoopCount = 0;
    try {
      localStorage.setItem('atrapa_bgm_track', trackId);
    } catch {}

    if (this.isPlaying) {
      this.currentStep = 0;
      if (this.ctx) {
        this.nextStepTime = this.ctx.currentTime + 0.05;
      }
    }
    this.notify();
  }

  /**
   * Asigna y reproduce la canción correspondiente a un nivel específico (1 a 10).
   */
  public playTrackForLevel(levelNumber: number): void {
    const clampedLevel = Math.max(1, Math.min(10, levelNumber));
    const trackId: BgmTrackId = `level_${clampedLevel}` as BgmTrackId;
    this.isInfiniteMode = false;
    this.setTrack(trackId, true);
    if (!this.isPlaying) {
      this.play();
    }
  }

  /**
   * Inicia el Modo Infinito con reproducción aleatoria de las 10 canciones
   * garantizando que nunca se repita la misma canción consecutivamente.
   */
  public startInfiniteModeShuffle(): void {
    this.isInfiniteMode = true;
    this.generateInfinitePlaylist(this.currentTrackId);
    const nextTrack = this.infinitePlaylist.shift() || 'level_1';
    this.setTrack(nextTrack, true);
    if (!this.isPlaying) {
      this.play();
    }
  }

  /**
   * Genera una nueva tanda aleatoria con las 10 canciones (Fisher-Yates shuffle),
   * asegurando explícitamente que la primera canción elegida no sea la última que sonó.
   */
  private generateInfinitePlaylist(excludeLastId?: BgmTrackId | null): void {
    const allIds: BgmTrackId[] = BGM_TRACKS.map((t) => t.id);
    
    // Algoritmo Fisher-Yates de barajado aleatorio
    for (let i = allIds.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [allIds[i], allIds[j]] = [allIds[j], allIds[i]];
    }

    // Regla estricta: Si el primer elemento coincide con el anterior que acaba de sonar,
    // se intercambia con otro elemento más adelante en la lista
    if (excludeLastId && allIds[0] === excludeLastId && allIds.length > 1) {
      const swapIndex = 1 + Math.floor(Math.random() * (allIds.length - 1));
      [allIds[0], allIds[swapIndex]] = [allIds[swapIndex], allIds[0]];
    }

    this.infinitePlaylist = allIds;
  }

  /**
   * Salta a la siguiente canción aleatoria en Modo Infinito sin repetir la anterior.
   */
  public playNextInfiniteTrack(): void {
    if (this.infinitePlaylist.length === 0) {
      this.generateInfinitePlaylist(this.currentTrackId);
    }
    const nextTrack = this.infinitePlaylist.shift()!;
    this.setTrack(nextTrack, true);
  }

  public nextTrack(): void {
    if (this.isInfiniteMode) {
      this.playNextInfiniteTrack();
      return;
    }
    const idx = BGM_TRACKS.findIndex((t) => t.id === this.currentTrackId);
    const nextIdx = (idx + 1) % BGM_TRACKS.length;
    this.setTrack(BGM_TRACKS[nextIdx].id);
  }

  public async play(): Promise<void> {
    const ctx = this.initContext();
    if (!ctx) return;

    if (ctx.state === 'suspended') {
      try {
        await ctx.resume();
      } catch {
        return;
      }
    }

    if (this.isPlaying) return;

    this.isPlaying = true;
    this.currentStep = 0;
    this.currentLoopCount = 0;
    this.nextStepTime = ctx.currentTime + 0.05;

    if (typeof window !== 'undefined') {
      if (this.schedulerIntervalId !== null) {
        clearInterval(this.schedulerIntervalId);
      }
      this.schedulerIntervalId = window.setInterval(() => {
        this.scheduler();
      }, this.lookaheadMs);
    }

    this.notify();
  }

  public pause(): void {
    if (!this.isPlaying) return;
    this.isPlaying = false;
    if (this.schedulerIntervalId !== null) {
      clearInterval(this.schedulerIntervalId);
      this.schedulerIntervalId = null;
    }
    this.notify();
  }

  public toggle(): void {
    if (this.isPlaying) {
      this.pause();
    } else {
      this.play();
    }
  }

  // Scheduler central de Web Audio
  private scheduler(): void {
    if (!this.ctx || !this.masterGain || !this.isPlaying) return;

    const seq = SEQUENCES[this.currentTrackId] || SEQUENCES.level_1;
    const stepDuration = 60 / seq.bpm / 4;

    while (this.nextStepTime < this.ctx.currentTime + this.scheduleAheadSec) {
      this.scheduleStep(this.currentStep, this.nextStepTime, seq, stepDuration);
      this.nextStepTime += stepDuration;
      
      const nextStep = (this.currentStep + 1) % 32;
      
      // Fin de una frase de 32 pasos (2 compases)
      if (nextStep === 0) {
        this.currentLoopCount++;
        // En Modo Infinito: Al finalizar la canción (~8 frases completas), pasar a la siguiente
        if (this.isInfiniteMode && this.currentLoopCount >= this.LOOPS_BEFORE_TRANSITION) {
          this.currentLoopCount = 0;
          this.playNextInfiniteTrack();
          return;
        }
      }

      this.currentStep = nextStep;
    }
  }

  private scheduleStep(step: number, time: number, seq: TrackSequence, stepDuration: number): void {
    if (!this.ctx || !this.masterGain) return;

    // 1. Programar Batería / Percusión
    const drum = seq.drums.find((d) => d.step === step);
    if (drum) {
      if (drum.type === 'kick') {
        this.playSynthesizedKick(time);
      } else if (drum.type === 'snare') {
        this.playSynthesizedSnare(time);
      } else if (drum.type === 'hihat') {
        this.playSynthesizedHiHat(time);
      }
    }

    // 2. Programar Bajo
    const bassEvents = seq.bass.filter((b) => b.step === step);
    bassEvents.forEach((b) => {
      const freq = getNoteFrequency(b.note);
      if (freq) {
        this.playSynthesizedBass(freq, time, b.duration * stepDuration, b.velocity || 0.3);
      }
    });

    // 3. Programar Acordes
    const chord = seq.chords.find((c) => c.step === step);
    if (chord) {
      chord.notes.forEach((n) => {
        const freq = getNoteFrequency(n);
        if (freq) {
          this.playSynthesizedPad(freq, time, chord.duration * stepDuration, 0.12);
        }
      });
    }

    // 4. Programar Melodía Principal
    const melodyEvents = seq.melody.filter((m) => m.step === step);
    melodyEvents.forEach((m) => {
      const freq = getNoteFrequency(m.note);
      if (freq) {
        this.playSynthesizedLead(freq, time, m.duration * stepDuration, m.velocity || 0.22, seq.scaleType);
      }
    });
  }

  // --- Sintetizadores individuales nativos ---

  private playSynthesizedKick(time: number): void {
    if (!this.ctx || !this.masterGain) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(120, time);
      osc.frequency.exponentialRampToValueAtTime(38, time + 0.09);

      gain.gain.setValueAtTime(0.35, time);
      gain.gain.exponentialRampToValueAtTime(0.001, time + 0.1);

      osc.connect(gain);
      gain.connect(this.masterGain);

      osc.start(time);
      osc.stop(time + 0.11);
    } catch {}
  }

  private playSynthesizedSnare(time: number): void {
    if (!this.ctx || !this.masterGain) return;
    try {
      const bufferSize = Math.floor(this.ctx.sampleRate * 0.08);
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }

      const noise = this.ctx.createBufferSource();
      noise.buffer = buffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1400, time);
      filter.Q.setValueAtTime(1.2, time);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.2, time);
      gain.gain.exponentialRampToValueAtTime(0.001, time + 0.08);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);

      noise.start(time);
      noise.stop(time + 0.08);
    } catch {}
  }

  private playSynthesizedHiHat(time: number): void {
    if (!this.ctx || !this.masterGain) return;
    try {
      const bufferSize = Math.floor(this.ctx.sampleRate * 0.035);
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }

      const noise = this.ctx.createBufferSource();
      noise.buffer = buffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'highpass';
      filter.frequency.setValueAtTime(7500, time);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.12, time);
      gain.gain.exponentialRampToValueAtTime(0.001, time + 0.035);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);

      noise.start(time);
      noise.stop(time + 0.035);
    } catch {}
  }

  private playSynthesizedBass(freq: number, time: number, duration: number, vel: number): void {
    if (!this.ctx || !this.masterGain) return;
    try {
      const osc = this.ctx.createOscillator();
      const filter = this.ctx.createBiquadFilter();
      const gain = this.ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, time);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(320, time);
      filter.frequency.exponentialRampToValueAtTime(160, time + duration);

      gain.gain.setValueAtTime(0.001, time);
      gain.gain.linearRampToValueAtTime(vel, time + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, time + duration);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);

      osc.start(time);
      osc.stop(time + duration);
    } catch {}
  }

  private playSynthesizedPad(freq: number, time: number, duration: number, vel: number): void {
    if (!this.ctx || !this.masterGain) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, time);

      gain.gain.setValueAtTime(0.001, time);
      gain.gain.linearRampToValueAtTime(vel, time + 0.06);
      gain.gain.exponentialRampToValueAtTime(0.001, time + duration);

      osc.connect(gain);
      gain.connect(this.masterGain);

      osc.start(time);
      osc.stop(time + duration);
    } catch {}
  }

  private playSynthesizedLead(
    freq: number,
    time: number,
    duration: number,
    vel: number,
    type: 'sine' | 'triangle' | 'square'
  ): void {
    if (!this.ctx || !this.masterGain) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, time);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(type === 'square' ? 1800 : 2800, time);

      gain.gain.setValueAtTime(0.001, time);
      gain.gain.linearRampToValueAtTime(vel, time + 0.02);
      gain.gain.setValueAtTime(vel * 0.8, time + duration * 0.5);
      gain.gain.exponentialRampToValueAtTime(0.001, time + duration);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);

      osc.start(time);
      osc.stop(time + duration);
    } catch {}
  }
}

// Singleton global de la música de fondo libre de derechos
export const bgm = new BgmEngine();
