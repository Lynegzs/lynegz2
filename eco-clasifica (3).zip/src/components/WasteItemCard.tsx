import React, { memo } from 'react';
import { WasteItem } from '../types';
import { WasteGraphic, getGraphicArchetype } from './WasteGraphics';

interface WasteItemCardProps {
  item: WasteItem;
  x: number;
  y: number;
  isGrabbed: boolean;
  isHoveredByHand: boolean;
  width?: number;
  height?: number;
  onPointerDown?: (e: React.PointerEvent) => void;
  onTouchStart?: (e: React.TouchEvent) => void;
}

export const WasteItemCard: React.FC<WasteItemCardProps> = memo(({
  item,
  x,
  y,
  isGrabbed,
  isHoveredByHand,
  width = 96,
  height = 96,
  onPointerDown,
  onTouchStart
}) => {
  const archetype = getGraphicArchetype(item);
  const isCustomVector = archetype !== 'generic';

  return (
    <div
      id="residuo-actual"
      onPointerDown={onPointerDown}
      onTouchStart={onTouchStart}
      style={{
        width: `${width}px`,
        height: `${height}px`,
        transform: `translate3d(${x - width / 2}px, ${y - height / 2}px, 0)`,
        transition: isGrabbed ? 'none' : 'transform 0.35s cubic-bezier(0.34, 1.56, 0.64, 1)',
        willChange: 'transform'
      }}
      className={`absolute top-0 left-0 flex flex-col items-center justify-between p-1.5 rounded-xl select-none z-30 pointer-events-auto touch-none transition-shadow ${
        isGrabbed
          ? 'scale-110 shadow-xl ring-3 ring-emerald-400 bg-slate-900/95 cursor-grabbing shadow-emerald-500/30'
          : isHoveredByHand
          ? 'scale-105 shadow-lg ring-2 ring-amber-400/80 bg-slate-900/90 shadow-amber-500/20 cursor-grab'
          : 'shadow-md ring-1 ring-white/30 bg-slate-900/85 backdrop-blur-md cursor-grab active:cursor-grabbing hover:ring-emerald-400/50'
      }`}
    >
      {/* Grab indicator badge */}
      {isGrabbed && (
        <div className="absolute -top-6 px-2 py-0.5 rounded-full bg-emerald-500 text-slate-950 font-black text-[9px] shadow uppercase tracking-wider whitespace-nowrap animate-pulse flex items-center gap-1">
          <span>✋</span> AGARRADO
        </div>
      )}

      {!isGrabbed && isHoveredByHand && (
        <div className="absolute -top-6 px-2 py-0.5 rounded-full bg-amber-400 text-slate-950 font-bold text-[9px] shadow uppercase tracking-wider whitespace-nowrap animate-bounce flex items-center gap-1">
          <span>🤏</span> ¡HAZ PINZA!
        </div>
      )}

      {!isGrabbed && !isHoveredByHand && (
        <div className="absolute -top-5 px-1.5 py-0.2 rounded-full bg-slate-800/90 text-emerald-300 font-bold text-[8px] shadow border border-emerald-500/40 uppercase tracking-wider whitespace-nowrap opacity-80 flex items-center gap-1">
          <span>🖐️</span> Acerca tu mano
        </div>
      )}

      {/* Main Graphic Illustration Area */}
      <div className="relative flex-1 w-full flex items-center justify-center p-0.5">
        <div className="relative w-12 h-12 sm:w-13 sm:h-13 flex items-center justify-center drop-shadow select-none">
          <WasteGraphic
            item={item}
            className="w-full h-full object-contain"
          />

          {/* Floating native emoji badge when showing vector graphics */}
          {isCustomVector && (
            <span
              className="absolute -bottom-1 -right-1 text-xs leading-none bg-slate-950/90 rounded-full p-0.5 shadow border border-slate-700 select-none"
              title={item.nombre}
            >
              {item.emoji}
            </span>
          )}
        </div>
      </div>

      {/* Waste Name Label: Crisp, readable, no harsh truncate */}
      <div className="w-full mt-0.5 flex justify-center text-center">
        <span
          className="text-[10px] font-bold text-slate-100 px-1.5 py-0.5 rounded bg-slate-950/95 border border-slate-700 shadow-xs leading-tight text-center line-clamp-1 max-w-[90px]"
          title={item.nombre}
        >
          {item.nombre}
        </span>
      </div>
    </div>
  );
});
