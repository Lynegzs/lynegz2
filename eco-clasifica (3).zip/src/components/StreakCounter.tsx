import React, { memo } from 'react';
import { Flame, Zap, Sparkles, TrendingUp, Info } from 'lucide-react';
import { calculateStreakMultiplier, getStreakTierInfo } from '../utils/streak';

interface StreakCounterProps {
  streak: number;
  lastPointsAdded?: { points: number; multiplier: number; id: number } | null;
  className?: string;
  compact?: boolean;
}

export const StreakCounter: React.FC<StreakCounterProps> = memo(({
  streak,
  lastPointsAdded,
  className = '',
  compact = false
}) => {
  const { multiplier, nextTierStreak, itemsToNextTier } = getStreakTierInfo(streak);
  const isHot = streak >= 2;
  const isSuperHot = streak >= 5;
  const isMax = streak >= 10;

  // Visual styling based on multiplier level
  const getTheme = () => {
    if (isMax) {
      return {
        badgeBorder: 'border-purple-400/80',
        badgeBg: 'bg-gradient-to-r from-purple-950/90 via-pink-900/80 to-amber-950/90',
        glow: 'shadow-lg shadow-purple-500/30',
        textAccent: 'text-amber-300',
        flameColor: 'text-amber-300 fill-amber-400 animate-pulse',
        multBg: 'bg-gradient-to-r from-amber-400 to-yellow-300 text-slate-950 font-black',
        label: '¡RACHA MÁXIMA!'
      };
    }
    if (isSuperHot) {
      return {
        badgeBorder: 'border-rose-400/70',
        badgeBg: 'bg-gradient-to-r from-rose-950/90 via-orange-900/80 to-amber-950/90',
        glow: 'shadow-lg shadow-rose-500/25',
        textAccent: 'text-rose-300',
        flameColor: 'text-rose-400 fill-rose-500 animate-pulse',
        multBg: 'bg-gradient-to-r from-rose-500 to-orange-400 text-white font-black',
        label: '¡SUPER RACHA!'
      };
    }
    if (isHot) {
      return {
        badgeBorder: 'border-amber-400/60',
        badgeBg: 'bg-gradient-to-r from-amber-950/90 via-orange-950/80 to-slate-900/90',
        glow: 'shadow-md shadow-amber-500/20',
        textAccent: 'text-amber-300',
        flameColor: 'text-amber-400 fill-amber-500',
        multBg: 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-black',
        label: 'RACHA ACTIVA'
      };
    }
    return {
      badgeBorder: 'border-slate-700/60',
      badgeBg: 'bg-slate-900/80 backdrop-blur-md',
      glow: 'shadow-sm',
      textAccent: 'text-slate-400',
      flameColor: 'text-slate-500',
      multBg: 'bg-slate-800 text-slate-300 font-bold',
      label: 'SIN RACHA'
    };
  };

  const theme = getTheme();

  if (compact) {
    return (
      <div
        className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border transition-all duration-300 ${theme.badgeBorder} ${theme.badgeBg} ${theme.glow} ${className}`}
        title={`Racha actual: ${streak} aciertos seguidos. Multiplicador: x${multiplier.toFixed(1)}`}
      >
        <Flame className={`w-3.5 h-3.5 ${theme.flameColor} transition-transform ${isHot ? 'scale-110' : ''}`} />
        <span className="text-xs font-black text-white">{streak}</span>
        <span className={`px-1.5 py-0.2 rounded-md text-[10px] ${theme.multBg}`}>
          x{multiplier.toFixed(1)}
        </span>
      </div>
    );
  }

  return (
    <div
      className={`relative flex flex-col items-end pointer-events-auto select-none ${className}`}
    >
      {/* Floating score notification when points are added with streak */}
      {lastPointsAdded && (
        <div
          key={lastPointsAdded.id}
          className="absolute -top-7 right-0 pointer-events-none animate-bounce flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-400 text-slate-950 text-xs font-black shadow-lg shadow-amber-400/40 border border-yellow-200 z-30"
        >
          <span>+{lastPointsAdded.points} pts</span>
          {lastPointsAdded.multiplier > 1 && (
            <span className="text-[10px] px-1 rounded bg-black/20 text-slate-950 font-extrabold">
              (x{lastPointsAdded.multiplier.toFixed(1)} 🔥)
            </span>
          )}
        </div>
      )}

      {/* Main Streak HUD Badge */}
      <div
        className={`flex items-center gap-2 px-3 py-1.5 rounded-2xl border ${theme.badgeBorder} ${theme.badgeBg} ${theme.glow} transition-all duration-300 backdrop-blur-md`}
      >
        {/* Animated flame icon */}
        <div className="relative flex items-center justify-center">
          <Flame
            className={`w-5 h-5 ${theme.flameColor} transition-all duration-300 ${
              isHot ? 'scale-110 drop-shadow-[0_0_8px_rgba(251,146,60,0.8)]' : ''
            }`}
          />
          {isSuperHot && (
            <span className="absolute -top-1 -right-1 flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500" />
            </span>
          )}
        </div>

        {/* Counter Info */}
        <div className="flex flex-col text-left">
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">
              Racha
            </span>
            <span className="text-sm font-black text-white tracking-tight leading-none">
              {streak}
            </span>
          </div>

          <div className="flex items-center gap-1 text-[9px] font-semibold text-slate-400">
            {isMax ? (
              <span className="text-amber-300 font-bold flex items-center gap-0.5">
                <Zap className="w-2.5 h-2.5 fill-amber-300" /> Multiplicador tope
              </span>
            ) : nextTierStreak !== null ? (
              <span>
                Próx: <strong className="text-amber-300 font-bold">x{calculateStreakMultiplier(nextTierStreak).toFixed(1)}</strong> en {itemsToNextTier} {itemsToNextTier === 1 ? 'acierto' : 'aciertos'}
              </span>
            ) : null}
          </div>
        </div>

        {/* Big Multiplier Pill */}
        <div
          className={`flex items-center gap-0.5 px-2 py-1 rounded-xl text-xs sm:text-sm font-black transition-all duration-300 shadow-sm ${theme.multBg} ${
            isHot ? 'scale-105' : ''
          }`}
        >
          <TrendingUp className="w-3 h-3" />
          <span>x{multiplier.toFixed(1)}</span>
        </div>
      </div>
    </div>
  );
});
