import React, { useState, useEffect } from 'react';
import { Music, Play, Pause, Volume2, VolumeX, SkipForward, Sparkles, ShieldCheck, Shuffle } from 'lucide-react';
import { bgm, BGM_TRACKS, BgmTrackId } from '../utils/bgm';

interface MusicPlayerControlProps {
  compact?: boolean;
  onOpenModal?: () => void;
}

export const MusicPlayerControl: React.FC<MusicPlayerControlProps> = ({ compact = false, onOpenModal }) => {
  const [isPlaying, setIsPlaying] = useState<boolean>(() => bgm.getIsPlaying());
  const [currentTrack, setCurrentTrack] = useState(() => bgm.getCurrentTrack());
  const [isInfiniteMode, setIsInfiniteMode] = useState<boolean>(() => bgm.getIsInfiniteMode());
  const [volume, setVolume] = useState<number>(() => bgm.getVolume());
  const [showDropdown, setShowDropdown] = useState<boolean>(false);

  useEffect(() => {
    // Sincronizar automáticamente con el motor de BGM
    const unsubscribe = bgm.subscribe(() => {
      setIsPlaying(bgm.getIsPlaying());
      setCurrentTrack(bgm.getCurrentTrack());
      setIsInfiniteMode(bgm.getIsInfiniteMode());
      setVolume(bgm.getVolume());
    });
    return unsubscribe;
  }, []);

  const handleTogglePlay = (e: React.MouseEvent) => {
    e.stopPropagation();
    bgm.toggle();
  };

  const handleNextTrack = (e: React.MouseEvent) => {
    e.stopPropagation();
    bgm.nextTrack();
  };

  const handleSelectTrack = (trackId: BgmTrackId) => {
    bgm.setTrack(trackId);
    if (!isPlaying) {
      bgm.play();
    }
  };

  const handleStartShuffle = (e: React.MouseEvent) => {
    e.stopPropagation();
    bgm.startInfiniteModeShuffle();
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    bgm.setVolume(val);
  };

  const handleToggleMute = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (volume > 0) {
      bgm.setVolume(0);
    } else {
      bgm.setVolume(0.25);
      if (!isPlaying) bgm.play();
    }
  };

  // Versión compacta para la barra superior (HUD del juego o cabecera del menú)
  if (compact) {
    return (
      <div className="relative inline-flex items-center">
        <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-900/90 hover:bg-slate-800/90 border border-emerald-500/30 text-xs text-slate-200 shadow-md backdrop-blur-md transition">
          {/* Botón Play / Pause con indicador de ecualizador */}
          <button
            onClick={handleTogglePlay}
            title={isPlaying ? 'Pausar música sin derechos' : 'Reproducir música libre de derechos'}
            className={`p-1.5 rounded-lg transition flex items-center gap-1 cursor-pointer ${
              isPlaying
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            {isPlaying ? (
              <>
                <Pause className="w-3.5 h-3.5 fill-current" />
                <span className="flex items-end gap-0.5 h-3 w-3">
                  <span className="w-0.5 bg-emerald-400 h-full animate-[pulse_0.6s_ease-in-out_infinite]" />
                  <span className="w-0.5 bg-teal-300 h-2/3 animate-[pulse_0.4s_ease-in-out_infinite_0.2s]" />
                  <span className="w-0.5 bg-emerald-400 h-4/5 animate-[pulse_0.8s_ease-in-out_infinite_0.4s]" />
                </span>
              </>
            ) : (
              <Play className="w-3.5 h-3.5 fill-current text-slate-300" />
            )}
          </button>

          {/* Nombre de la pista y modo */}
          <button
            onClick={() => {
              if (onOpenModal) {
                onOpenModal();
              } else {
                setShowDropdown(!showDropdown);
              }
            }}
            title={onOpenModal ? "Ver y cambiar las 10 canciones del juego" : "Cambiar pista musical o ajustar volumen"}
            className="flex items-center gap-1.5 px-1.5 py-1 rounded-lg hover:bg-slate-700/60 transition cursor-pointer max-w-[150px] sm:max-w-[210px] text-left"
          >
            {isInfiniteMode ? (
              <Shuffle className={`w-3 h-3 shrink-0 text-amber-400 ${isPlaying ? 'animate-pulse' : ''}`} />
            ) : (
              <Music className={`w-3 h-3 shrink-0 ${isPlaying ? 'text-emerald-400 animate-spin-slow' : 'text-slate-400'}`} />
            )}
            <div className="flex flex-col truncate leading-tight">
              <span className="truncate text-[11px] font-bold text-slate-200">
                {currentTrack.emoji} {currentTrack.name}
              </span>
              <span className="text-[9px] text-emerald-400 font-semibold truncate">
                {isInfiniteMode ? 'Aleatorio ♾️' : `Nivel ${currentTrack.level}/10`}
              </span>
            </div>
          </button>

          {/* Botón Siguiente Pista */}
          <button
            onClick={handleNextTrack}
            title={isInfiniteMode ? 'Siguiente canción aleatoria' : 'Siguiente canción'}
            className="p-1 rounded-lg hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
          >
            <SkipForward className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Dropdown flotante para control de volumen y las 10 canciones */}
        {showDropdown && (
          <div
            className="absolute top-full right-0 mt-2 w-72 sm:w-80 p-3 rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl z-50 flex flex-col gap-2.5 backdrop-blur-xl animate-in fade-in zoom-in-95 duration-150"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-1.5 border-b border-slate-800">
              <span className="text-[11px] font-black uppercase tracking-wider text-emerald-400 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                10 Canciones Libres de Derechos
              </span>
              <button
                onClick={() => setShowDropdown(false)}
                className="text-[10px] text-slate-400 hover:text-white px-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {onOpenModal && (
              <button
                onClick={() => {
                  setShowDropdown(false);
                  onOpenModal();
                }}
                className="w-full py-1.5 px-2 rounded-xl bg-teal-500/20 hover:bg-teal-500/30 text-teal-300 border border-teal-500/40 text-xs font-bold text-center transition cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Music className="w-3.5 h-3.5" />
                <span>Abrir Catálogo de Música Completo</span>
              </button>
            )}

            {/* Slider de volumen */}
            <div className="flex items-center gap-2">
              <button
                onClick={handleToggleMute}
                className="text-slate-400 hover:text-emerald-400 transition cursor-pointer"
              >
                {volume === 0 ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
              </button>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={volume}
                onChange={handleVolumeChange}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
              />
              <span className="text-[10px] font-bold text-slate-400 w-7 text-right">
                {Math.round(volume * 100)}%
              </span>
            </div>

            {/* Botón rápido Modo Aleatorio */}
            <button
              onClick={handleStartShuffle}
              className={`w-full flex items-center justify-center gap-2 py-1.5 px-2 rounded-xl text-xs font-bold transition cursor-pointer ${
                isInfiniteMode
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300 border border-slate-700'
              }`}
            >
              <Shuffle className="w-3.5 h-3.5 text-amber-400" />
              <span>{isInfiniteMode ? 'Modo Aleatorio Activo 🔀 (Sin repetición)' : 'Activar Modo Aleatorio (10 canciones)'}</span>
            </button>

            {/* Selector de las 10 pistas */}
            <div className="flex flex-col gap-1 max-h-56 overflow-y-auto pr-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase">1 Canción por Nivel:</span>
              {BGM_TRACKS.map((t) => (
                <button
                  key={t.id}
                  onClick={() => handleSelectTrack(t.id)}
                  className={`flex items-center justify-between p-1.5 rounded-xl text-left text-xs font-semibold transition cursor-pointer ${
                    currentTrack.id === t.id
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'hover:bg-slate-800 text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-1.5 truncate">
                    <span className="px-1.5 py-0.5 rounded bg-slate-800 text-[9px] font-black text-emerald-400">
                      L{t.level}
                    </span>
                    <span>{t.emoji}</span>
                    <span className="truncate">{t.name}</span>
                  </div>
                  <span className="text-[9px] text-slate-400 shrink-0 ml-1">{t.bpm} BPM</span>
                </button>
              ))}
            </div>

            <div className="pt-1 border-t border-slate-800/80 text-[10px] text-emerald-400/90 text-center flex items-center justify-center gap-1 font-medium">
              <Sparkles className="w-3 h-3" />
              <span>Web Audio nativo • 100% Sin copyright</span>
            </div>
          </div>
        )}
      </div>
    );
  }

  // Versión expandida para la pantalla del Menú Principal
  return (
    <div className="w-full max-w-xl my-4 p-4 sm:p-5 rounded-3xl bg-slate-900/90 border border-emerald-500/30 shadow-xl backdrop-blur-md flex flex-col gap-3">
      {/* Header del reproductor */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center shadow-md shadow-emerald-500/20">
            <Music className="w-4 h-4 text-slate-950" />
          </div>
          <div className="text-left">
            <div className="text-xs sm:text-sm font-black text-white flex items-center gap-1.5">
              <span>BANDA SONORA PROCEDURAL</span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[9px] font-black uppercase tracking-wider flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-emerald-400" />
                100% Libre de Derechos
              </span>
            </div>
            <div className="text-[11px] text-slate-400">
              10 canciones exclusivas • 1 para cada nivel • Aleatorio en Modo Infinito
            </div>
          </div>
        </div>

        {/* Acciones principales Play / Modo Infinito */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleStartShuffle}
            title="Reproducir las 10 canciones en orden aleatorio sin repetir la anterior"
            className={`px-3 py-2 rounded-2xl font-bold text-xs transition cursor-pointer flex items-center gap-1.5 border ${
              isInfiniteMode
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-sm'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
            }`}
          >
            <Shuffle className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Aleatorio</span>
          </button>

          <button
            onClick={handleTogglePlay}
            className={`px-4 py-2 rounded-2xl font-black text-xs transition cursor-pointer flex items-center gap-2 shadow-lg ${
              isPlaying
                ? 'bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40'
                : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-emerald-500/20 font-black'
            }`}
          >
            {isPlaying ? (
              <>
                <Pause className="w-4 h-4 fill-current" />
                <span>PAUSAR</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                <span>ACTIVAR MÚSICA</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Grid de las 10 Canciones (1 por cada nivel) */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 max-h-60 sm:max-h-none overflow-y-auto pr-1">
        {BGM_TRACKS.map((t) => {
          const isSelected = currentTrack.id === t.id;
          return (
            <button
              key={t.id}
              onClick={() => handleSelectTrack(t.id)}
              className={`p-2.5 rounded-2xl text-left transition border cursor-pointer flex flex-col justify-between ${
                isSelected
                  ? 'bg-emerald-950/60 border-emerald-400 text-white shadow-md shadow-emerald-500/10 ring-1 ring-emerald-400'
                  : 'bg-slate-800/60 border-slate-700/80 hover:border-slate-600 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <div className="flex items-center justify-between w-full">
                <span className="px-1.5 py-0.5 rounded bg-slate-900 text-[9px] font-black text-emerald-400">
                  Nivel {t.level}
                </span>
                <span className="text-base">{t.emoji}</span>
              </div>
              <div className="mt-1.5">
                <div className="text-xs font-bold truncate">{t.name}</div>
                <div className="text-[9px] text-slate-400 truncate">{t.style}</div>
              </div>
              {isSelected && isPlaying && (
                <div className="flex items-center gap-1 mt-1">
                  <span className="flex items-end gap-0.5 h-2.5">
                    <span className="w-0.5 bg-emerald-400 h-full animate-[pulse_0.6s_ease-in-out_infinite]" />
                    <span className="w-0.5 bg-teal-300 h-2/3 animate-[pulse_0.4s_ease-in-out_infinite_0.2s]" />
                    <span className="w-0.5 bg-emerald-400 h-4/5 animate-[pulse_0.8s_ease-in-out_infinite_0.4s]" />
                  </span>
                  <span className="text-[9px] text-emerald-400 font-bold uppercase">Sonando</span>
                </div>
              )}
            </button>
          );
        })}
      </div>

      {/* Control de Volumen y detalle de la pista actual */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800/80 text-xs">
        <div className="flex items-center gap-2 text-slate-300 font-semibold truncate max-w-xs">
          <span>{currentTrack.emoji}</span>
          <span className="truncate">
            <strong>Nivel {currentTrack.level}:</strong> {currentTrack.name} ({currentTrack.bpm} BPM)
          </span>
          {isInfiniteMode && (
            <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[10px] font-bold">
              🔀 Aleatorio
            </span>
          )}
        </div>

        <div className="flex items-center gap-2.5 ml-auto">
          <button
            onClick={handleToggleMute}
            title={volume === 0 ? 'Activar sonido' : 'Silenciar'}
            className="text-slate-400 hover:text-emerald-400 transition cursor-pointer"
          >
            {volume === 0 ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
          </button>
          <span className="text-[11px] font-bold text-slate-400">Volumen:</span>
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={volume}
            onChange={handleVolumeChange}
            className="w-24 sm:w-32 h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
          />
          <span className="text-[11px] font-bold text-emerald-400 w-8 text-right">
            {Math.round(volume * 100)}%
          </span>
        </div>
      </div>
    </div>
  );
};
