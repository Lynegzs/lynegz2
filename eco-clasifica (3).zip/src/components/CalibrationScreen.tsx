import React, { useState, useEffect, useRef } from 'react';
import { Camera, CheckCircle2, Hand, MoveHorizontal, MoveVertical, Play, ArrowLeft } from 'lucide-react';
import { sound } from '../utils/audio';

interface CalibrationScreenProps {
  handDetected: boolean;
  normX: number;
  normY: number;
  isPinching: boolean;
  videoRef: React.RefObject<HTMLVideoElement | null>;
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
  onStartGame: () => void;
  onBackToMenu: () => void;
}

export const CalibrationScreen: React.FC<CalibrationScreenProps> = ({
  handDetected,
  normX,
  normY,
  isPinching,
  videoRef,
  canvasRef,
  onStartGame,
  onBackToMenu
}) => {
  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const localCanvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (localVideoRef.current && videoRef.current?.srcObject) {
      localVideoRef.current.srcObject = videoRef.current.srcObject;
      localVideoRef.current.muted = true;
      localVideoRef.current.play().catch(() => {});
    }
  }, [videoRef]);

  // Step progression: 1 = Hand detection, 2 = Left/Right motion, 3 = Up/Down motion, 4 = Ready!
  const [step, setStep] = useState<number>(1);

  // Use refs for tracking motion ranges to completely prevent re-render loops
  const minXRef = useRef<number>(0.5);
  const maxXRef = useRef<number>(0.5);
  const minYRef = useRef<number>(0.5);
  const maxYRef = useRef<number>(0.5);

  // Step 1: Detect hand placed steadily
  useEffect(() => {
    if (step === 1 && handDetected) {
      const timer = setTimeout(() => {
        setStep(2);
        minXRef.current = 0.5;
        maxXRef.current = 0.5;
        sound.playGrab();
      }, 900);
      return () => clearTimeout(timer);
    }
  }, [handDetected, step]);

  // Step 2: Track horizontal movement
  useEffect(() => {
    if (step === 2 && handDetected) {
      minXRef.current = Math.min(minXRef.current, normX);
      maxXRef.current = Math.max(maxXRef.current, normX);
      if (maxXRef.current - minXRef.current > 0.16) {
        setStep(3);
        minYRef.current = 0.5;
        maxYRef.current = 0.5;
        sound.playGrab();
      }
    }
  }, [handDetected, normX, step]);

  // Step 3: Track vertical movement
  useEffect(() => {
    if (step === 3 && handDetected) {
      minYRef.current = Math.min(minYRef.current, normY);
      maxYRef.current = Math.max(maxYRef.current, normY);
      if (maxYRef.current - minYRef.current > 0.14) {
        setStep(4);
        sound.playCorrect();
      }
    }
  }, [handDetected, normY, step]);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen w-full max-w-2xl mx-auto px-3 py-3 select-none">
      {/* Top navigation */}
      <div className="w-full flex items-center justify-between mb-2">
        <button
          onClick={onBackToMenu}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition text-xs font-semibold border border-slate-700 cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Volver al Menú</span>
        </button>

        <div className="flex items-center gap-2">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
            Fase de Calibración
          </span>
          <div className="flex gap-1">
            {[1, 2, 3, 4].map((s) => (
              <span
                key={s}
                className={`w-2 h-2 rounded-full transition-colors ${
                  step >= s ? 'bg-emerald-400' : 'bg-slate-700'
                }`}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Main Card */}
      <div className="w-full bg-slate-800/90 border border-slate-700/80 rounded-2xl p-4 sm:p-5 shadow-2xl backdrop-blur-md flex flex-col items-center">
        {/* Title */}
        <div className="flex items-center gap-2 mb-1 text-emerald-400">
          <Camera className="w-5 h-5" />
          <h1 className="text-lg sm:text-xl font-black tracking-tight text-white uppercase">
            📷 CONFIGURACIÓN DE CÁMARA
          </h1>
        </div>

        {/* Step Instructions */}
        <div className="my-1.5 text-center min-h-[36px] flex items-center justify-center">
          {step === 1 && (
            <div className="flex items-center gap-1.5 text-sm font-bold text-amber-300 animate-pulse">
              <Hand className="w-4 h-4" />
              <span>Coloca tu mano frente a la cámara.</span>
            </div>
          )}

          {step === 2 && (
            <div className="flex items-center gap-1.5 text-sm font-bold text-sky-300">
              <MoveHorizontal className="w-4 h-4 animate-bounce" />
              <span>Mueve lentamente tu mano de izquierda a derecha.</span>
            </div>
          )}

          {step === 3 && (
            <div className="flex items-center gap-1.5 text-sm font-bold text-sky-300">
              <MoveVertical className="w-4 h-4 animate-bounce" />
              <span>Ahora mueve tu mano de arriba hacia abajo.</span>
            </div>
          )}

          {step === 4 && (
            <div className="flex flex-col items-center">
              <div className="flex items-center gap-1.5 text-base font-black text-emerald-400">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                <span>✅ MANO DETECTADA</span>
              </div>
              <p className="text-xs font-semibold text-slate-300 mt-0.5">
                ¡Perfecto! Ya puedes comenzar. Haz pinza 🤏 para verificar.
              </p>
            </div>
          )}
        </div>

        {/* Interactive Calibration Viewport */}
        <div className="relative w-full max-w-sm aspect-[4/3] rounded-xl overflow-hidden bg-slate-950 border-2 border-slate-700 shadow-xl my-2">
          <video
            ref={localVideoRef}
            playsInline
            muted
            autoPlay
            className="absolute inset-0 w-full h-full object-cover -scale-x-100"
          />
          <canvas
            ref={localCanvasRef}
            width={640}
            height={480}
            className="absolute inset-0 w-full h-full object-cover pointer-events-none z-10"
          />

          {/* Virtual Crosshair overlay following the calibrated hand position */}
          {handDetected && (
            <div
              style={{
                left: `${normX * 100}%`,
                top: `${normY * 100}%`
              }}
              className="absolute -translate-x-1/2 -translate-y-1/2 pointer-events-none transition-all duration-75 flex flex-col items-center z-20"
            >
              <div
                className={`w-8 h-8 rounded-full border-2 border-dashed flex items-center justify-center ${
                  isPinching
                    ? 'border-emerald-400 bg-emerald-500/30 scale-125'
                    : 'border-amber-400 bg-amber-400/20'
                }`}
              >
                <div
                  className={`w-2.5 h-2.5 rounded-full ${
                    isPinching ? 'bg-emerald-400' : 'bg-amber-400'
                  }`}
                />
              </div>
              <span className="text-xs mt-1 font-mono font-bold px-2 py-0.5 rounded bg-slate-900/90 text-white">
                {isPinching ? '🤏 Pinza activa' : '🖐️ Mano libre'}
              </span>
            </div>
          )}

          {/* Calibration guide bounding box in center */}
          <div className="absolute inset-8 border border-white/20 rounded-xl pointer-events-none flex items-center justify-center z-15">
            {!handDetected && (
              <div className="bg-slate-900/80 px-4 py-2 rounded-xl border border-slate-700 text-center">
                <span className="text-xs font-semibold text-slate-300">
                  Área óptima de captura
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Action Button - Always enabled so player is never blocked */}
        <div className="mt-4 flex flex-col sm:flex-row items-center gap-4 w-full justify-center">
          <button
            id="btn-comenzar-partida"
            onClick={onStartGame}
            className="flex items-center justify-center gap-3 px-8 py-4 rounded-2xl font-black text-lg tracking-wide uppercase shadow-xl transition-all w-full sm:w-auto bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 hover:scale-105 active:scale-95 cursor-pointer ring-4 ring-emerald-400/40"
          >
            <Play className="w-5 h-5 fill-current" />
            <span>▶ ENTRAR AL JUEGO</span>
          </button>
        </div>
      </div>
    </div>
  );
};
