import React, { useRef, useEffect } from 'react';
import { Camera, AlertTriangle, RotateCcw, ArrowLeft, Loader2, CheckCircle2, MousePointer, ShieldCheck } from 'lucide-react';

interface CameraPermissionModalProps {
  isLoading: boolean;
  hasError: boolean;
  errorMessage?: string;
  onRetry: () => void;
  onBack: () => void;
  videoRef?: React.RefObject<HTMLVideoElement | null>;
  onContinueWithoutCamera?: () => void;
}

export const CameraPermissionModal: React.FC<CameraPermissionModalProps> = ({
  isLoading,
  hasError,
  errorMessage,
  onRetry,
  onBack,
  videoRef,
  onContinueWithoutCamera
}) => {
  const previewVideoRef = useRef<HTMLVideoElement | null>(null);

  useEffect(() => {
    if (previewVideoRef.current && videoRef?.current?.srcObject) {
      previewVideoRef.current.srcObject = videoRef.current.srcObject;
      previewVideoRef.current.muted = true;
      previewVideoRef.current.play().catch(() => {});
    }
  }, [videoRef]);

  const hasStream = !!videoRef?.current?.srcObject;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/85 backdrop-blur-md select-none">
      <div className="w-full max-w-md bg-slate-900 border border-slate-700/80 rounded-2xl p-4 sm:p-5 shadow-2xl flex flex-col items-center text-center max-h-[92vh] overflow-y-auto">
        {hasError ? (
          <div className="w-12 h-12 rounded-xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 mb-2">
            <AlertTriangle className="w-7 h-7" />
          </div>
        ) : hasStream ? (
          <div className="w-12 h-12 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 mb-2">
            <CheckCircle2 className="w-7 h-7 text-emerald-400 animate-pulse" />
          </div>
        ) : (
          <div className="w-12 h-12 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 mb-2">
            <Camera className="w-7 h-7 animate-pulse" />
          </div>
        )}

        <h2 className="text-xl font-black text-white uppercase tracking-tight">
          {hasError ? 'Acceso a Cámara' : hasStream ? '¡Cámara Detectada!' : 'Solicitud de Cámara'}
        </h2>

        {/* Live video test container if stream is active */}
        {hasStream && !hasError && (
          <div className="relative w-full max-w-xs aspect-video rounded-2xl overflow-hidden bg-slate-950 border-2 border-emerald-400/60 shadow-lg my-3">
            <video
              ref={previewVideoRef}
              playsInline
              muted
              autoPlay
              className="w-full h-full object-cover -scale-x-100"
            />
            <div className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-slate-950/80 text-[10px] font-mono font-bold text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
              <span>IMAGEN EN VIVO</span>
            </div>
          </div>
        )}

        {hasError ? (
          <div className="my-4 text-sm text-rose-200 bg-rose-950/40 border border-rose-800/60 p-4 rounded-2xl text-left w-full">
            <p className="font-bold flex items-center gap-2 mb-1 text-rose-300">
              <span>⚠️</span>
              <span>No se pudo acceder a la señal de cámara.</span>
            </p>
            <p className="text-xs text-rose-300/90 mt-1 leading-relaxed">
              {errorMessage || 'Por favor comprueba los permisos de cámara en tu navegador.'}
            </p>

            <div className="mt-3 p-2.5 rounded-xl bg-slate-950/60 border border-white/5 text-[11px] text-slate-300 space-y-1">
              <div className="font-bold text-amber-300 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>¿Cómo solucionarlo?</span>
              </div>
              <p>1. Haz clic en el icono del candado o cámara 🔒📷 en la barra de direcciones de tu navegador.</p>
              <p>2. Selecciona &quot;Permitir&quot; para la Cámara.</p>
              <p>3. Asegúrate de que ninguna otra pestaña o aplicación (Zoom, Meet, Teams) tenga la cámara bloqueada.</p>
            </div>
          </div>
        ) : (
          <div className="my-4 text-sm text-slate-300 bg-slate-800/60 border border-slate-700 p-4 rounded-2xl w-full">
            <p className="font-medium text-emerald-300 flex items-center justify-center gap-2 mb-2">
              <Camera className="w-4 h-4" />
              <span>📷 Realidad Aumentada & Visión por Computadora</span>
            </p>
            <p className="text-xs leading-relaxed text-slate-300">
              Atrapa y Recicla utiliza tu cámara web para proyectar los residuos y detectar el movimiento de tu mano y el gesto de pinza en tiempo real.
            </p>
            {isLoading && (
              <div className="flex items-center justify-center gap-2 text-xs font-semibold text-emerald-400 mt-3 animate-pulse">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Conectando cámara y cargando modelos de IA...</span>
              </div>
            )}
          </div>
        )}

        <div className="flex flex-col sm:flex-row gap-2.5 w-full mt-2">
          {hasError ? (
            <>
              <button
                onClick={onRetry}
                className="flex-1 flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-bold text-sm uppercase tracking-wider bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-lg transition cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Reintentar Cámara</span>
              </button>
              {onContinueWithoutCamera && (
                <button
                  onClick={onContinueWithoutCamera}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-bold text-xs uppercase tracking-wider bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 transition cursor-pointer"
                >
                  <MousePointer className="w-4 h-4" />
                  <span>Jugar con Ratón / Táctil</span>
                </button>
              )}
              <button
                onClick={onBack}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-bold text-xs uppercase tracking-wider bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Volver</span>
              </button>
            </>
          ) : (
            <button
              onClick={onBack}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider bg-slate-800 hover:bg-slate-700 text-slate-400 transition cursor-pointer"
            >
              <span>Cancelar</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
