import React, { useEffect, useRef, useImperativeHandle, forwardRef, useCallback } from 'react';
import confetti from 'canvas-confetti';
import { WasteCategory } from '../types';

export interface ParticleEffectHandle {
  spawnSuccessBurst: (stageX: number, stageY: number, category: WasteCategory, viewportX?: number, viewportY?: number) => void;
  spawnVictoryBlast: () => void;
}

interface ParticleEffectsProps {
  width: number;
  height: number;
}

// Discriminative union for high-performance canvas particle system
interface ConfettiParticle {
  type: 'confetti';
  x: number;
  y: number;
  vx: number;
  vy: number;
  width: number;
  height: number;
  color: string;
  backColor: string;
  alpha: number;
  decay: number;
  gravity: number;
  drag: number;
  rotation: number;
  vRotation: number;
  wobble: number;
  vWobble: number;
}

interface SparkParticle {
  type: 'spark';
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  glowColor: string;
  alpha: number;
  decay: number;
  gravity: number;
  drag: number;
  sparklePhase: number;
  twinkleSpeed: number;
}

interface ShapeParticle {
  type: 'shape';
  shape: 'leaf' | 'star' | 'sparkle' | 'diamond' | 'circle';
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  glowColor: string;
  alpha: number;
  decay: number;
  gravity: number;
  drag: number;
  rotation: number;
  vRotation: number;
}

type CanvasParticle = ConfettiParticle | SparkParticle | ShapeParticle;

interface Shockwave {
  x: number;
  y: number;
  radius: number;
  maxRadius: number;
  color: string;
  alpha: number;
  lineWidth: number;
}

interface ScoreFloater {
  x: number;
  y: number;
  vy: number;
  text: string;
  subText: string;
  color: string;
  alpha: number;
  scale: number;
  age: number;
  maxAge: number;
}

// High-fidelity chromatic palettes for each container category
const CATEGORY_PALETTES: Record<WasteCategory, {
  primary: string;
  glow: string;
  confettiColors: Array<{ front: string; back: string }>;
  sparkColors: string[];
}> = {
  verde: {
    primary: '#22c55e',
    glow: 'rgba(34, 197, 94, 0.8)',
    confettiColors: [
      { front: '#22c55e', back: '#15803d' },
      { front: '#4ade80', back: '#16a34a' },
      { front: '#86efac', back: '#22c55e' },
      { front: '#facc15', back: '#ca8a04' },
      { front: '#fbbf24', back: '#d97706' },
      { front: '#34d399', back: '#059669' },
      { front: '#ffffff', back: '#cbd5e1' }
    ],
    sparkColors: ['#ffffff', '#fef08a', '#86efac', '#4ade80', '#facc15']
  },
  azul: {
    primary: '#3b82f6',
    glow: 'rgba(59, 130, 246, 0.8)',
    confettiColors: [
      { front: '#3b82f6', back: '#1d4ed8' },
      { front: '#60a5fa', back: '#2563eb' },
      { front: '#93c5fd', back: '#3b82f6' },
      { front: '#38bdf8', back: '#0284c7' },
      { front: '#facc15', back: '#ca8a04' },
      { front: '#06b6d4', back: '#0891b2' },
      { front: '#ffffff', back: '#cbd5e1' }
    ],
    sparkColors: ['#ffffff', '#bae6fd', '#93c5fd', '#38bdf8', '#fef08a']
  },
  gris: {
    primary: '#94a3b8',
    glow: 'rgba(148, 163, 184, 0.8)',
    confettiColors: [
      { front: '#94a3b8', back: '#475569' },
      { front: '#cbd5e1', back: '#64748b' },
      { front: '#e2e8f0', back: '#94a3b8' },
      { front: '#fbbf24', back: '#b45309' },
      { front: '#f59e0b', back: '#b45309' },
      { front: '#f8fafc', back: '#94a3b8' },
      { front: '#ffffff', back: '#cbd5e1' }
    ],
    sparkColors: ['#ffffff', '#fef08a', '#e2e8f0', '#fbbf24', '#cbd5e1']
  },
  rojo: {
    primary: '#ef4444',
    glow: 'rgba(239, 68, 68, 0.8)',
    confettiColors: [
      { front: '#ef4444', back: '#b91c1c' },
      { front: '#f87171', back: '#dc2626' },
      { front: '#fca5a5', back: '#ef4444' },
      { front: '#fb923c', back: '#c2410c' },
      { front: '#facc15', back: '#ca8a04' },
      { front: '#f43f5e', back: '#be123c' },
      { front: '#ffffff', back: '#cbd5e1' }
    ],
    sparkColors: ['#ffffff', '#fecaca', '#fed7aa', '#f87171', '#fef08a']
  }
};

export const ParticleCanvas = forwardRef<ParticleEffectHandle, ParticleEffectsProps>(
  ({ width, height }, ref) => {
    const canvasRef = useRef<HTMLCanvasElement | null>(null);
    const particlesRef = useRef<CanvasParticle[]>([]);
    const shockwavesRef = useRef<Shockwave[]>([]);
    const scoreFloatersRef = useRef<ScoreFloater[]>([]);
    const animFrameIdRef = useRef<number | null>(null);
    const isRunningRef = useRef<boolean>(false);

    // Main animation & render step on the native Canvas
    const render = useCallback(() => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const dpr = window.devicePixelRatio || 1;
      ctx.save();
      ctx.scale(dpr, dpr);

      // ==========================================
      // 1. RENDER & UPDATE SHOCKWAVE EXPANSION RINGS
      // ==========================================
      for (let i = shockwavesRef.current.length - 1; i >= 0; i--) {
        const sw = shockwavesRef.current[i];
        sw.radius += 4.2;
        sw.alpha -= 0.032;

        if (sw.alpha <= 0 || sw.radius >= sw.maxRadius) {
          shockwavesRef.current.splice(i, 1);
          continue;
        }

        ctx.save();
        ctx.beginPath();
        ctx.arc(sw.x, sw.y, sw.radius, 0, Math.PI * 2);
        ctx.strokeStyle = sw.color;
        ctx.globalAlpha = Math.max(0, sw.alpha);
        ctx.lineWidth = sw.lineWidth * (1 - sw.radius / sw.maxRadius * 0.4);
        ctx.shadowColor = sw.color;
        ctx.shadowBlur = 14;
        ctx.stroke();
        ctx.restore();
      }

      // ==========================================
      // 2. RENDER & UPDATE PARTICLES (CONFETTI, SPARKS, SHAPES)
      // ==========================================
      for (let i = particlesRef.current.length - 1; i >= 0; i--) {
        const p = particlesRef.current[i];

        if (p.type === 'confetti') {
          // --- 3D Fluttering Confetti Paper Physics ---
          p.x += p.vx + Math.sin(p.wobble) * 1.2;
          p.y += p.vy;
          p.vy += p.gravity;
          p.vx *= p.drag;
          p.vy *= p.drag;
          p.rotation += p.vRotation;
          p.wobble += p.vWobble;
          p.alpha -= p.decay;

          if (p.alpha <= 0 || p.y > height + 40) {
            particlesRef.current.splice(i, 1);
            continue;
          }

          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rotation);

          // 3D tumble flip scale factor
          const flipScale = Math.cos(p.wobble);
          ctx.scale(flipScale, 1);
          ctx.globalAlpha = Math.max(0, p.alpha);

          // Render front or darker back side for realistic 3D depth
          ctx.fillStyle = flipScale > 0 ? p.color : p.backColor;
          ctx.shadowColor = p.color;
          ctx.shadowBlur = 4;
          ctx.fillRect(-p.width / 2, -p.height / 2, p.width, p.height);

          // Subtle sheen highlight on edges
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
          ctx.lineWidth = 0.5;
          ctx.strokeRect(-p.width / 2, -p.height / 2, p.width, p.height);

          ctx.restore();
        } else if (p.type === 'spark') {
          // --- Incandescent Trailing Sparks (Chispas) Physics ---
          p.x += p.vx;
          p.y += p.vy;
          p.vy += p.gravity;
          p.vx *= p.drag;
          p.vy *= p.drag;
          p.sparklePhase += p.twinkleSpeed;
          p.alpha -= p.decay;

          if (p.alpha <= 0 || p.y > height + 30) {
            particlesRef.current.splice(i, 1);
            continue;
          }

          ctx.save();
          ctx.globalAlpha = Math.max(0, p.alpha);

          // Motion streak trail (speed vector line)
          const speed = Math.hypot(p.vx, p.vy);
          const trailLength = Math.min(24, Math.max(5, speed * 2));
          const angle = Math.atan2(p.vy, p.vx);
          const tailX = p.x - Math.cos(angle) * trailLength;
          const tailY = p.y - Math.sin(angle) * trailLength;

          const grad = ctx.createLinearGradient(tailX, tailY, p.x, p.y);
          grad.addColorStop(0, 'rgba(255, 255, 255, 0)');
          grad.addColorStop(0.6, p.color);
          grad.addColorStop(1, '#ffffff');

          ctx.beginPath();
          ctx.moveTo(tailX, tailY);
          ctx.lineTo(p.x, p.y);
          ctx.strokeStyle = grad;
          ctx.lineWidth = Math.max(1.2, 3.2 * p.alpha);
          ctx.lineCap = 'round';
          ctx.shadowColor = p.glowColor;
          ctx.shadowBlur = 10;
          ctx.stroke();

          // Incandescent glowing spark head
          const twinkle = 0.8 + 0.35 * Math.sin(p.sparklePhase);
          ctx.beginPath();
          ctx.arc(p.x, p.y, Math.max(1.5, 2.5 * twinkle), 0, Math.PI * 2);
          ctx.fillStyle = '#ffffff';
          ctx.shadowColor = p.glowColor;
          ctx.shadowBlur = 12;
          ctx.fill();

          // Diamond glint on prominent sparks
          if (p.alpha > 0.55 && twinkle > 0.98) {
            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = 1;
            const starRadius = 5 * twinkle;
            ctx.beginPath();
            ctx.moveTo(p.x - starRadius, p.y);
            ctx.lineTo(p.x + starRadius, p.y);
            ctx.moveTo(p.x, p.y - starRadius);
            ctx.lineTo(p.x, p.y + starRadius);
            ctx.stroke();
          }

          ctx.restore();
        } else if (p.type === 'shape') {
          // --- Celebratory Shape Elements (Leaves, Stars, Sparkles, Diamonds) ---
          p.x += p.vx;
          p.y += p.vy;
          p.vy += p.gravity;
          p.vx *= p.drag;
          p.vy *= p.drag;
          p.rotation += p.vRotation;
          p.alpha -= p.decay;

          if (p.alpha <= 0 || p.y > height + 40) {
            particlesRef.current.splice(i, 1);
            continue;
          }

          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rotation);
          ctx.globalAlpha = Math.max(0, p.alpha);
          ctx.fillStyle = p.color;
          ctx.shadowColor = p.glowColor;
          ctx.shadowBlur = 8;

          const s = p.size;

          if (p.shape === 'star') {
            // 5-point star
            ctx.beginPath();
            for (let pt = 0; pt < 5; pt++) {
              const rot = (Math.PI / 2) * 3;
              const step = Math.PI / 5;
              let x = Math.cos(rot + pt * step * 2) * s;
              let y = Math.sin(rot + pt * step * 2) * s;
              if (pt === 0) ctx.moveTo(x, y);
              else ctx.lineTo(x, y);

              x = Math.cos(rot + (pt * 2 + 1) * step) * (s * 0.44);
              y = Math.sin(rot + (pt * 2 + 1) * step) * (s * 0.44);
              ctx.lineTo(x, y);
            }
            ctx.closePath();
            ctx.fill();
          } else if (p.shape === 'sparkle') {
            // 4-point diamond star
            ctx.beginPath();
            ctx.moveTo(0, -s);
            ctx.quadraticCurveTo(0, 0, s, 0);
            ctx.quadraticCurveTo(0, 0, 0, s);
            ctx.quadraticCurveTo(0, 0, -s, 0);
            ctx.quadraticCurveTo(0, 0, 0, -s);
            ctx.closePath();
            ctx.fill();
          } else if (p.shape === 'leaf') {
            // Eco leaf shape
            ctx.beginPath();
            ctx.moveTo(0, -s);
            ctx.bezierCurveTo(s * 0.85, -s * 0.5, s * 0.85, s * 0.5, 0, s);
            ctx.bezierCurveTo(-s * 0.85, s * 0.5, -s * 0.85, -s * 0.5, 0, -s);
            ctx.closePath();
            ctx.fill();

            // Leaf vein
            ctx.beginPath();
            ctx.moveTo(0, -s * 0.7);
            ctx.lineTo(0, s * 0.7);
            ctx.strokeStyle = '#ffffff';
            ctx.globalAlpha = Math.max(0, p.alpha * 0.6);
            ctx.lineWidth = 1;
            ctx.stroke();
          } else if (p.shape === 'diamond') {
            ctx.beginPath();
            ctx.moveTo(0, -s);
            ctx.lineTo(s * 0.75, 0);
            ctx.lineTo(0, s);
            ctx.lineTo(-s * 0.75, 0);
            ctx.closePath();
            ctx.fill();
          } else {
            // Circle
            ctx.beginPath();
            ctx.arc(0, 0, s / 2, 0, Math.PI * 2);
            ctx.fill();
          }

          ctx.restore();
        }
      }

      // ==========================================
      // 3. RENDER & UPDATE FLOATING SCORE BADGES OVER CONTAINER
      // ==========================================
      for (let i = scoreFloatersRef.current.length - 1; i >= 0; i--) {
        const sf = scoreFloatersRef.current[i];
        sf.age++;
        sf.y += sf.vy;
        sf.vy *= 0.94;

        if (sf.age < 12) {
          sf.scale = 0.6 + (sf.age / 12) * 0.5;
        } else if (sf.age > sf.maxAge - 20) {
          sf.alpha = (sf.maxAge - sf.age) / 20;
          sf.scale = 1.1 + ((sf.age - (sf.maxAge - 20)) / 20) * 0.15;
        }

        if (sf.age >= sf.maxAge) {
          scoreFloatersRef.current.splice(i, 1);
          continue;
        }

        ctx.save();
        ctx.translate(sf.x, sf.y);
        ctx.scale(sf.scale, sf.scale);
        ctx.globalAlpha = Math.max(0, sf.alpha);

        // Backdrop glowing capsule
        const pillWidth = 144;
        const pillHeight = 44;
        const pillRadius = 22;

        ctx.beginPath();
        ctx.roundRect(-pillWidth / 2, -pillHeight / 2, pillWidth, pillHeight, pillRadius);
        ctx.fillStyle = 'rgba(2, 6, 23, 0.92)';
        ctx.fill();

        ctx.strokeStyle = sf.color;
        ctx.lineWidth = 2.5;
        ctx.shadowColor = sf.color;
        ctx.shadowBlur = 18;
        ctx.stroke();

        // Main Score (+10 ⭐)
        ctx.font = '900 20px "Plus Jakarta Sans", system-ui, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillStyle = '#ffffff';
        ctx.shadowColor = sf.color;
        ctx.shadowBlur = 10;
        ctx.fillText(sf.text, 0, -4);

        // Subtext (¡CORRECTO!)
        ctx.font = '800 10px "Plus Jakarta Sans", system-ui, sans-serif';
        ctx.fillStyle = sf.color;
        ctx.shadowBlur = 5;
        ctx.fillText(sf.subText, 0, 13);

        ctx.restore();
      }

      ctx.restore();

      // Keep animation loop ticking as long as particles or effects remain active
      if (
        particlesRef.current.length > 0 ||
        shockwavesRef.current.length > 0 ||
        scoreFloatersRef.current.length > 0
      ) {
        animFrameIdRef.current = requestAnimationFrame(render);
      } else {
        isRunningRef.current = false;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
      }
    }, [height]);

    // Start loop if not currently active
    const ensureAnimationRunning = useCallback(() => {
      if (!isRunningRef.current) {
        isRunningRef.current = true;
        animFrameIdRef.current = requestAnimationFrame(render);
      }
    }, [render]);

    // Resize canvas with device pixel ratio
    useEffect(() => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const dpr = window.devicePixelRatio || 1;
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
    }, [width, height]);

    // Clean up animation loop on unmount
    useEffect(() => {
      return () => {
        if (animFrameIdRef.current) {
          cancelAnimationFrame(animFrameIdRef.current);
        }
      };
    }, []);

    // Public Imperative API for triggering particle bursts
    useImperativeHandle(ref, () => ({
      spawnSuccessBurst: (stageX: number, stageY: number, category: WasteCategory, viewportX?: number, viewportY?: number) => {
        const pal = CATEGORY_PALETTES[category] || CATEGORY_PALETTES.verde;
        const mainColor = pal.primary;

        // 1. Neon Shockwaves emerging from container opening
        shockwavesRef.current.push({
          x: stageX,
          y: stageY,
          radius: 10,
          maxRadius: 90,
          color: mainColor,
          alpha: 0.95,
          lineWidth: 4.5
        });

        shockwavesRef.current.push({
          x: stageX,
          y: stageY,
          radius: 5,
          maxRadius: 65,
          color: '#ffffff',
          alpha: 0.85,
          lineWidth: 2.5
        });

        // 2. Score Floater Badge directly over container
        scoreFloatersRef.current.push({
          x: stageX,
          y: stageY - 45,
          vy: -2.8,
          text: '+10 ⭐',
          subText: '¡CORRECTO!',
          color: mainColor,
          alpha: 1,
          scale: 0.6,
          age: 0,
          maxAge: 75
        });

        // 3. Confetti Paper Strips (Fountain eruption from container mouth)
        const confettiCount = 55;
        for (let i = 0; i < confettiCount; i++) {
          // Fountain spread upwards from the container
          const angle = -Math.PI / 2 + (Math.random() - 0.5) * 1.5;
          const speed = 9 + Math.random() * 12;
          const confPair = pal.confettiColors[Math.floor(Math.random() * pal.confettiColors.length)];

          // Varying confetti shapes: rectangles, ribbons, squares
          const isRibbon = Math.random() > 0.45;
          const w = isRibbon ? 6 + Math.random() * 4 : 8 + Math.random() * 5;
          const h = isRibbon ? 12 + Math.random() * 8 : 8 + Math.random() * 5;

          particlesRef.current.push({
            type: 'confetti',
            x: stageX + (Math.random() - 0.5) * 36,
            y: stageY + (Math.random() - 0.5) * 12,
            vx: Math.cos(angle) * speed,
            vy: Math.sin(angle) * speed,
            width: w,
            height: h,
            color: confPair.front,
            backColor: confPair.back,
            alpha: 1,
            decay: 0.012 + Math.random() * 0.014,
            gravity: 0.28 + Math.random() * 0.12,
            drag: 0.975,
            rotation: Math.random() * Math.PI * 2,
            vRotation: (Math.random() - 0.5) * 0.28,
            wobble: Math.random() * Math.PI * 2,
            vWobble: 0.1 + Math.random() * 0.18
          });
        }

        // 4. Incandescent Glowing Sparks (Chispas volcánicas y eléctricas)
        const sparkCount = 45;
        for (let i = 0; i < sparkCount; i++) {
          const angle = -Math.PI / 2 + (Math.random() - 0.5) * 1.8;
          const speed = 11 + Math.random() * 13;
          const spColor = pal.sparkColors[Math.floor(Math.random() * pal.sparkColors.length)];

          particlesRef.current.push({
            type: 'spark',
            x: stageX + (Math.random() - 0.5) * 25,
            y: stageY + (Math.random() - 0.5) * 10,
            vx: Math.cos(angle) * speed,
            vy: Math.sin(angle) * speed,
            color: spColor,
            glowColor: pal.glow,
            alpha: 1,
            decay: 0.02 + Math.random() * 0.022,
            gravity: 0.35 + Math.random() * 0.15,
            drag: 0.965,
            sparklePhase: Math.random() * Math.PI * 2,
            twinkleSpeed: 0.3 + Math.random() * 0.4
          });
        }

        // 5. Eco Stars, Leaves & Sparkles
        const shapeTypes: Array<'leaf' | 'star' | 'sparkle' | 'diamond'> = [
          'leaf',
          'star',
          'sparkle',
          'diamond'
        ];
        const shapeCount = 18;
        for (let i = 0; i < shapeCount; i++) {
          const angle = -Math.PI / 2 + (Math.random() - 0.5) * 1.6;
          const speed = 7 + Math.random() * 8;
          const sh = shapeTypes[Math.floor(Math.random() * shapeTypes.length)];
          const shColor = pal.confettiColors[Math.floor(Math.random() * pal.confettiColors.length)].front;

          particlesRef.current.push({
            type: 'shape',
            shape: sh,
            x: stageX + (Math.random() - 0.5) * 20,
            y: stageY,
            vx: Math.cos(angle) * speed,
            vy: Math.sin(angle) * speed,
            size: sh === 'leaf' ? 9 + Math.random() * 5 : 7 + Math.random() * 6,
            color: shColor,
            glowColor: pal.glow,
            alpha: 1,
            decay: 0.015 + Math.random() * 0.015,
            gravity: 0.22 + Math.random() * 0.08,
            drag: 0.98,
            rotation: Math.random() * Math.PI * 2,
            vRotation: (Math.random() - 0.5) * 0.2
          });
        }

        // 6. Complementary physics confetti burst from exact container coordinates
        const originX = viewportX !== undefined ? viewportX : stageX / window.innerWidth;
        const originY = viewportY !== undefined ? viewportY : stageY / window.innerHeight;

        try {
          confetti({
            particleCount: 30,
            angle: 90,
            spread: 60,
            origin: { x: Math.max(0.05, Math.min(0.95, originX)), y: Math.max(0.05, Math.min(0.95, originY)) },
            colors: pal.confettiColors.slice(0, 5).map(c => c.front),
            startVelocity: 26,
            gravity: 0.95,
            scalar: 0.85,
            ticks: 75,
            shapes: ['circle', 'square'],
            disableForReducedMotion: true
          });
        } catch {
          // Safe fallback
        }

        ensureAnimationRunning();
      },

      spawnVictoryBlast: () => {
        // Grand victory barrage on the canvas
        const canvas = canvasRef.current;
        const w = canvas ? canvas.width / (window.devicePixelRatio || 1) : 800;
        const h = canvas ? canvas.height / (window.devicePixelRatio || 1) : 600;

        // Spawn multi-point celebratory fountains directly on the canvas
        const burstPoints = [w * 0.2, w * 0.5, w * 0.8];
        const allColors = [
          ...CATEGORY_PALETTES.verde.confettiColors,
          ...CATEGORY_PALETTES.azul.confettiColors,
          ...CATEGORY_PALETTES.gris.confettiColors,
          ...CATEGORY_PALETTES.rojo.confettiColors
        ];

        burstPoints.forEach((bx, idx) => {
          setTimeout(() => {
            for (let i = 0; i < 40; i++) {
              const angle = -Math.PI / 2 + (Math.random() - 0.5) * 1.6;
              const speed = 12 + Math.random() * 15;
              const pair = allColors[Math.floor(Math.random() * allColors.length)];

              particlesRef.current.push({
                type: 'confetti',
                x: bx + (Math.random() - 0.5) * 30,
                y: h - 40,
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed,
                width: 7 + Math.random() * 5,
                height: 12 + Math.random() * 8,
                color: pair.front,
                backColor: pair.back,
                alpha: 1,
                decay: 0.01 + Math.random() * 0.01,
                gravity: 0.26 + Math.random() * 0.1,
                drag: 0.98,
                rotation: Math.random() * Math.PI * 2,
                vRotation: (Math.random() - 0.5) * 0.3,
                wobble: Math.random() * Math.PI * 2,
                vWobble: 0.12 + Math.random() * 0.2
              });
            }

            for (let i = 0; i < 25; i++) {
              const angle = -Math.PI / 2 + (Math.random() - 0.5) * 1.8;
              const speed = 14 + Math.random() * 14;

              particlesRef.current.push({
                type: 'spark',
                x: bx,
                y: h - 40,
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed,
                color: '#facc15',
                glowColor: 'rgba(250, 204, 21, 0.8)',
                alpha: 1,
                decay: 0.018 + Math.random() * 0.018,
                gravity: 0.32,
                drag: 0.97,
                sparklePhase: Math.random() * Math.PI * 2,
                twinkleSpeed: 0.4
              });
            }
            ensureAnimationRunning();
          }, idx * 180);
        });

        // Complementary fireworks
        try {
          confetti({
            particleCount: 90,
            spread: 90,
            origin: { y: 0.65 },
            disableForReducedMotion: true
          });
        } catch {}

        ensureAnimationRunning();
      }
    }));

    return (
      <canvas
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none z-40"
        style={{ width: `${width}px`, height: `${height}px` }}
      />
    );
  }
);

ParticleCanvas.displayName = 'ParticleCanvas';
