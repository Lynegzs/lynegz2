import React, { useState } from 'react';
import { Camera, ShieldAlert, Sparkles, Volume2, VolumeX, CheckCircle, Info, Award, Smartphone, Tablet, Monitor, Infinity, Flame, Trophy, Music } from 'lucide-react';
import { GameMode } from '../types';
import { CATEGORIAS } from '../data/residuos';
import { ALL_MEDALS, getStoredUnlockedMedalIds, getUserStats } from '../data/medals';
import { MedalsModal } from './MedalsModal';
import { MusicModal } from './MusicModal';
import { sound } from '../utils/audio';
import { bgm } from '../utils/bgm';
import { MusicPlayerControl } from './MusicPlayerControl';

interface MenuScreenProps {
  onStart: (mode?: GameMode) => void;
  onCalibrate?: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const MenuScreen: React.FC<MenuScreenProps> = ({
  onStart,
  onCalibrate,
  soundEnabled,
  onToggleSound
}) => {
  const [showBinGuide, setShowBinGuide] = useState<boolean>(false);
  const [showMedalsModal, setShowMedalsModal] = useState<boolean>(false);
  const [showMusicModal, setShowMusicModal] = useState<boolean>(false);
  const [unlockedMedalIds, setUnlockedMedalIds] = useState<string[]>(() => getStoredUnlockedMedalIds());
  const userStats = getUserStats();

  return (
    <div className="flex flex-col items-center justify-center min-h-screen w-full max-w-3xl mx-auto px-3 py-3 select-none">
      {/* Top right quick controls: Sound SFX and Royalty-free BGM */}
      <div className="w-full flex flex-wrap items-center justify-between gap-1.5 mb-2">
        {/* Brand pill */}
        <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-[10px] sm:text-xs font-black tracking-wide uppercase">
          <span>♻️</span>
          <span>ATRAPA Y RECICLA</span>
        </div>

        <div className="flex items-center gap-1.5">
          {/* Quick Royalty-Free Music Pill */}
          <MusicPlayerControl compact onOpenModal={() => setShowMusicModal(true)} />

          {/* Sound FX Button */}
          <button
            onClick={onToggleSound}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition text-[11px] font-bold cursor-pointer"
          >
            {soundEnabled ? <Volume2 className="w-3.5 h-3.5 text-emerald-400" /> : <VolumeX className="w-3.5 h-3.5 text-rose-400" />}
            <span>{soundEnabled ? 'SFX: ON' : 'SFX: OFF'}</span>
          </button>
        </div>
      </div>

      {/* Main Hero Card - Compact scale */}
      <div className="w-full bg-slate-800/85 border border-slate-700/80 rounded-2xl p-4 sm:p-6 shadow-2xl backdrop-blur-md flex flex-col items-center text-center">
        {/* Animated Recycling Icon Badge */}
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center shadow-lg shadow-emerald-500/25 mb-2 transform hover:rotate-12 transition-transform">
          <span className="text-2xl">♻️</span>
        </div>

        {/* Title */}
        <h1 className="text-2xl sm:text-3xl md:text-4xl font-black text-white tracking-tight uppercase">
          ATRAPA Y RECICLA
        </h1>

        {/* Tagline */}
        <p className="text-xs sm:text-sm text-emerald-400 font-bold tracking-wide mt-0.5">
          "Atrapa, arrastra y clasifica residuos jugando en cualquier dispositivo"
        </p>
        <p className="text-[11px] sm:text-xs text-slate-400 max-w-md mt-0.5 leading-snug">
          Supera <strong>10 niveles progresivos</strong> o desafía el <strong>Modo Infinito</strong> con 160 residuos reales. Clasifica por su color sin logos. ¡3 fallos y reinicias!
        </p>

        {/* Multiplatform Device Badge */}
        <div className="flex flex-wrap items-center justify-center gap-2 mt-2 px-2.5 py-0.5 rounded-full bg-slate-900/90 border border-emerald-500/30 text-[10px] sm:text-[11px] font-bold text-slate-300">
          <span className="flex items-center gap-1 text-emerald-400">
            <Smartphone className="w-3 h-3" />
            <span>Celular</span>
          </span>
          <span className="text-slate-600">•</span>
          <span className="flex items-center gap-1 text-teal-400">
            <Tablet className="w-3 h-3" />
            <span>Tablet</span>
          </span>
          <span className="text-slate-600">•</span>
          <span className="flex items-center gap-1 text-sky-400">
            <Monitor className="w-3 h-3" />
            <span>Computadora</span>
          </span>
        </div>

        {/* 4 Mini Bins preview (Pure colors without logos) */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 my-2.5 w-full max-w-md">
          <div className="flex items-center gap-1.5 p-1.5 rounded-lg bg-emerald-950/40 border border-emerald-500/30 text-left">
            <span className="w-3 h-3 rounded-full bg-emerald-500 shadow-sm shrink-0" />
            <div>
              <div className="text-[11px] font-black text-emerald-300 uppercase leading-tight">Orgánicos</div>
              <div className="text-[9px] text-slate-400">Verde</div>
            </div>
          </div>
          <div className="flex items-center gap-1.5 p-1.5 rounded-lg bg-blue-950/40 border border-blue-500/30 text-left">
            <span className="w-3 h-3 rounded-full bg-blue-500 shadow-sm shrink-0" />
            <div>
              <div className="text-[11px] font-black text-blue-300 uppercase leading-tight">Reciclables</div>
              <div className="text-[9px] text-slate-400">Azul</div>
            </div>
          </div>
          <div className="flex items-center gap-1.5 p-1.5 rounded-lg bg-slate-950/40 border border-slate-500/30 text-left">
            <span className="w-3 h-3 rounded-full bg-slate-400 shadow-sm shrink-0" />
            <div>
              <div className="text-[11px] font-black text-slate-300 uppercase leading-tight">No Aprov.</div>
              <div className="text-[9px] text-slate-400">Gris</div>
            </div>
          </div>
          <div className="flex items-center gap-1.5 p-1.5 rounded-lg bg-red-950/40 border border-red-500/30 text-left">
            <span className="w-3 h-3 rounded-full bg-red-500 shadow-sm shrink-0" />
            <div>
              <div className="text-[11px] font-black text-red-300 uppercase leading-tight">Peligrosos</div>
              <div className="text-[9px] text-slate-400">Rojo</div>
            </div>
          </div>
        </div>

        {/* Game Mode Buttons (Levels Mode & Infinite Mode) */}
        <div className="w-full max-w-sm space-y-2">
          {/* 1. Modo Niveles */}
          <button
            id="btn-comenzar-juego"
            onClick={() => {
              sound.playGrab();
              bgm.playTrackForLevel(1);
              onStart('levels');
            }}
            className="w-full flex items-center justify-center gap-2.5 px-4 py-2.5 rounded-xl font-black text-xs sm:text-sm uppercase tracking-wide bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 shadow-lg shadow-emerald-500/20 hover:scale-[1.01] active:scale-[0.99] transition cursor-pointer"
          >
            <Camera className="w-4 h-4 shrink-0" />
            <span>MODO NIVELES (1 - 10)</span>
          </button>

          {/* 2. Modo Infinito */}
          <button
            id="btn-modo-infinito"
            onClick={() => {
              sound.playGrab();
              bgm.startInfiniteModeShuffle();
              onStart('infinite');
            }}
            className="w-full flex items-center justify-center gap-2.5 px-4 py-2.5 rounded-xl font-black text-xs sm:text-sm uppercase tracking-wide bg-gradient-to-r from-purple-600 via-pink-500 to-amber-500 hover:from-purple-500 hover:to-amber-400 text-white shadow-lg shadow-purple-500/20 hover:scale-[1.01] active:scale-[0.99] transition cursor-pointer border border-white/20"
          >
            <Infinity className="w-4 h-4 shrink-0 text-amber-300 animate-spin" style={{ animationDuration: '8s' }} />
            <div className="flex flex-col items-start text-left leading-tight">
              <span>MODO INFINITO ♾️</span>
              <span className="text-[9px] font-semibold text-amber-200 normal-case tracking-normal">
                160 residuos • 10 canciones aleatorias • Sin fin
              </span>
            </div>
            <Flame className="w-4 h-4 text-amber-300 fill-amber-400 ml-auto shrink-0" />
          </button>

          {/* Record banner if infinite mode has been played */}
          {(userStats.bestInfiniteScore || 0) > 0 && (
            <div className="flex items-center justify-between px-3 py-1 rounded-lg bg-purple-950/50 border border-purple-500/30 text-[11px]">
              <span className="text-purple-300 font-bold flex items-center gap-1">
                <Trophy className="w-3 h-3 text-amber-400" />
                <span>Récord Infinito:</span>
              </span>
              <span className="text-amber-300 font-black">
                {userStats.bestInfiniteScore} pts (Racha x{userStats.bestInfiniteStreak || 0} 🔥)
              </span>
            </div>
          )}
        </div>

        {/* Secondary Info, Music Showcase & Optional Calibration Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-1.5 mt-2.5">
          {/* Dedicated Music Modal Trigger */}
          <button
            id="btn-abrir-musica"
            onClick={() => {
              sound.playGrab();
              setShowMusicModal(true);
            }}
            className="flex items-center gap-1 text-[11px] font-bold text-teal-300 hover:text-white px-2.5 py-1 rounded-lg bg-teal-500/20 hover:bg-teal-500/30 border border-teal-500/40 transition cursor-pointer shadow-sm hover:scale-[1.01] active:scale-[0.99]"
          >
            <Music className="w-3.5 h-3.5 text-teal-400" />
            <span>🎵 Banda Sonora (10)</span>
          </button>

          {onCalibrate && (
            <button
              onClick={() => {
                sound.playGrab();
                onCalibrate();
              }}
              className="flex items-center gap-1 text-[11px] font-bold text-emerald-300 hover:text-white px-2.5 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 transition cursor-pointer"
            >
              <span>📷 Calibrar Cámara</span>
            </button>
          )}

          <button
            onClick={() => setShowBinGuide(!showBinGuide)}
            className="flex items-center gap-1 text-[11px] font-bold text-slate-300 hover:text-white px-2.5 py-1 rounded-lg bg-slate-700/50 hover:bg-slate-700 transition cursor-pointer"
          >
            <Info className="w-3.5 h-3.5 text-emerald-400" />
            <span>Guía de Residuos</span>
          </button>

          <button
            onClick={() => {
              sound.playGrab();
              setUnlockedMedalIds(getStoredUnlockedMedalIds());
              setShowMedalsModal(true);
            }}
            className="flex items-center gap-1 text-[11px] font-bold text-amber-300 hover:text-amber-100 px-2.5 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 transition cursor-pointer"
          >
            <Award className="w-3.5 h-3.5 text-amber-400" />
            <span>🏅 Medallas ({unlockedMedalIds.length}/{ALL_MEDALS.length})</span>
          </button>
        </div>

        {/* Bin Guide Accordion */}
        {showBinGuide && (
          <div className="w-full max-w-md bg-slate-900/90 border border-slate-700 rounded-xl p-3 mt-2 text-left animate-fade-in">
            <h3 className="text-xs font-black text-emerald-400 uppercase tracking-wider mb-1.5">
              Guía Oficial de Clasificación
            </h3>
            <div className="space-y-1 text-[11px]">
              <div className="p-1.5 rounded-lg bg-emerald-950/30 border border-emerald-500/30">
                <strong className="text-emerald-300">🟢 VERDE (Orgánicos):</strong> Cáscara de banana 🍌, Manzana 🍎, Restos 🍽️.
              </div>
              <div className="p-1.5 rounded-lg bg-blue-950/30 border border-blue-500/30">
                <strong className="text-blue-300">🔵 AZUL (Reciclables):</strong> Plástico 🧴, Lata 🥫, Vidrio 🍾, Cartón 📦, Papel 📰.
              </div>
              <div className="p-1.5 rounded-lg bg-slate-800 border border-slate-600">
                <strong className="text-slate-300">⚫ GRIS (No aprovechables):</strong> Servilleta usada 🧻, Vidrio roto 🪟.
              </div>
              <div className="p-1.5 rounded-lg bg-red-950/30 border border-red-500/30">
                <strong className="text-red-300">🔴 ROJO (Peligrosos):</strong> Pilas 🔋, Jeringas 💉.
              </div>
            </div>
          </div>
        )}

        {/* Privacy Note */}
        <div className="mt-2.5 text-[10px] text-slate-400 max-w-sm flex items-center justify-center gap-1">
          <ShieldAlert className="w-3 h-3 text-emerald-400 shrink-0" />
          <span>Privacidad 100% local: El video se procesa en tu navegador. No se guardan imágenes.</span>
        </div>
      </div>

      {/* Medals Showcase Modal */}
      {showMedalsModal && (
        <MedalsModal
          unlockedMedalIds={unlockedMedalIds}
          onClose={() => {
            setUnlockedMedalIds(getStoredUnlockedMedalIds());
            setShowMedalsModal(false);
          }}
          onStatsReset={() => setUnlockedMedalIds([])}
        />
      )}

      {/* Music Showcase / Jukebox Modal */}
      {showMusicModal && (
        <MusicModal
          onClose={() => setShowMusicModal(false)}
        />
      )}
    </div>
  );
};
