import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { GameLevel, RoundResult } from '../types';
import { Trophy, RotateCcw, ArrowRight, Home, CheckCircle2, XCircle, Heart, Award, Sparkles } from 'lucide-react';

interface LevelFeedbackModalProps {
  type: 'level_success' | 'level_failed' | 'game_victory';
  level: GameLevel;
  levelNumber: number;
  totalLevels: number;
  score: number;
  levelErrors: number;
  livesRemaining: number;
  maxLives: number;
  levelHistory: RoundResult[];
  onNextLevel: () => void;
  onRestartLevel: () => void;
  onRestartEntireGame: () => void;
  onGoHome: () => void;
  onShowMedals?: () => void;
}

export const LevelFeedbackModal: React.FC<LevelFeedbackModalProps> = ({
  type,
  level,
  levelNumber,
  totalLevels,
  score,
  levelErrors,
  livesRemaining,
  maxLives,
  levelHistory,
  onNextLevel,
  onRestartLevel,
  onRestartEntireGame,
  onGoHome,
  onShowMedals
}) => {
  const isVictory = type === 'level_success';
  const isFailed = type === 'level_failed';
  const isGameWon = type === 'game_victory';

  useEffect(() => {
    if (isVictory || isGameWon) {
      try {
        confetti({
          particleCount: isGameWon ? 110 : 60,
          spread: isGameWon ? 90 : 65,
          origin: { y: 0.55 },
          disableForReducedMotion: true
        });
      } catch {
        // Fallback
      }
    }
  }, [isVictory, isGameWon]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/85 backdrop-blur-md select-none animate-fade-in">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-2xl p-4 sm:p-5 shadow-2xl flex flex-col items-center text-center max-h-[92vh] overflow-y-auto">
        {/* Header Icon */}
        {isGameWon && (
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-400 via-yellow-300 to-amber-500 flex items-center justify-center shadow-lg shadow-amber-500/30 mb-2 animate-bounce">
            <Trophy className="w-7 h-7 text-slate-950" />
          </div>
        )}

        {isVictory && (
          <div className="w-12 h-12 rounded-xl bg-emerald-500/20 border border-emerald-400 flex items-center justify-center shadow-md shadow-emerald-500/30 mb-2">
            <Sparkles className="w-6 h-6 text-emerald-400 animate-spin-slow" />
          </div>
        )}

        {isFailed && (
          <div className="w-12 h-12 rounded-xl bg-rose-500/20 border border-rose-500 flex items-center justify-center shadow-md shadow-rose-500/30 mb-2">
            <RotateCcw className="w-6 h-6 text-rose-400 animate-pulse" />
          </div>
        )}

        {/* Title and Subtitle */}
        {isGameWon && (
          <>
            <h1 className="text-2xl sm:text-3xl font-black text-amber-300 uppercase tracking-tight">
              🏆 ¡HAS GANADO EL JUEGO!
            </h1>
            <p className="text-xs font-bold text-amber-100/90 mt-0.5">
              ¡Completaste los 10 niveles de clasificación en Realidad Aumentada!
            </p>
          </>
        )}

        {isVictory && (
          <>
            <div className="inline-flex items-center gap-1 px-2 py-0.2 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-extrabold text-[10px] uppercase tracking-wider mb-1">
              <span>Nivel {levelNumber} de {totalLevels}</span>
              <span>•</span>
              <span>{level.difficulty}</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white uppercase tracking-tight">
              ¡NIVEL {levelNumber} SUPERADO! 🎉
            </h1>
            <p className="text-[11px] text-slate-300 mt-0.5">
              {level.title} — Clasificaste los 10 objetos con éxito.
            </p>
          </>
        )}

        {isFailed && (
          <>
            <div className="inline-flex items-center gap-1 px-2 py-0.2 rounded-full bg-rose-500/20 border border-rose-500/40 text-rose-300 font-extrabold text-[10px] uppercase tracking-wider mb-1">
              <span>Nivel {levelNumber} • {level.difficulty}</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-rose-400 uppercase tracking-tight">
              ¡NIVEL FALLIDO! 💥
            </h1>
            <p className="text-[11px] text-slate-300 mt-0.5 max-w-sm">
              Agotaste tus vidas al cometer errores en este nivel. Para avanzar debes reiniciar y clasificar los 10 objetos correctamente.
            </p>
          </>
        )}

        {/* Metrics Grid */}
        <div className="grid grid-cols-3 gap-2 w-full my-3">
          <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-2 flex flex-col items-center">
            <span className="text-[10px] font-extrabold text-slate-400 uppercase">Objetos</span>
            <span className="text-xl sm:text-2xl font-black text-white mt-0.5">10/10</span>
            <span className="text-[9px] text-slate-400 font-medium">clasificados</span>
          </div>

          <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-2 flex flex-col items-center">
            <span className="text-[10px] font-extrabold text-slate-400 uppercase">Vidas</span>
            <div className="flex items-center gap-0.5 mt-0.5 text-sm">
              {Array.from({ length: maxLives }).map((_, i) => (
                <span key={i} className={i < livesRemaining ? 'text-rose-500' : 'text-slate-600 opacity-40'}>
                  ❤️
                </span>
              ))}
            </div>
            <span className="text-[9px] text-slate-400 font-medium mt-0.5">{livesRemaining} de {maxLives}</span>
          </div>

          <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-2 flex flex-col items-center">
            <span className="text-[10px] font-extrabold text-emerald-400 uppercase">Puntaje</span>
            <span className="text-xl sm:text-2xl font-black text-emerald-400 mt-0.5">{score}</span>
            <span className="text-[9px] text-slate-400 font-medium">puntos acum.</span>
          </div>
        </div>

        {/* Milestone achievement badge callout */}
        {(isVictory || isGameWon) && levelErrors === 0 && livesRemaining === maxLives && (
          <div className="w-full -mt-1 mb-2.5 p-2 rounded-xl bg-gradient-to-r from-amber-500/20 via-yellow-500/15 to-amber-500/20 border border-amber-400/50 text-amber-200 text-[11px] font-bold flex items-center justify-center gap-2 shadow-sm">
            <span className="text-base">✨</span>
            <div>
              <span className="font-black text-amber-300 uppercase tracking-wide mr-1">¡Nivel Impecable!</span>
              <span>0 errores y 3 vidas intactas.</span>
            </div>
          </div>
        )}

        {/* Educational Review of the 10 Items */}
        <div className="w-full bg-slate-950/70 rounded-xl p-2.5 border border-slate-800 mb-3 text-left">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider">
              {isFailed ? '⚠️ Errores cometidos:' : '📋 Resumen de los 10 objetos:'}
            </span>
            <span className="text-[9px] text-slate-500 font-bold">
              {levelHistory.filter((h) => h.isCorrect).length} aciertos / {levelHistory.filter((h) => !h.isCorrect).length} fallos
            </span>
          </div>

          <div className="space-y-1 max-h-32 overflow-y-auto pr-1">
            {levelHistory.map((item, idx) => (
              <div
                key={idx}
                className={`p-1.5 rounded-lg text-xs flex items-center gap-1.5 border ${
                  item.isCorrect
                    ? 'bg-emerald-500/10 border-emerald-500/25 text-emerald-200'
                    : 'bg-rose-500/15 border-rose-500/30 text-rose-200'
                }`}
              >
                <span className="text-base shrink-0 leading-none">{item.item.emoji}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1">
                    <span className="font-bold text-[11px] truncate">{item.item.nombre}</span>
                    <span className="text-[9px] px-1 py-0.2 rounded font-extrabold uppercase shrink-0">
                      {item.isCorrect ? '✅ Acertado' : '❌ Fallado'}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-1.5 w-full justify-center">
          {/* If failed, primary action is Restart Level */}
          {isFailed && (
            <button
              onClick={onRestartLevel}
              className="flex-1 flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl font-black text-xs sm:text-sm uppercase tracking-wider bg-rose-500 hover:bg-rose-400 text-white shadow-md shadow-rose-500/25 hover:scale-[1.01] transition cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>🔄 REINICIAR NIVEL {levelNumber}</span>
            </button>
          )}

          {/* If victory on a level < 10, primary action is Next Level */}
          {isVictory && levelNumber < totalLevels && (
            <button
              onClick={onNextLevel}
              className="flex-1 flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl font-black text-xs sm:text-sm uppercase tracking-wider bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-md shadow-emerald-500/25 hover:scale-[1.01] transition cursor-pointer"
            >
              <span>SIGUIENTE NIVEL ({levelNumber + 1})</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          )}

          {/* If full game won */}
          {isGameWon && (
            <button
              onClick={onRestartEntireGame}
              className="flex-1 flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl font-black text-xs sm:text-sm uppercase tracking-wider bg-amber-400 hover:bg-amber-300 text-slate-950 shadow-md shadow-amber-500/30 hover:scale-[1.01] transition cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>JUGAR DE NUEVO (NIVEL 1)</span>
            </button>
          )}

          {/* Medals and Achievements button */}
          {onShowMedals && (
            <button
              onClick={onShowMedals}
              className="px-3 py-2 rounded-xl font-bold text-xs uppercase tracking-wider bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 hover:scale-[1.01] transition cursor-pointer flex items-center justify-center gap-1"
              title="Ver Logros y Medallas Desbloqueadas"
            >
              <Award className="w-3.5 h-3.5 text-amber-400" />
              <span>LOGROS</span>
            </button>
          )}

          {/* Menu navigation button */}
          <button
            onClick={onGoHome}
            className="px-4 py-2 rounded-xl font-bold text-xs uppercase tracking-wider bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 hover:scale-[1.01] transition cursor-pointer flex items-center justify-center gap-1.5"
          >
            <Home className="w-3.5 h-3.5" />
            <span>MENÚ</span>
          </button>
        </div>
      </div>
    </div>
  );
};
