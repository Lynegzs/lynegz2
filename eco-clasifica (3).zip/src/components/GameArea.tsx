import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { WasteItem, WasteCategory, RoundResult, Medal, GameMode } from '../types';
import { NIVELES_JUEGO, CATEGORIAS, TODOS_LOS_RESIDUOS, createInfiniteDeck } from '../data/residuos';
import { ALL_MEDALS, getStoredUnlockedMedalIds, saveUnlockedMedalId, recordItemClassified, recordLevelResult, recordInfiniteGameResult, getUserStats } from '../data/medals';
import { RecyclingBin } from './RecyclingBin';
import { WasteItemCard } from './WasteItemCard';
import { HandCursor } from './HandCursor';
import { LevelFeedbackModal } from './LevelFeedbackModal';
import { InfiniteGameOverModal } from './InfiniteGameOverModal';
import { ParticleCanvas, ParticleEffectHandle } from './ParticleEffects';
import { MedalNotification } from './MedalNotification';
import { MedalsModal } from './MedalsModal';
import { MusicModal } from './MusicModal';
import { StreakCounter } from './StreakCounter';
import { calculateStreakMultiplier } from '../utils/streak';
import { sound } from '../utils/audio';
import { bgm } from '../utils/bgm';
import { CheckCircle2, XCircle, AlertCircle, Volume2, VolumeX, Settings2, Award, Camera, RefreshCw, Infinity, Flame, Zap, Play, Pause, Music } from 'lucide-react';

interface GameAreaProps {
  handDetected: boolean;
  normX: number;
  normY: number;
  isPinching: boolean;
  pinchDistance: number;
  videoRef: React.RefObject<HTMLVideoElement | null>;
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
  onGameOver: (score: number, errors: number, history: RoundResult[]) => void;
  onExitToMenu: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onReCalibrate: () => void;
  onSwitchCamera?: () => Promise<void>;
  facingMode?: 'user' | 'environment';
  initialMode?: GameMode;
}

export const GameArea: React.FC<GameAreaProps> = ({
  handDetected,
  normX,
  normY,
  isPinching,
  pinchDistance,
  videoRef,
  canvasRef,
  onGameOver,
  onExitToMenu,
  soundEnabled,
  onToggleSound,
  onReCalibrate,
  onSwitchCamera,
  facingMode = 'user',
  initialMode = 'levels'
}) => {
  // Game Mode: 'levels' (10 levels of 10 items) vs 'infinite' (160 items endless)
  const [gameMode, setGameMode] = useState<GameMode>(initialMode);

  // Game Levels Management (10 Levels with 10 Objects each)
  const TOTAL_LEVELS = NIVELES_JUEGO.length; // 10
  const ITEMS_PER_LEVEL = 10;
  const MAX_LIVES = 3;

  const [currentLevelIndex, setCurrentLevelIndex] = useState<number>(0);
  const currentLevel = NIVELES_JUEGO[currentLevelIndex];

  // Item within current level (0 to 9)
  const [itemIndexInLevel, setItemIndexInLevel] = useState<number>(0);

  // Infinite mode state & deck (drawing from all 160 items)
  const infiniteDeckRef = useRef<WasteItem[]>(createInfiniteDeck());
  const [infiniteSortedCount, setInfiniteSortedCount] = useState<number>(0);
  const infiniteSortedCountRef = useRef<number>(0);
  infiniteSortedCountRef.current = infiniteSortedCount;

  const [infiniteCurrentItem, setInfiniteCurrentItem] = useState<WasteItem>(() => {
    return infiniteDeckRef.current.shift() || TODOS_LOS_RESIDUOS[0];
  });
  const [bestInfiniteScore, setBestInfiniteScore] = useState<number>(() => getUserStats().bestInfiniteScore || 0);
  const bestStreakInSessionRef = useRef<number>(0);
  const [isNewInfiniteRecord, setIsNewInfiniteRecord] = useState<boolean>(false);
  const [bonusLifeEarned, setBonusLifeEarned] = useState<boolean>(false);

  // Current active item according to mode
  const currentItem = gameMode === 'infinite' ? infiniteCurrentItem : currentLevel.items[itemIndexInLevel];

  // Performance metrics for current level and overall
  const [levelLives, setLevelLives] = useState<number>(MAX_LIVES);
  const [levelErrors, setLevelErrors] = useState<number>(0);
  const [totalScore, setTotalScore] = useState<number>(0);
  const totalScoreRef = useRef<number>(0);
  totalScoreRef.current = totalScore;
  const [levelHistory, setLevelHistory] = useState<RoundResult[]>([]);
  const [globalHistory, setGlobalHistory] = useState<RoundResult[]>([]);

  // Grabbing state for AR hand tracking
  const [isGrabbed, setIsGrabbed] = useState<boolean>(false);
  const [isSwitchingCam, setIsSwitchingCam] = useState<boolean>(false);

  // Stage dimensions and home anchor position for the waste item
  const [stageSize, setStageSize] = useState<{ width: number; height: number }>({ width: 800, height: 600 });
  const [homePos, setHomePos] = useState<{ x: number; y: number }>({ x: 400, y: 220 });

  // Cached DOM Rects to prevent expensive synchronous reflows on drag
  const stageRectRef = useRef<DOMRect | null>(null);
  const binRectsRef = useRef<Record<WasteCategory, { left: number; right: number; top: number; bottom: number } | null>>({
    verde: null,
    azul: null,
    gris: null,
    rojo: null
  });

  // Stable tracking refs
  const currentItemRef = useRef(currentItem);
  currentItemRef.current = currentItem;
  const currentLevelIndexRef = useRef(currentLevelIndex);
  currentLevelIndexRef.current = currentLevelIndex;
  const itemIndexInLevelRef = useRef(itemIndexInLevel);
  itemIndexInLevelRef.current = itemIndexInLevel;
  const levelLivesRef = useRef(levelLives);
  levelLivesRef.current = levelLives;
  const levelErrorsRef = useRef(levelErrors);
  levelErrorsRef.current = levelErrors;
  const gameModeRef = useRef<GameMode>(gameMode);
  gameModeRef.current = gameMode;

  // Latch flag to ensure grabbing requires a deliberate pinch cycle
  const canGrabRef = useRef<boolean>(true);

  // Round resolution state protection against double responses
  const rondaProcesadaRef = useRef<boolean>(false);
  const [roundFeedback, setRoundFeedback] = useState<{
    status: 'correct' | 'incorrect' | null;
    message: string;
    detail?: string;
  } | null>(null);

  // Informative toast when released outside bins
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Modal states: null | 'level_success' | 'level_failed' | 'game_victory' | 'infinite_game_over'
  const [activeModal, setActiveModal] = useState<'level_success' | 'level_failed' | 'game_victory' | 'infinite_game_over' | null>(null);

  // Medals & Achievements state
  const [unlockedMedalIds, setUnlockedMedalIds] = useState<string[]>(() => getStoredUnlockedMedalIds());
  const [medalQueue, setMedalQueue] = useState<Medal[]>([]);
  const [showMedalsModal, setShowMedalsModal] = useState<boolean>(false);
  const [showMusicModal, setShowMusicModal] = useState<boolean>(false);
  const [isMusicPlaying, setIsMusicPlaying] = useState<boolean>(() => bgm.getIsPlaying());

  useEffect(() => {
    const unsub = bgm.subscribe(() => {
      setIsMusicPlaying(bgm.getIsPlaying());
    });
    return unsub;
  }, []);

  // Consecutive streak tracking & speed counter
  const consecutiveCorrectRef = useRef<number>(0);
  const [streak, setStreak] = useState<number>(0);
  const [lastPointsNotification, setLastPointsNotification] = useState<{
    points: number;
    multiplier: number;
    id: number;
  } | null>(null);
  const itemSpawnTimeRef = useRef<number>(Date.now());

  // Auto-dismiss floating score notification after animation
  useEffect(() => {
    if (lastPointsNotification) {
      const timer = setTimeout(() => {
        setLastPointsNotification(null);
      }, 1600);
      return () => clearTimeout(timer);
    }
  }, [lastPointsNotification]);

  // Function to unlock medals with fanfare and queue for visual CSS animation banner
  const awardMedal = useCallback((medalId: string) => {
    setUnlockedMedalIds((currentUnlocked) => {
      if (currentUnlocked.includes(medalId)) return currentUnlocked;
      const updated = saveUnlockedMedalId(medalId);
      const medal = ALL_MEDALS.find((m) => m.id === medalId);
      if (medal) {
        sound.playMedalUnlocked();
        setMedalQueue((prevQueue) => [...prevQueue, medal]);
      }
      return updated;
    });
  }, []);

  const handleDismissMedal = useCallback((medalId: string) => {
    setMedalQueue((prev) => prev.filter((m) => m.id !== medalId));
  }, []);

  // Update item spawn time whenever the level or item changes
  useEffect(() => {
    itemSpawnTimeRef.current = Date.now();
  }, [currentLevelIndex, itemIndexInLevel]);

  // Container refs for hit-testing / intersections
  const stageRef = useRef<HTMLDivElement | null>(null);
  const delimitedAreaRef = useRef<HTMLDivElement | null>(null);
  const particleRef = useRef<ParticleEffectHandle | null>(null);
  const [lastDropFeedback, setLastDropFeedback] = useState<{
    bin: WasteCategory;
    status: 'correct' | 'incorrect';
  } | null>(null);

  const binRefs = useRef<Record<WasteCategory, HTMLDivElement | null>>({
    verde: null,
    azul: null,
    gris: null,
    rojo: null
  });

  // Adaptive waste item dimensions: compact scale for 100% zoom
  const isMobile = stageSize.width < 640;
  const ITEM_WIDTH = isMobile ? 80 : 92;
  const ITEM_HEIGHT = isMobile ? 80 : 92;

  // Cache bin rects relative to stage to avoid reflows during drag
  const updateCachedRects = useCallback(() => {
    if (!stageRef.current) return;
    const stageRect = stageRef.current.getBoundingClientRect();
    stageRectRef.current = stageRect;
    setStageSize({ width: stageRect.width, height: stageRect.height });

    if (delimitedAreaRef.current) {
      const areaRect = delimitedAreaRef.current.getBoundingClientRect();
      const centerX = areaRect.left - stageRect.left + areaRect.width / 2;
      const centerY = areaRect.top - stageRect.top + areaRect.height / 2;
      setHomePos({ x: centerX, y: centerY });
    } else {
      setHomePos({ x: stageRect.width / 2, y: stageRect.height * 0.35 });
    }

    const categories: WasteCategory[] = ['verde', 'azul', 'gris', 'rojo'];
    for (const cat of categories) {
      const el = binRefs.current[cat];
      if (el) {
        const r = el.getBoundingClientRect();
        binRectsRef.current[cat] = {
          left: r.left,
          right: r.right,
          top: r.top,
          bottom: r.bottom
        };
      }
    }
  }, []);

  // Compute stage center inside the single delimited area on mount & resize
  useEffect(() => {
    updateCachedRects();
    window.addEventListener('resize', updateCachedRects);
    return () => window.removeEventListener('resize', updateCachedRects);
  }, [updateCachedRects]);

  // Virtual cursor positions derived directly from normalized coordinates
  const cursorPos = useMemo(() => {
    const cx = Math.max(15, Math.min(stageSize.width - 15, normX * stageSize.width));
    const cy = Math.max(15, Math.min(stageSize.height - 15, normY * stageSize.height));
    return { x: cx, y: cy };
  }, [normX, normY, stageSize.width, stageSize.height]);

  // Clamp waste position strictly keeping it within visible stage
  const clampedWastePos = useMemo(() => {
    const minX = ITEM_WIDTH / 2 + 10;
    const maxX = stageSize.width - ITEM_WIDTH / 2 - 10;
    const minY = ITEM_HEIGHT / 2 + 10;
    const maxY = stageSize.height - ITEM_HEIGHT / 2 - 10;

    return {
      x: Math.max(minX, Math.min(cursorPos.x, maxX)),
      y: Math.max(minY, Math.min(cursorPos.y, maxY))
    };
  }, [cursorPos.x, cursorPos.y, stageSize.width, stageSize.height, ITEM_WIDTH, ITEM_HEIGHT]);

  // The active rendered position of the waste item (follows hand cursor when grabbed, sits at homePos when idle)
  const wastePos = useMemo(() => {
    if (isGrabbed) {
      return clampedWastePos;
    }
    return homePos;
  }, [isGrabbed, clampedWastePos, homePos]);

  // Ref tracking latest waste position so grab/release logic never causes dependency loops
  const wastePosRef = useRef(wastePos);
  wastePosRef.current = wastePos;

  // Proximity to waste item (for AR hand pinch)
  const distToWaste = Math.hypot(cursorPos.x - homePos.x, cursorPos.y - homePos.y);
  const isHoveringWaste = !isGrabbed && distToWaste < 85;

  // Optimized helper to test intersection between Waste Item and a Container using cached rects
  const checkIntersectionWithBin = useCallback(
    (wasteX: number, wasteY: number): WasteCategory | null => {
      const stageRect = stageRectRef.current || (stageRef.current ? stageRef.current.getBoundingClientRect() : null);
      if (!stageRect) return null;

      const wasteLeft = stageRect.left + wasteX - ITEM_WIDTH / 2;
      const wasteRight = stageRect.left + wasteX + ITEM_WIDTH / 2;
      const wasteTop = stageRect.top + wasteY - ITEM_HEIGHT / 2;
      const wasteBottom = stageRect.top + wasteY + ITEM_HEIGHT / 2;

      const categories: WasteCategory[] = ['verde', 'azul', 'gris', 'rojo'];
      for (const cat of categories) {
        let binRect = binRectsRef.current[cat];
        if (!binRect) {
          const binEl = binRefs.current[cat];
          if (binEl) {
            const r = binEl.getBoundingClientRect();
            binRect = { left: r.left, right: r.right, top: r.top, bottom: r.bottom };
            binRectsRef.current[cat] = binRect;
          }
        }
        if (!binRect) continue;

        const targetLeft = binRect.left - 20;
        const targetRight = binRect.right + 20;
        const targetTop = binRect.top - 30;
        const targetBottom = binRect.bottom + 30;

        const overlapX = Math.max(0, Math.min(wasteRight, targetRight) - Math.max(wasteLeft, targetLeft));
        const overlapY = Math.max(0, Math.min(wasteBottom, targetBottom) - Math.max(wasteTop, targetTop));

        if (overlapX > 25 && overlapY > 25) {
          return cat;
        }
      }
      return null;
    },
    [ITEM_WIDTH, ITEM_HEIGHT]
  );

  // Draw next item in Infinite Mode from the 160-item pool
  const drawNextInfiniteItem = useCallback(() => {
    if (infiniteDeckRef.current.length < 10) {
      const curId = currentItemRef.current.id;
      const fresh = createInfiniteDeck().filter((i) => i.id !== curId);
      infiniteDeckRef.current = [...infiniteDeckRef.current, ...fresh];
    }
    const nextItem = infiniteDeckRef.current.shift() || TODOS_LOS_RESIDUOS[0];
    setInfiniteCurrentItem(nextItem);
    itemSpawnTimeRef.current = Date.now();
  }, []);

  // Handle release of waste item into container or outside
  const handleRelease = useCallback((releaseX: number, releaseY: number) => {
    setIsGrabbed(false);
    canGrabRef.current = false;
    sound.playRelease();

    const targetedBin = checkIntersectionWithBin(releaseX, releaseY);

    if (!targetedBin) {
      setToastMessage('Lleva el residuo hacia uno de los 4 contenedores abajo.');
      return;
    }

    if (rondaProcesadaRef.current) return;
    rondaProcesadaRef.current = true;

    const curItem = currentItemRef.current;
    const curLevelIdx = currentLevelIndexRef.current;
    const curItemIdx = itemIndexInLevelRef.current;
    const curLives = levelLivesRef.current;
    const curErrors = levelErrorsRef.current;
    const currentMode = gameModeRef.current;

    const isCorrect = targetedBin === curItem.categoria;
    const correctInfo = CATEGORIAS[curItem.categoria];
    const chosenInfo = CATEGORIAS[targetedBin];

    let updatedLives = isCorrect ? curLives : Math.max(0, curLives - 1);
    const updatedErrors = isCorrect ? curErrors : curErrors + 1;

    // Haptic vibration feedback for mobile and tablet devices
    if ('vibrate' in navigator) {
      try {
        if (isCorrect) {
          navigator.vibrate([35, 45, 60]);
        } else {
          navigator.vibrate([80, 50, 90]);
        }
      } catch {}
    }

    // Calculate bin stage coordinates and viewport ratios for particles & confetti
    const binEl = binRefs.current[targetedBin];
    let particleX = releaseX;
    let particleY = releaseY;
    let viewportX: number | undefined = undefined;
    let viewportY: number | undefined = undefined;

    if (binEl && stageRef.current) {
      const stageRect = stageRef.current.getBoundingClientRect();
      const binRect = binEl.getBoundingClientRect();
      particleX = (binRect.left + binRect.width / 2) - stageRect.left;
      particleY = (binRect.top + binRect.height * 0.12) - stageRect.top;
      viewportX = (binRect.left + binRect.width / 2) / window.innerWidth;
      viewportY = (binRect.top + binRect.height * 0.12) / window.innerHeight;
    }

    setLastDropFeedback({
      bin: targetedBin,
      status: isCorrect ? 'correct' : 'incorrect'
    });

    const elapsedSeconds = (Date.now() - itemSpawnTimeRef.current) / 1000;
    const isToxic = curItem.categoria === 'rojo';

    if (isCorrect) {
      const newStreak = consecutiveCorrectRef.current + 1;
      consecutiveCorrectRef.current = newStreak;
      setStreak(newStreak);
      bestStreakInSessionRef.current = Math.max(bestStreakInSessionRef.current, newStreak);

      const multiplier = calculateStreakMultiplier(newStreak);
      const pointsAwarded = Math.round(10 * multiplier);

      setTotalScore((prev) => prev + pointsAwarded);
      setLastPointsNotification({
        points: pointsAwarded,
        multiplier,
        id: Date.now()
      });

      // Infinite Mode progression & bonus life
      if (currentMode === 'infinite') {
        setInfiniteSortedCount((c) => c + 1);
        if (newStreak > 0 && newStreak % 15 === 0 && updatedLives < MAX_LIVES) {
          updatedLives = Math.min(MAX_LIVES, updatedLives + 1);
          setLevelLives(updatedLives);
          setBonusLifeEarned(true);
          setTimeout(() => setBonusLifeEarned(false), 2500);
        }
      }

      if (multiplier > 1) {
        sound.playStreakBonus(multiplier);
      } else {
        sound.playCorrect();
      }

      particleRef.current?.spawnSuccessBurst(particleX, particleY, targetedBin, viewportX, viewportY);
      
      const streakTag = multiplier > 1 ? ` (x${multiplier.toFixed(1)} 🔥)` : '';
      setRoundFeedback({
        status: 'correct',
        message: `¡CORRECTO! +${pointsAwarded} pts${streakTag}`,
        detail: newStreak >= 2
          ? `¡Racha de ${newStreak} aciertos seguidos! Multiplicador x${multiplier.toFixed(1)} aplicado (+${pointsAwarded} pts). "${curItem.nombre}" va al contenedor ${correctInfo.nombre} (${correctInfo.etiqueta}).`
          : `"${curItem.nombre}" va al contenedor ${correctInfo.nombre} (${correctInfo.etiqueta}).`
      });

      // Persistent stats and medal evaluation
      const { newlyUnlocked, stats: nextStats } = recordItemClassified(
        true,
        elapsedSeconds,
        isToxic,
        pointsAwarded
      );

      if (newlyUnlocked.length > 0) {
        sound.playMedalUnlocked();
        setUnlockedMedalIds(nextStats.unlockedMedalIds);
        setMedalQueue((prev) => [...prev, ...newlyUnlocked]);
      }
    } else {
      const prevStreak = consecutiveCorrectRef.current;
      consecutiveCorrectRef.current = 0;
      setStreak(0);
      setLevelLives(updatedLives);
      setLevelErrors(updatedErrors);

      if (prevStreak >= 2) {
        sound.playStreakBreak();
      } else {
        sound.playIncorrect();
      }

      const streakNotice = prevStreak >= 2 ? ` ¡Racha de ${prevStreak} aciertos perdida!` : '';
      setRoundFeedback({
        status: 'incorrect',
        message: '¡INCORRECTO!',
        detail: `"${curItem.nombre}" corresponde al contenedor ${correctInfo.nombre} (${correctInfo.etiqueta}), no al ${chosenInfo.nombre}.${streakNotice}`
      });

      // Reset current streak in persistent stats
      recordItemClassified(false, elapsedSeconds, isToxic, 0);
    }

    const newResult: RoundResult = {
      round: currentMode === 'infinite' ? infiniteSortedCountRef.current + 1 : curItemIdx + 1,
      item: curItem,
      chosenCategory: targetedBin,
      isCorrect,
      explanation: isCorrect
        ? `Correcto: ${curItem.nombre} se deposita en ${correctInfo.nombre}.`
        : `Atención: ${curItem.nombre} pertenece a ${correctInfo.nombre} (${correctInfo.etiqueta}).`
    };

    setLevelHistory((prev) => [...prev, newResult]);
    setGlobalHistory((prev) => [...prev, newResult]);

    // Advance after feedback
    setTimeout(() => {
      setRoundFeedback(null);
      setToastMessage(null);
      setLastDropFeedback(null);

      // INFINITE MODE ADVANCEMENT
      if (currentMode === 'infinite') {
        if (updatedLives <= 0) {
          sound.playGameOver();
          const infResult = recordInfiniteGameResult(
            totalScoreRef.current,
            infiniteSortedCountRef.current,
            bestStreakInSessionRef.current
          );
          setIsNewInfiniteRecord(infResult.isNewRecord);
          setBestInfiniteScore(infResult.stats.bestInfiniteScore || 0);
          if (infResult.newlyUnlocked.length > 0) {
            sound.playMedalUnlocked();
            setUnlockedMedalIds(infResult.stats.unlockedMedalIds);
            setMedalQueue((prev) => [...prev, ...infResult.newlyUnlocked]);
          }
          setActiveModal('infinite_game_over');
          return;
        }

        drawNextInfiniteItem();
        rondaProcesadaRef.current = false;
        canGrabRef.current = true;
        return;
      }

      // LEVELS MODE ADVANCEMENT
      if (updatedLives <= 0) {
        sound.playGameOver();
        setActiveModal('level_failed');
        return;
      }

      // Check if player finished all 10 items of the current level
      if (curItemIdx + 1 >= ITEMS_PER_LEVEL) {
        sound.playVictory();
        particleRef.current?.spawnVictoryBlast();

        const isGameComplete = curLevelIdx + 1 >= TOTAL_LEVELS;
        const { newlyUnlocked: levelMedals, stats: levelStats } = recordLevelResult(
          true,
          updatedLives,
          updatedErrors,
          isGameComplete
        );

        if (levelMedals.length > 0) {
          sound.playMedalUnlocked();
          setUnlockedMedalIds(levelStats.unlockedMedalIds);
          setMedalQueue((prev) => [...prev, ...levelMedals]);
        }

        if (isGameComplete) {
          setActiveModal('game_victory');
        } else {
          setActiveModal('level_success');
        }
      } else {
        setItemIndexInLevel((prev) => prev + 1);
        rondaProcesadaRef.current = false;
        canGrabRef.current = true;
      }
    }, 1500);
  }, [checkIntersectionWithBin, drawNextInfiniteItem]);

  // Derived directly during render: No state, no effect, no re-render loop
  const hoveredBin = useMemo(() => {
    if (!isGrabbed) return null;
    return checkIntersectionWithBin(wastePos.x, wastePos.y);
  }, [isGrabbed, wastePos.x, wastePos.y, checkIntersectionWithBin]);

  // Grab & Release Hand Gestures Effect (Strictly loop-free via gesture latch)
  useEffect(() => {
    if (activeModal !== null || rondaProcesadaRef.current) return;

    // Opening fingers unlocks grabbing capability for next gesture
    if (!isPinching) {
      canGrabRef.current = true;
    }

    if (!isGrabbed) {
      if (handDetected && isPinching && canGrabRef.current && isHoveringWaste) {
        canGrabRef.current = false;
        setIsGrabbed(true);
        sound.playGrab();
        setToastMessage(null);
      }
    } else {
      if (!isPinching || !handDetected) {
        canGrabRef.current = false;
        handleRelease(wastePosRef.current.x, wastePosRef.current.y);
      }
    }
  }, [
    activeModal,
    isGrabbed,
    handDetected,
    isPinching,
    isHoveringWaste,
    handleRelease
  ]);

  // Restart current level (resets level counter, restores 3 lives)
  const handleRestartLevel = () => {
    setActiveModal(null);
    setItemIndexInLevel(0);
    setLevelLives(MAX_LIVES);
    setLevelErrors(0);
    setLevelHistory([]);
    setStreak(0);
    consecutiveCorrectRef.current = 0;
    setLastPointsNotification(null);
    rondaProcesadaRef.current = false;
    bgm.playTrackForLevel(currentLevelIndex + 1);
  };

  // Next Level Progression
  const handleNextLevel = () => {
    setActiveModal(null);
    const nextIdx = currentLevelIndex + 1;
    setCurrentLevelIndex(nextIdx);
    setItemIndexInLevel(0);
    setLevelLives(MAX_LIVES);
    setLevelErrors(0);
    setLevelHistory([]);
    rondaProcesadaRef.current = false;
    bgm.playTrackForLevel(nextIdx + 1);
  };

  // Restart entire game from Level 1
  const handleRestartEntireGame = () => {
    setActiveModal(null);
    setGameMode('levels');
    setCurrentLevelIndex(0);
    setItemIndexInLevel(0);
    setLevelLives(MAX_LIVES);
    setLevelErrors(0);
    setLevelHistory([]);
    setGlobalHistory([]);
    setTotalScore(0);
    setStreak(0);
    consecutiveCorrectRef.current = 0;
    setLastPointsNotification(null);
    rondaProcesadaRef.current = false;
    bgm.playTrackForLevel(1);
  };

  // Start or restart Infinite Mode session
  const handleStartInfiniteMode = useCallback(() => {
    setActiveModal(null);
    setGameMode('infinite');
    infiniteDeckRef.current = createInfiniteDeck();
    const firstItem = infiniteDeckRef.current.shift() || TODOS_LOS_RESIDUOS[0];
    setInfiniteCurrentItem(firstItem);
    setInfiniteSortedCount(0);
    setLevelLives(MAX_LIVES);
    setLevelErrors(0);
    setLevelHistory([]);
    setTotalScore(0);
    setStreak(0);
    consecutiveCorrectRef.current = 0;
    bestStreakInSessionRef.current = 0;
    setLastPointsNotification(null);
    rondaProcesadaRef.current = false;
    canGrabRef.current = true;
    itemSpawnTimeRef.current = Date.now();
    bgm.startInfiniteModeShuffle();
  }, []);

  // Switch to Levels Mode
  const handleStartLevelsMode = useCallback(() => {
    setActiveModal(null);
    setGameMode('levels');
    setCurrentLevelIndex(0);
    setItemIndexInLevel(0);
    setLevelLives(MAX_LIVES);
    setLevelErrors(0);
    setLevelHistory([]);
    setGlobalHistory([]);
    setTotalScore(0);
    setStreak(0);
    consecutiveCorrectRef.current = 0;
    setLastPointsNotification(null);
    rondaProcesadaRef.current = false;
    canGrabRef.current = true;
    itemSpawnTimeRef.current = Date.now();
    bgm.playTrackForLevel(1);
  }, []);

  // Sincronización automática de música: 1 canción por cada nivel (1 a 10) o aleatoria sin repetición en Modo Infinito
  useEffect(() => {
    if (gameMode === 'infinite') {
      bgm.startInfiniteModeShuffle();
    } else {
      bgm.playTrackForLevel(currentLevelIndex + 1);
    }
  }, [gameMode, currentLevelIndex]);

  // Synchronize game mode if initialMode prop updates
  useEffect(() => {
    if (initialMode && initialMode !== gameModeRef.current) {
      if (initialMode === 'infinite') {
        handleStartInfiniteMode();
      } else {
        handleStartLevelsMode();
      }
    }
  }, [initialMode, handleStartInfiniteMode, handleStartLevelsMode]);

  return (
    <div
      ref={stageRef}
      id="escenario-ar-principal"
      className="relative w-full h-screen max-w-5xl mx-auto flex flex-col justify-between p-1.5 sm:p-2.5 select-none overflow-hidden z-10"
    >
      {/* 1. TOP MULTIPLATFORM HUD BAR */}
      <header
        id="marcador-juego"
        className="w-full z-40 bg-slate-900/95 backdrop-blur-md px-2 sm:px-3 py-1.5 rounded-2xl border border-slate-700/80 shadow-2xl flex items-center justify-between gap-1.5 sm:gap-2.5"
      >
        {/* LEFT ZONE: Context & Mode/Level */}
        <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
          {/* Mode Switcher Pill */}
          <div className="flex items-center p-0.5 rounded-xl bg-slate-950/80 border border-slate-800 text-[10px] font-bold">
            <button
              onClick={handleStartLevelsMode}
              title="Cambiar a Modo Niveles (1-10)"
              className={`px-2 py-0.5 rounded-lg transition cursor-pointer flex items-center gap-1 ${
                gameMode === 'levels'
                  ? 'bg-emerald-500 text-slate-950 font-black shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>🎯</span>
              <span className="hidden sm:inline">Niveles</span>
              {gameMode === 'levels' && <span>{currentLevelIndex + 1}/10</span>}
            </button>
            <button
              onClick={handleStartInfiniteMode}
              title="Cambiar a Modo Infinito (160 residuos)"
              className={`px-2 py-0.5 rounded-lg transition cursor-pointer flex items-center gap-1 ${
                gameMode === 'infinite'
                  ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white font-black shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Infinity className="w-3 h-3 text-amber-300" />
              <span className="hidden sm:inline">Infinito</span>
            </button>
          </div>

          {/* Current progress badge */}
          <div className="flex items-center gap-1 px-2 py-0.5 rounded-lg bg-slate-950/80 border border-sky-500/30 text-sky-300 text-[11px] font-bold">
            <span>📦</span>
            {gameMode === 'levels' ? (
              <span>{itemIndexInLevel + 1}/10</span>
            ) : (
              <span>#{infiniteSortedCount}</span>
            )}
          </div>
        </div>

        {/* CENTER ZONE: Vital Gameplay Stats (Hearts, Score & Streak) */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Lives (Hearts) */}
          <div
            className="flex items-center gap-0.5 px-2 py-0.5 rounded-xl bg-slate-950/80 border border-rose-500/30"
            title={`Vidas restantes: ${levelLives} de ${MAX_LIVES}`}
          >
            {Array.from({ length: MAX_LIVES }).map((_, i) => (
              <span
                key={i}
                className={`text-xs sm:text-sm transition-all duration-300 select-none ${
                  i < levelLives
                    ? 'scale-105 filter drop-shadow-[0_0_4px_rgba(244,63,94,0.6)]'
                    : 'opacity-25 grayscale'
                }`}
              >
                ❤️
              </span>
            ))}
            {bonusLifeEarned && (
              <span className="ml-0.5 px-1 py-0.2 rounded bg-rose-500 text-white text-[8px] font-black uppercase whitespace-nowrap animate-bounce shadow">
                +1
              </span>
            )}
          </div>

          {/* Points Badge with Dynamic Floating Points */}
          <div className="relative flex items-center gap-1 px-2.5 py-0.5 rounded-xl bg-slate-950/80 border border-amber-500/30 text-amber-300 font-black text-xs sm:text-sm">
            <span>⭐</span>
            <span className="tabular-nums">{totalScore}</span>

            {/* Floating Score Notification */}
            {lastPointsNotification && (
              <div
                key={lastPointsNotification.id}
                className="absolute -top-7 left-1/2 -translate-x-1/2 pointer-events-none animate-bounce flex items-center gap-0.5 px-2 py-0.5 rounded-full bg-amber-400 text-slate-950 text-[10px] font-black shadow-lg shadow-amber-400/40 border border-yellow-200 z-50 whitespace-nowrap"
              >
                <span>+{lastPointsNotification.points}</span>
                {lastPointsNotification.multiplier > 1 && (
                  <span className="text-[9px] text-slate-900 font-extrabold">
                    (x{lastPointsNotification.multiplier.toFixed(1)}🔥)
                  </span>
                )}
              </div>
            )}
          </div>

          {/* Streak Counter Badge (only shows when active streak >= 2) */}
          {streak >= 2 && (
            <div
              className="flex items-center gap-1 px-2 py-0.5 rounded-xl bg-gradient-to-r from-orange-950/60 to-amber-950/60 border border-orange-500/40 text-amber-300 font-black text-xs shadow-md animate-pulse"
              title={`Racha de ${streak} aciertos seguidos (Multiplicador x${calculateStreakMultiplier(streak).toFixed(1)})`}
            >
              <Flame className="w-3.5 h-3.5 text-orange-400 fill-orange-400" />
              <span className="text-white font-bold">{streak}</span>
              <span className="text-[10px] text-amber-300 font-extrabold">
                x{calculateStreakMultiplier(streak).toFixed(1)}
              </span>
            </div>
          )}
        </div>

        {/* RIGHT ZONE: Utility Controls */}
        <div className="flex items-center gap-1 shrink-0">
          {/* Music Controller Pill */}
          <div className="flex items-center rounded-xl bg-slate-950/80 border border-teal-500/30 p-0.5">
            <button
              onClick={(e) => {
                e.stopPropagation();
                sound.playGrab();
                bgm.toggle();
              }}
              title={isMusicPlaying ? 'Pausar música' : 'Reproducir música'}
              className={`p-1 rounded-lg transition cursor-pointer ${
                isMusicPlaying ? 'text-teal-300 hover:text-white' : 'text-slate-500 hover:text-slate-300'
              }`}
            >
              {isMusicPlaying ? (
                <Pause className="w-3.5 h-3.5 fill-current" />
              ) : (
                <Play className="w-3.5 h-3.5 fill-current" />
              )}
            </button>
            <button
              onClick={() => {
                sound.playGrab();
                setShowMusicModal(true);
              }}
              title="Ver las 10 canciones del juego"
              className="flex items-center gap-1 px-1.5 py-0.5 rounded-lg text-[10px] font-bold text-teal-300 hover:text-white hover:bg-slate-800 transition cursor-pointer"
            >
              <Music className={`w-3 h-3 text-teal-400 ${isMusicPlaying ? 'animate-spin-slow' : ''}`} />
              <span className="hidden sm:inline">10 Canciones</span>
            </button>
          </div>

          {/* Sound FX Toggle Button */}
          <button
            onClick={onToggleSound}
            title={soundEnabled ? 'Silenciar efectos de sonido' : 'Activar efectos de sonido'}
            className="p-1.5 rounded-xl bg-slate-950/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 transition cursor-pointer"
          >
            {soundEnabled ? (
              <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
            ) : (
              <VolumeX className="w-3.5 h-3.5 text-rose-400" />
            )}
          </button>

          {/* Camera Flip Button (Front / Rear) */}
          {onSwitchCamera && (
            <button
              onClick={async () => {
                setIsSwitchingCam(true);
                await onSwitchCamera();
                setIsSwitchingCam(false);
              }}
              disabled={isSwitchingCam}
              title={`Girar cámara (${facingMode === 'user' ? 'frontal' : 'trasera'})`}
              className="p-1.5 rounded-xl bg-slate-950/80 hover:bg-slate-800 text-teal-300 hover:text-white border border-slate-800 transition cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSwitchingCam ? 'animate-spin' : ''}`} />
            </button>
          )}

          {/* Medals Trophy Button */}
          <button
            onClick={() => setShowMedalsModal(true)}
            title="Ver Logros y Medallas Desbloqueadas"
            className="flex items-center gap-1 px-2 py-1 rounded-xl bg-slate-950/80 hover:bg-slate-800 text-amber-300 border border-amber-500/30 text-xs font-bold transition cursor-pointer"
          >
            <Award className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-[10px] font-black">{unlockedMedalIds.length}</span>
          </button>

          {/* Exit to Menu Button */}
          <button
            onClick={onExitToMenu}
            title="Regresar al Menú Principal"
            className="px-2.5 py-1 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-slate-200 hover:text-white text-xs font-black border border-slate-700 transition cursor-pointer"
          >
            Menú
          </button>
        </div>
      </header>

      {/* 2. THE SINGLE DELIMITED AR INTERACTION AREA - Compact Height */}
      <div className="relative flex-1 flex flex-col items-center justify-center my-1 pointer-events-none">
        <div
          id="area-delimitada-residuos"
          ref={delimitedAreaRef}
          className="relative w-full max-w-lg h-38 sm:h-44 md:h-48 rounded-2xl border-2 border-emerald-400/50 bg-slate-950/30 backdrop-blur-[2px] shadow-xl shadow-emerald-500/10 flex flex-col items-center justify-between p-2 sm:p-2.5 pointer-events-auto transition-all"
        >
          {/* Holographic AR Corner Brackets */}
          <div className="absolute -top-1 -left-1 w-4 h-4 border-t-3 border-l-3 border-emerald-400 rounded-tl-lg pointer-events-none" />
          <div className="absolute -top-1 -right-1 w-4 h-4 border-t-3 border-r-3 border-emerald-400 rounded-tr-lg pointer-events-none" />
          <div className="absolute -bottom-1 -left-1 w-4 h-4 border-b-3 border-l-3 border-emerald-400 rounded-bl-lg pointer-events-none" />
          <div className="absolute -bottom-1 -right-1 w-4 h-4 border-b-3 border-r-3 border-emerald-400 rounded-br-lg pointer-events-none" />

          {/* Delimited Area Header Badge */}
          <div className="flex items-center justify-between w-full pointer-events-none">
            <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-slate-950/85 border border-emerald-500/40 shadow-xs">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
              <span className="text-[9px] sm:text-[10px] font-black uppercase tracking-wider text-emerald-400">
                {gameMode === 'infinite' ? '♾️ MODO INFINITO (160 RESIDUOS)' : currentLevel.title}
              </span>
            </div>

            <div className="px-2.5 py-0.5 rounded-full bg-slate-950/85 border border-slate-700/60 shadow-xs text-[9px] sm:text-[10px] font-bold text-slate-300">
              {isGrabbed
                ? '✋ ¡Llévalo al contenedor!'
                : '🤏 Haz pinza para agarrar'}
            </div>
          </div>

          {/* Level Guidance Text */}
          {!isGrabbed && (
            <div className="text-center pointer-events-none my-auto px-3 py-1.5 rounded-xl bg-slate-950/60 border border-white/5 backdrop-blur-xs max-w-sm">
              <p className="text-[11px] text-slate-200 font-medium leading-snug">
                {gameMode === 'infinite'
                  ? 'Pon a prueba tus reflejos ecológicos con 160 residuos reales sin fin. Cada 15 aciertos recuperas +1 vida.'
                  : currentLevel.description}
              </p>
              <span className="inline-block mt-0.5 text-[10px] text-amber-300 font-bold">
                ⚠️ Tienes {levelLives} {levelLives === 1 ? 'vida' : 'vidas'}. ¡3 fallos y reinicias!
              </span>
            </div>
          )}

          {/* Area Footer Guidance */}
          <div className="w-full text-center pointer-events-none">
            <span className="text-[9px] sm:text-[10px] font-extrabold text-slate-400 tracking-wider uppercase">
              {gameMode === 'infinite'
                ? `Residuo #${infiniteSortedCount + 1} • Racha: ${streak} 🔥 • Arrastra hacia el contenedor`
                : `Objeto ${itemIndexInLevel + 1} de ${ITEMS_PER_LEVEL} • Haz pinza y arrastra hacia el contenedor`}
            </span>
          </div>
        </div>

        {/* Interactive Waste Item Card (Can be grabbed by hand gesture) */}
        {currentItem && (
          <WasteItemCard
            item={currentItem}
            x={wastePos.x}
            y={wastePos.y}
            isGrabbed={isGrabbed}
            isHoveredByHand={isHoveringWaste}
            width={ITEM_WIDTH}
            height={ITEM_HEIGHT}
          />
        )}
      </div>

      {/* 3. DESTINATION RECYCLING BINS ROW (Without Logos and Without Names!) */}
      <div
        id="fila-contenedores"
        className="relative w-full flex items-end justify-around gap-1 sm:gap-2 px-1 pb-1 z-30 pointer-events-auto"
      >
        {(['verde', 'azul', 'gris', 'rojo'] as WasteCategory[]).map((cat) => (
          <div
            key={cat}
            ref={(el) => {
              binRefs.current[cat] = el;
            }}
            className="flex-1 max-w-[130px] flex justify-center"
          >
            <RecyclingBin
              category={cat}
              isHovered={hoveredBin === cat}
              dropFeedback={
                lastDropFeedback?.bin === cat
                  ? lastDropFeedback.status
                  : null
              }
            />
          </div>
        ))}
      </div>

      {/* 4. HIGH PERFORMANCE PARTICLE CANVAS (For success shockwaves, floaters & confetti) */}
      <ParticleCanvas
        ref={particleRef}
        width={stageSize.width}
        height={stageSize.height}
      />

      {/* 5. VIRTUAL AR HAND CURSOR */}
      <HandCursor
        x={cursorPos.x}
        y={cursorPos.y}
        isPinching={isPinching}
        isHoldingItem={isGrabbed}
        detected={handDetected}
        pinchDistance={pinchDistance}
      />

      {/* 5. HAND SEARCH NOTIFICATION PILL (Leaves camera 100% visible and unblurred) */}
      {!handDetected && !activeModal && (
        <div className="absolute top-16 left-1/2 -translate-x-1/2 z-40 pointer-events-none animate-fade-in max-w-sm w-full px-4">
          <div className="px-4 py-2.5 rounded-2xl bg-slate-950/85 border border-amber-400/60 shadow-2xl backdrop-blur-md flex items-center justify-between gap-3 pointer-events-auto">
            <div className="flex items-center gap-2.5">
              <span className="text-xl animate-bounce">🖐️</span>
              <div>
                <div className="text-[11px] font-black text-amber-300 uppercase tracking-wide flex items-center gap-1.5">
                  <span>BUSCANDO TU MANO</span>
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
                </div>
                <p className="text-[10px] text-slate-300">
                  Coloca tu mano frente al lente (o usa ratón/pantalla táctil)
                </p>
              </div>
            </div>

            {onSwitchCamera && (
              <button
                onClick={async () => {
                  setIsSwitchingCam(true);
                  await onSwitchCamera();
                  setIsSwitchingCam(false);
                }}
                disabled={isSwitchingCam}
                title="Girar cámara"
                className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-300 border border-teal-500/30 text-xs font-bold transition cursor-pointer shrink-0"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSwitchingCam ? 'animate-spin' : ''}`} />
              </button>
            )}
          </div>
        </div>
      )}

      {/* 6. ROUND FEEDBACK OVERLAY */}
      {roundFeedback && (
        <div className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/65 backdrop-blur-xs pointer-events-none animate-fade-in">
          <div
            className={`p-6 rounded-3xl border-2 shadow-2xl flex flex-col items-center text-center max-w-md ${
              roundFeedback.status === 'correct'
                ? 'bg-emerald-950/95 border-emerald-400 text-emerald-100 shadow-emerald-500/30'
                : 'bg-rose-950/95 border-rose-400 text-rose-100 shadow-rose-500/30'
            }`}
          >
            {roundFeedback.status === 'correct' ? (
              <CheckCircle2 className="w-16 h-16 text-emerald-400 mb-2 animate-bounce" />
            ) : (
              <XCircle className="w-16 h-16 text-rose-400 mb-2 animate-shake" />
            )}
            <h3 className="text-2xl sm:text-3xl font-black uppercase tracking-tight">
              {roundFeedback.message}
            </h3>
            <p className="text-sm font-semibold mt-2 opacity-90 leading-relaxed">
              {roundFeedback.detail}
            </p>
            {roundFeedback.status === 'incorrect' && (
              <div className="mt-3 px-3 py-1 rounded-full bg-rose-500/30 text-rose-200 text-xs font-bold">
                Te quedan {levelLives} {levelLives === 1 ? 'vida' : 'vidas'}
              </div>
            )}
          </div>
        </div>
      )}

      {/* 7. TOAST MESSAGE WHEN RELEASED OUTSIDE */}
      {toastMessage && !roundFeedback && !activeModal && (
        <div className="absolute bottom-28 left-1/2 -translate-x-1/2 z-40 bg-amber-500/90 text-slate-950 px-4 py-2 rounded-2xl shadow-xl border border-amber-300 font-bold text-xs sm:text-sm flex items-center gap-2 animate-bounce">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* 8. LEVEL PROGRESSION / VICTORY / GAMEOVER FEEDBACK MODAL */}
      {activeModal && activeModal !== 'infinite_game_over' && (
        <LevelFeedbackModal
          type={activeModal}
          level={currentLevel}
          levelNumber={currentLevelIndex + 1}
          totalLevels={TOTAL_LEVELS}
          score={totalScore}
          levelErrors={levelErrors}
          livesRemaining={levelLives}
          maxLives={MAX_LIVES}
          levelHistory={levelHistory}
          onNextLevel={handleNextLevel}
          onRestartLevel={handleRestartLevel}
          onRestartEntireGame={handleRestartEntireGame}
          onGoHome={onExitToMenu}
          onShowMedals={() => setShowMedalsModal(true)}
        />
      )}

      {/* INFINITE MODE GAME OVER MODAL */}
      {activeModal === 'infinite_game_over' && (
        <InfiniteGameOverModal
          score={totalScore}
          itemsSorted={infiniteSortedCount}
          bestStreak={bestStreakInSessionRef.current}
          isNewRecord={isNewInfiniteRecord}
          bestHistoricScore={bestInfiniteScore}
          history={globalHistory}
          onPlayAgain={handleStartInfiniteMode}
          onSwitchToLevels={handleStartLevelsMode}
          onHome={onExitToMenu}
          onShowMedals={() => setShowMedalsModal(true)}
        />
      )}

      {/* 9. MEDAL POPUP NOTIFICATION (Driven by CSS animations) */}
      <MedalNotification
        medalQueue={medalQueue}
        onDismiss={handleDismissMedal}
      />

      {/* 10. MEDAL COLLECTION GALLERY MODAL */}
      {showMedalsModal && (
        <MedalsModal
          unlockedMedalIds={unlockedMedalIds}
          onClose={() => setShowMedalsModal(false)}
          onStatsReset={() => setUnlockedMedalIds([])}
        />
      )}

      {/* 11. BGM SOUNDTRACK JUKEBOX MODAL */}
      {showMusicModal && (
        <MusicModal
          onClose={() => setShowMusicModal(false)}
        />
      )}
    </div>
  );
};
