import React, { useEffect, useState } from 'react';
import { Medal } from '../types';
import { Sparkles, X, Award, Flame, Trophy, ShieldAlert, Zap, Crown, CheckCircle2 } from 'lucide-react';

interface MedalNotificationProps {
  medalQueue: Medal[];
  onDismiss: (id: string) => void;
}

export const MedalNotification: React.FC<MedalNotificationProps> = ({ medalQueue, onDismiss }) => {
  const currentMedal = medalQueue.length > 0 ? medalQueue[0] : null;
  const [isExiting, setIsExiting] = useState(false);

  useEffect(() => {
    if (!currentMedal) {
      setIsExiting(false);
      return;
    }

    setIsExiting(false);
    // Stay visible for 3.4 seconds, then trigger exit animation for 0.4s
    const timer = setTimeout(() => {
      setIsExiting(true);
      const exitTimer = setTimeout(() => {
        onDismiss(currentMedal.id);
      }, 400);
      return () => clearTimeout(exitTimer);
    }, 3400);

    return () => clearTimeout(timer);
  }, [currentMedal?.id, onDismiss]);

  if (!currentMedal) return null;

  const handleManualDismiss = () => {
    setIsExiting(true);
    setTimeout(() => {
      onDismiss(currentMedal.id);
    }, 350);
  };

  const getTierBadgeStyle = (tier: Medal['tier']) => {
    switch (tier) {
      case 'diamond':
        return 'bg-gradient-to-r from-cyan-400 via-sky-300 to-blue-400 text-slate-950 font-black shadow-cyan-500/50';
      case 'gold':
        return 'bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 text-slate-950 font-black shadow-amber-500/50';
      case 'silver':
        return 'bg-gradient-to-r from-slate-200 via-sky-100 to-slate-300 text-slate-900 font-black shadow-sky-400/40';
      case 'bronze':
      default:
        return 'bg-gradient-to-r from-amber-600 via-amber-500 to-amber-700 text-amber-50 font-black shadow-amber-700/40';
    }
  };

  const getMedalIconGraphic = (id: string, iconEmoji: string) => {
    switch (id) {
      case 'streak_5':
      case 'streak_10':
        return <Flame className="w-8 h-8 text-amber-300 animate-pulse" />;
      case 'level_cleared':
      case 'clean_sheet':
        return <Trophy className="w-8 h-8 text-yellow-300" />;
      case 'toxic_expert':
        return <ShieldAlert className="w-8 h-8 text-rose-300" />;
      case 'speed_sorter':
        return <Zap className="w-8 h-8 text-purple-300" />;
      case 'eco_legend':
        return <Crown className="w-8 h-8 text-cyan-300" />;
      default:
        return <span className="text-3xl select-none">{iconEmoji}</span>;
    }
  };

  return (
    <div
      className={`fixed top-4 left-1/2 -translate-x-1/2 z-50 pointer-events-auto max-w-md w-[92vw] sm:w-[420px] transition-all select-none ${
        isExiting ? 'animate-medal-exit' : 'animate-medal-pop'
      }`}
    >
      <div
        onClick={handleManualDismiss}
        role="alert"
        className="relative overflow-hidden rounded-2xl border-2 p-4 shadow-2xl backdrop-blur-xl cursor-pointer group bg-slate-950/95"
        style={{
          borderColor: currentMedal.borderColor,
          boxShadow: `0 10px 40px -10px ${currentMedal.accentColor}77, 0 0 25px ${currentMedal.accentColor}44`
        }}
      >
        {/* Rotating Sunburst Rays Background */}
        <div className="absolute -top-12 -left-12 w-44 h-44 pointer-events-none opacity-25 animate-sunburst overflow-hidden">
          <svg viewBox="0 0 100 100" className="w-full h-full fill-current" style={{ color: currentMedal.accentColor }}>
            {[...Array(12)].map((_, i) => (
              <polygon
                key={i}
                points="50,50 46,0 54,0"
                transform={`rotate(${i * 30} 50 50)`}
              />
            ))}
          </svg>
        </div>

        {/* Shimmer Light Reflection Sweep */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <div className="w-1/2 h-full bg-gradient-to-r from-transparent via-white/20 to-transparent animate-medal-shimmer" />
        </div>

        {/* Corner Twinkling Sparkles */}
        <div className="absolute top-2 right-9 text-amber-300 animate-sparkle-twinkle">
          <Sparkles className="w-4 h-4" />
        </div>
        <div className="absolute bottom-2 left-2 text-yellow-200 animate-sparkle-twinkle" style={{ animationDelay: '0.7s' }}>
          <Sparkles className="w-3.5 h-3.5" />
        </div>

        {/* Dismiss Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            handleManualDismiss();
          }}
          className="absolute top-2.5 right-2.5 p-1 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          title="Cerrar notificación"
          aria-label="Cerrar medalla"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Main Content Layout */}
        <div className="flex items-center gap-3.5 relative z-10">
          {/* Medal Medallion Badge Icon */}
          <div className="relative flex-shrink-0 animate-badge-bob">
            {/* Outer halo */}
            <div
              className="absolute -inset-1 rounded-full blur-md opacity-60"
              style={{ backgroundColor: currentMedal.accentColor }}
            />
            {/* Medal disc */}
            <div
              className="relative w-14 h-14 rounded-full flex items-center justify-center border-2 shadow-inner"
              style={{
                backgroundColor: '#090d16',
                borderColor: currentMedal.borderColor
              }}
            >
              {getMedalIconGraphic(currentMedal.id, currentMedal.icon)}
            </div>
            {/* Ribbon tip indicator */}
            <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 flex items-center justify-center">
              <Award className="w-4 h-4" style={{ color: currentMedal.borderColor }} />
            </div>
          </div>

          {/* Details */}
          <div className="flex-1 min-w-0 pr-5">
            <div className="flex items-center gap-2 mb-1">
              <span
                className={`text-[9px] uppercase tracking-wider px-2 py-0.5 rounded-full shadow-sm ${getTierBadgeStyle(
                  currentMedal.tier
                )}`}
              >
                ✦ Medalla de {currentMedal.tierLabel} ✦
              </span>
            </div>

            <h4 className="text-white font-extrabold text-sm sm:text-base leading-tight tracking-tight flex items-center gap-1.5 truncate">
              {currentMedal.title}
            </h4>

            <p className="text-[12px] font-medium text-emerald-300 mt-0.5 leading-snug">
              {currentMedal.subtitle}
            </p>

            <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed line-clamp-2">
              {currentMedal.description}
            </p>
          </div>
        </div>

        {/* Progress queue indicator if multiple unlocked */}
        {medalQueue.length > 1 && (
          <div className="mt-2 pt-1.5 border-t border-white/10 flex items-center justify-between text-[10px] text-slate-400">
            <span className="flex items-center gap-1 font-semibold text-amber-300">
              <CheckCircle2 className="w-3 h-3" />
              +{medalQueue.length - 1} medalla{medalQueue.length > 2 ? 's' : ''} más en cola
            </span>
            <span className="text-slate-500">Toca para ver la siguiente</span>
          </div>
        )}
      </div>
    </div>
  );
};
