import React from 'react';
import { Trophy, RotateCcw, Home, Award, CheckCircle2, XCircle } from 'lucide-react';
import { RoundResult } from '../types';

interface GameOverModalProps {
  score: number;
  errors: number;
  totalRounds: number;
  history: RoundResult[];
  onRestart: () => void;
  onHome: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  score,
  errors,
  totalRounds,
  history,
  onRestart,
  onHome
}) => {
  const precision = Math.round((score / totalRounds) * 100);

  const getEcoRank = () => {
    if (score >= 9) return { title: 'Experto en Reciclaje 🌟', desc: '¡Increíble precisión! Dominas la separación en la fuente.' };
    if (score >= 7) return { title: 'Guardián Ambiental 🌿', desc: '¡Muy buen trabajo! Tienes sólidos hábitos ecológicos.' };
    if (score >= 5) return { title: 'Aprendiz Consciente 🌱', desc: 'Buen intento, con un poco más de práctica serás un máster.' };
    return { title: 'Iniciador Ecológico ♻️', desc: 'Recuerda revisar qué va en cada contenedor y vuelve a intentarlo.' };
  };

  const rank = getEcoRank();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/85 backdrop-blur-md select-none animate-fade-in">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-2xl p-4 sm:p-5 shadow-2xl flex flex-col items-center text-center max-h-[92vh] overflow-y-auto">
        {/* Trophy Icon */}
        <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-amber-500 to-yellow-300 flex items-center justify-center shadow-md shadow-amber-500/30 mb-2">
          <Trophy className="w-6 h-6 text-slate-950" />
        </div>

        {/* Title */}
        <h1 className="text-xl sm:text-2xl font-black text-white uppercase tracking-tight">
          🎉 ¡PARTIDA TERMINADA!
        </h1>

        <div className="mt-1 inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-bold text-xs">
          <Award className="w-3.5 h-3.5" />
          <span>{rank.title}</span>
        </div>
        <p className="text-[11px] text-slate-400 mt-0.5 max-w-sm">{rank.desc}</p>

        {/* Score Cards Grid */}
        <div className="grid grid-cols-3 gap-2 w-full my-3">
          <div className="bg-slate-800/80 border border-emerald-500/30 rounded-xl p-2.5 flex flex-col items-center">
            <span className="text-[10px] sm:text-xs font-black text-emerald-400 uppercase">⭐ Puntos</span>
            <span className="text-2xl sm:text-3xl font-black text-white mt-0.5">{score}</span>
            <span className="text-[9px] text-slate-400 font-medium">de {totalRounds}</span>
          </div>

          <div className="bg-slate-800/80 border border-rose-500/30 rounded-xl p-2.5 flex flex-col items-center">
            <span className="text-[10px] sm:text-xs font-black text-rose-400 uppercase">❌ Errores</span>
            <span className="text-2xl sm:text-3xl font-black text-white mt-0.5">{errors}</span>
            <span className="text-[9px] text-slate-400 font-medium">fallos</span>
          </div>

          <div className="bg-slate-800/80 border border-sky-500/30 rounded-xl p-2.5 flex flex-col items-center">
            <span className="text-[10px] sm:text-xs font-black text-sky-400 uppercase">🎯 Precisión</span>
            <span className="text-2xl sm:text-3xl font-black text-white mt-0.5">{precision}%</span>
            <span className="text-[9px] text-slate-400 font-medium">efectividad</span>
          </div>
        </div>

        {/* Round review mini list */}
        <div className="w-full bg-slate-950/60 rounded-xl p-2.5 border border-slate-800 mb-3 max-h-28 overflow-y-auto">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5 text-left">
            Resumen de Residuos Clasificados:
          </span>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
            {history.map((h, i) => (
              <div
                key={i}
                className={`flex items-center gap-1 p-1 rounded-md text-[11px] font-semibold border ${
                  h.isCorrect
                    ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                    : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                }`}
              >
                <span>{h.item.emoji}</span>
                <span className="truncate flex-1 text-left">{h.item.nombre}</span>
                {h.isCorrect ? (
                  <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                ) : (
                  <XCircle className="w-3 h-3 text-rose-400 shrink-0" />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-2 w-full justify-center">
          <button
            onClick={onRestart}
            className="flex-1 flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl font-black text-xs sm:text-sm uppercase tracking-wider bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-md shadow-emerald-500/20 hover:scale-[1.01] transition cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>🔄 JUGAR OTRA VEZ</span>
          </button>

          <button
            onClick={onHome}
            className="flex-1 flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl font-bold text-xs sm:text-sm uppercase tracking-wider bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 hover:scale-[1.01] transition cursor-pointer"
          >
            <Home className="w-4 h-4" />
            <span>🏠 MENÚ</span>
          </button>
        </div>
      </div>
    </div>
  );
};
