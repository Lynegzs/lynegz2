import React, { useState } from 'react';
import { Medal, UserStats } from '../types';
import { ALL_MEDALS, getUserStats, resetUserStats } from '../data/medals';
import {
  Trophy,
  X,
  Lock,
  CheckCircle2,
  Award,
  Sparkles,
  Flame,
  ShieldAlert,
  Zap,
  Crown,
  Recycle,
  Star,
  RotateCcw,
  Target,
  Clock,
  Filter
} from 'lucide-react';
import { sound } from '../utils/audio';

interface MedalsModalProps {
  unlockedMedalIds?: string[];
  onClose: () => void;
  onStatsReset?: () => void;
}

export const MedalsModal: React.FC<MedalsModalProps> = ({
  unlockedMedalIds: propUnlockedIds,
  onClose,
  onStatsReset
}) => {
  const [stats, setStats] = useState<UserStats>(() => getUserStats());
  const [activeFilter, setActiveFilter] = useState<'all' | 'unlocked' | 'progress' | 'locked'>('all');
  const [showResetConfirm, setShowResetConfirm] = useState<boolean>(false);

  // Synchronize unlocked IDs between props and persistent storage
  const unlockedIds = propUnlockedIds || stats.unlockedMedalIds;
  const unlockedCount = ALL_MEDALS.filter((m) => unlockedIds.includes(m.id)).length;
  const totalCount = ALL_MEDALS.length;
  const progressPercent = Math.round((unlockedCount / totalCount) * 100);

  // Filter medals
  const filteredMedals = ALL_MEDALS.filter((medal) => {
    const isUnlocked = unlockedIds.includes(medal.id);
    if (activeFilter === 'unlocked') return isUnlocked;
    if (activeFilter === 'locked') return !isUnlocked;
    if (activeFilter === 'progress') {
      if (isUnlocked) return false;
      // Show medals that have quantifiable target value and some progress
      if (medal.targetValue && medal.statKey) {
        const val = stats[medal.statKey];
        return typeof val === 'number' && val > 0 && val < medal.targetValue;
      }
      return false;
    }
    return true;
  });

  const getTierTag = (tier: Medal['tier'], tierLabel: string) => {
    switch (tier) {
      case 'diamond':
        return (
          <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-cyan-400/20 text-cyan-300 border border-cyan-400/40 shadow-xs">
            💎 {tierLabel}
          </span>
        );
      case 'gold':
        return (
          <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/40 shadow-xs">
            🥇 {tierLabel}
          </span>
        );
      case 'silver':
        return (
          <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-sky-300/20 text-sky-200 border border-sky-300/40 shadow-xs">
            🥈 {tierLabel}
          </span>
        );
      case 'bronze':
      default:
        return (
          <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-700/20 text-amber-400 border border-amber-600/40 shadow-xs">
            🥉 {tierLabel}
          </span>
        );
    }
  };

  const getIcon = (id: string, iconEmoji: string, unlocked: boolean) => {
    if (!unlocked) {
      return <Lock className="w-5 h-5 text-slate-500" />;
    }
    switch (id) {
      case 'streak_5':
      case 'perfect_streak':
      case 'streak_15':
        return <Flame className="w-6 h-6 text-amber-300 animate-pulse" />;
      case 'level_cleared':
      case 'clean_sheet':
        return <Trophy className="w-6 h-6 text-yellow-300" />;
      case 'toxic_expert':
        return <ShieldAlert className="w-6 h-6 text-rose-300" />;
      case 'speed_sorter':
        return <Zap className="w-6 h-6 text-purple-300" />;
      case 'eco_legend':
        return <Crown className="w-6 h-6 text-cyan-300" />;
      case 'correct_50':
      case 'correct_100':
        return <Recycle className="w-6 h-6 text-emerald-300" />;
      default:
        return <span className="text-2xl select-none">{iconEmoji}</span>;
    }
  };

  const handleResetProgress = () => {
    const emptyStats = resetUserStats();
    setStats(emptyStats);
    setShowResetConfirm(false);
    sound.playRelease();
    if (onStatsReset) {
      onStatsReset();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/85 backdrop-blur-md select-none animate-fade-in overflow-y-auto">
      <div className="w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-2xl p-3.5 sm:p-4 shadow-2xl flex flex-col max-h-[92vh] my-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-2.5 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-yellow-400 to-amber-300 p-0.5 flex items-center justify-center shadow-md shadow-amber-500/20 shrink-0">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <Award className="w-4 h-4 sm:w-5 sm:h-5 text-amber-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-black tracking-wider text-amber-400 uppercase">
                  SISTEMA DE PROGRESO LOCAL
                </span>
                <span className="px-1.5 py-0.2 rounded-full bg-amber-400/20 text-amber-300 text-[9px] font-bold">
                  {unlockedCount}/{totalCount}
                </span>
              </div>
              <h2 className="text-sm sm:text-base font-black text-white flex items-center gap-1.5 tracking-tight">
                Logros y Medallas de Reciclaje
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              </h2>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playGrab();
              onClose();
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
            title="Cerrar vitrina"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* PERSISTENT STATS DASHBOARD SUMMARY */}
        <div className="mt-2.5 grid grid-cols-2 sm:grid-cols-4 gap-1.5">
          {/* Stat 1: Total Residuos Correctos (Highlights 50 items milestone) */}
          <div className="p-2 rounded-xl bg-slate-950/80 border border-slate-800 flex flex-col justify-between">
            <div className="flex items-center justify-between text-slate-400 text-[10px] font-bold">
              <span className="flex items-center gap-1">
                <Recycle className="w-3 h-3 text-emerald-400" />
                Residuos
              </span>
              <span className="text-emerald-400 font-extrabold text-[10px]">Hito 50</span>
            </div>
            <div className="mt-1 flex items-baseline gap-1">
              <span className="text-xl sm:text-2xl font-black text-white">{stats.totalCorrect}</span>
              <span className="text-xs text-slate-500">/ 50</span>
            </div>
            {/* Progress to 50 */}
            <div className="w-full h-1.5 bg-slate-800 rounded-full mt-1.5 overflow-hidden">
              <div
                className="h-full bg-emerald-500 rounded-full transition-all duration-500"
                style={{ width: `${Math.min(100, Math.round((stats.totalCorrect / 50) * 100))}%` }}
              />
            </div>
          </div>

          {/* Stat 2: Mejor Racha (Highlights Racha Perfecta milestone) */}
          <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col justify-between">
            <div className="flex items-center justify-between text-slate-400 text-[11px] font-bold">
              <span className="flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 text-amber-400" />
                Mejor Racha
              </span>
              <span className="text-amber-400 font-extrabold text-[10px]">Racha x10</span>
            </div>
            <div className="mt-1 flex items-baseline gap-1">
              <span className="text-xl sm:text-2xl font-black text-white">{stats.bestStreak}</span>
              <span className="text-xs text-slate-500">/ 10 seguidos</span>
            </div>
            {/* Progress to Perfect Streak 10 */}
            <div className="w-full h-1.5 bg-slate-800 rounded-full mt-1.5 overflow-hidden">
              <div
                className="h-full bg-amber-500 rounded-full transition-all duration-500"
                style={{ width: `${Math.min(100, Math.round((stats.bestStreak / 10) * 100))}%` }}
              />
            </div>
          </div>

          {/* Stat 3: Medallas Coleccionadas */}
          <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col justify-between">
            <div className="flex items-center justify-between text-slate-400 text-[11px] font-bold">
              <span className="flex items-center gap-1">
                <Trophy className="w-3.5 h-3.5 text-yellow-400" />
                Medallas
              </span>
              <span className="text-yellow-400 font-extrabold text-[10px]">{progressPercent}%</span>
            </div>
            <div className="mt-1 flex items-baseline gap-1">
              <span className="text-xl sm:text-2xl font-black text-white">{unlockedCount}</span>
              <span className="text-xs text-slate-500">/ {totalCount}</span>
            </div>
            <div className="w-full h-1.5 bg-slate-800 rounded-full mt-1.5 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-amber-400 to-yellow-300 rounded-full transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>

          {/* Stat 4: Puntuación Total */}
          <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col justify-between">
            <div className="flex items-center justify-between text-slate-400 text-[11px] font-bold">
              <span className="flex items-center gap-1">
                <Star className="w-3.5 h-3.5 text-sky-400" />
                Puntuación
              </span>
              <span className="text-sky-400 font-extrabold text-[10px]">⭐ Puntos</span>
            </div>
            <div className="mt-1 flex items-baseline gap-1">
              <span className="text-xl sm:text-2xl font-black text-white">{stats.totalScore}</span>
              <span className="text-xs text-slate-500">pts</span>
            </div>
            <div className="w-full h-1.5 bg-slate-800 rounded-full mt-1.5 overflow-hidden">
              <div
                className="h-full bg-sky-500 rounded-full transition-all duration-500"
                style={{ width: `${Math.min(100, (stats.totalScore / 500) * 100)}%` }}
              />
            </div>
          </div>
        </div>

        {/* TABS / FILTERS */}
        <div className="mt-3 flex items-center justify-between gap-1 border-b border-slate-800 pb-2">
          <div className="flex items-center gap-1.5 text-xs font-bold overflow-x-auto">
            <button
              onClick={() => setActiveFilter('all')}
              className={`px-3 py-1.5 rounded-xl transition cursor-pointer shrink-0 ${
                activeFilter === 'all'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-black'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              Todas ({totalCount})
            </button>
            <button
              onClick={() => setActiveFilter('unlocked')}
              className={`px-3 py-1.5 rounded-xl transition cursor-pointer shrink-0 flex items-center gap-1 ${
                activeFilter === 'unlocked'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-black'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
              Desbloqueadas ({unlockedCount})
            </button>
            <button
              onClick={() => setActiveFilter('progress')}
              className={`px-3 py-1.5 rounded-xl transition cursor-pointer shrink-0 flex items-center gap-1 ${
                activeFilter === 'progress'
                  ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40 font-black'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <Target className="w-3 h-3 text-sky-400" />
              En Progreso
            </button>
            <button
              onClick={() => setActiveFilter('locked')}
              className={`px-3 py-1.5 rounded-xl transition cursor-pointer shrink-0 flex items-center gap-1 ${
                activeFilter === 'locked'
                  ? 'bg-slate-700/60 text-slate-200 border border-slate-600 font-black'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <Lock className="w-3 h-3 text-slate-500" />
              Bloqueadas ({totalCount - unlockedCount})
            </button>
          </div>
        </div>

        {/* MEDALS LIST */}
        <div className="mt-3 overflow-y-auto pr-1 space-y-2.5 flex-1 min-h-[220px]">
          {filteredMedals.length === 0 ? (
            <div className="h-44 flex flex-col items-center justify-center text-slate-400 text-center p-4">
              <span className="text-3xl mb-2">🔍</span>
              <p className="text-xs font-bold text-slate-300">No hay medallas en esta categoría</p>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Cambia de filtro para explorar tus otros reconocimientos.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {filteredMedals.map((medal) => {
                const isUnlocked = unlockedIds.includes(medal.id);

                // Compute progress if target exists
                let curVal = 0;
                let targetVal = medal.targetValue || 0;
                let pct = 0;

                if (medal.statKey && medal.targetValue) {
                  const statVal = stats[medal.statKey];
                  if (typeof statVal === 'number') {
                    curVal = Math.min(statVal, medal.targetValue);
                    pct = Math.round((curVal / medal.targetValue) * 100);
                  }
                }

                return (
                  <div
                    key={medal.id}
                    className={`relative p-3.5 rounded-2xl border transition-all flex items-start gap-3 ${
                      isUnlocked
                        ? 'bg-slate-950/85 border-slate-700 shadow-md hover:border-amber-400/50'
                        : 'bg-slate-950/40 border-slate-800/60 opacity-65 hover:opacity-85'
                    }`}
                    style={
                      isUnlocked
                        ? {
                            borderColor: `${medal.borderColor}66`,
                            boxShadow: `0 4px 20px -8px ${medal.accentColor}33`
                          }
                        : {}
                    }
                  >
                    {/* Medal Icon Badge */}
                    <div
                      className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 border ${
                        isUnlocked
                          ? 'bg-slate-900 shadow-md'
                          : 'bg-slate-900/50 border-slate-800'
                      }`}
                      style={isUnlocked ? { borderColor: medal.borderColor } : {}}
                    >
                      {getIcon(medal.id, medal.icon, isUnlocked)}
                    </div>

                    {/* Medal Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1 mb-0.5">
                        <h4
                          className={`text-xs font-black truncate ${
                            isUnlocked ? 'text-white' : 'text-slate-300'
                          }`}
                        >
                          {medal.title}
                        </h4>
                        {getTierTag(medal.tier, medal.tierLabel)}
                      </div>

                      <div className="text-[11px] font-bold text-amber-400/90 mb-0.5">
                        {medal.subtitle}
                      </div>

                      <p className="text-[11px] text-slate-400 leading-snug line-clamp-2">
                        {medal.description}
                      </p>

                      {/* Progress Bar (If target exists and not unlocked or recently unlocked) */}
                      {targetVal > 1 && !isUnlocked && (
                        <div className="mt-2">
                          <div className="flex justify-between items-center text-[10px] font-bold mb-1 text-slate-400">
                            <span>Progreso:</span>
                            <span className="text-sky-300">
                              {curVal} / {targetVal} {medal.unit || ''} ({pct}%)
                            </span>
                          </div>
                          <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-sky-500 rounded-full transition-all duration-300"
                              style={{ width: `${pct}%` }}
                            />
                          </div>
                        </div>
                      )}

                      {/* Status footer */}
                      <div className="mt-2 flex items-center justify-between text-[10px]">
                        {isUnlocked ? (
                          <span className="text-emerald-400 font-extrabold flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3" />
                            ¡Desbloqueada!
                          </span>
                        ) : (
                          <span className="text-slate-500 font-semibold flex items-center gap-1">
                            <Lock className="w-2.5 h-2.5" />
                            Bloqueada
                          </span>
                        )}

                        {medal.category && (
                          <span className="text-slate-500 uppercase tracking-wider text-[9px] font-bold">
                            #{medal.category}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* FOOTER ACTIONS */}
        <div className="mt-3 pt-3 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-2.5">
          {/* Reset progress button or confirmation */}
          {!showResetConfirm ? (
            <button
              onClick={() => setShowResetConfirm(true)}
              className="text-[11px] text-slate-500 hover:text-rose-400 flex items-center gap-1 transition cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reiniciar Progreso Local</span>
            </button>
          ) : (
            <div className="flex items-center gap-2 text-xs bg-rose-950/40 border border-rose-500/40 px-3 py-1.5 rounded-xl">
              <span className="text-rose-300 text-[11px] font-bold">¿Borrar medallas y estadísticas?</span>
              <button
                onClick={handleResetProgress}
                className="px-2 py-0.5 rounded bg-rose-600 hover:bg-rose-500 text-white font-bold text-[10px] cursor-pointer"
              >
                Sí, borrar
              </button>
              <button
                onClick={() => setShowResetConfirm(false)}
                className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] cursor-pointer"
              >
                Cancelar
              </button>
            </div>
          )}

          <button
            onClick={() => {
              sound.playGrab();
              onClose();
            }}
            className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-amber-500/20 transition cursor-pointer"
          >
            Cerrar Vitrina
          </button>
        </div>

      </div>
    </div>
  );
};
