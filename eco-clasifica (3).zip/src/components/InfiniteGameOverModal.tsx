import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Trophy, RotateCcw, Home, Award, Sparkles, Flame, Zap, Infinity, CheckCircle2, XCircle } from 'lucide-react';
import { RoundResult } from '../types';

interface InfiniteGameOverModalProps {
  score: number;
  itemsSorted: number;
  bestStreak: number;
  isNewRecord: boolean;
  bestHistoricScore: number;
  history: RoundResult[];
  onPlayAgain: () => void;
  onSwitchToLevels: () => void;
  onHome: () => void;
  onShowMedals?: () => void;
}

export const InfiniteGameOverModal: React.FC<InfiniteGameOverModalProps> = ({
  score,
  itemsSorted,
  bestStreak,
  isNewRecord,
  bestHistoricScore,
  history,
  onPlayAgain,
  onSwitchToLevels,
  onHome,
  onShowMedals
}) => {
  useEffect(() => {
    if (isNewRecord || itemsSorted >= 15) {
      try {
        confetti({
          particleCount: isNewRecord ? 90 : 50,
          spread: 75,
          origin: { y: 0.5 },
          disableForReducedMotion: true
        });
      } catch {}
    }
  }, [isNewRecord, itemsSorted]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/85 backdrop-blur-md select-none animate-fade-in">
      <div className="w-full max-w-lg bg-slate-900 border border-purple-500/40 rounded-2xl p-4 sm:p-5 shadow-2xl flex flex-col items-center text-center max-h-[92vh] overflow-y-auto">
        {/* Floating Infinity Icon */}
        <div className="relative mb-2">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-purple-600 via-pink-600 to-amber-500 flex items-center justify-center shadow-md shadow-purple-500/30">
            <Infinity className="w-7 h-7 text-white" />
          </div>
          {isNewRecord && (
            <span className="absolute -top-2 -right-2 px-1.5 py-0.2 rounded-full bg-amber-400 text-slate-950 text-[9px] font-black uppercase tracking-wider shadow-sm animate-bounce">
              ¡RÉCORD!
            </span>
          )}
        </div>

        {/* Title */}
        <h2 className="text-xl sm:text-2xl font-black text-white uppercase tracking-tight">
          ¡FIN DE LA RONDA INFINITA!
        </h2>

        {isNewRecord ? (
          <div className="mt-1 inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-400/20 border border-amber-400/50 text-amber-300 font-bold text-xs">
            <Trophy className="w-3.5 h-3.5 text-amber-400" />
            <span>🎉 ¡NUEVO RÉCORD HISTÓRICO! Superaste tu marca previa.</span>
          </div>
        ) : (
          <p className="text-[11px] text-slate-300 mt-0.5 max-w-sm">
            Excelente sesión de clasificación sin fin. ¡Sigue practicando para batir tu récord de {bestHistoricScore} pts!
          </p>
        )}

        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-2 w-full my-3">
          {/* Total Score */}
          <div className="bg-slate-800/80 border border-amber-500/30 rounded-xl p-2.5 flex flex-col items-center">
            <span className="text-[10px] sm:text-xs font-black text-amber-400 uppercase">⭐ Puntos</span>
            <span className="text-2xl sm:text-3xl font-black text-white mt-0.5">{score}</span>
            <span className="text-[9px] text-slate-400">Récord: {bestHistoricScore}</span>
          </div>

          {/* Items Classified */}
          <div className="bg-slate-800/80 border border-purple-500/30 rounded-xl p-2.5 flex flex-col items-center">
            <span className="text-[10px] sm:text-xs font-black text-purple-400 uppercase">📦 Residuos</span>
            <span className="text-2xl sm:text-3xl font-black text-white mt-0.5">{itemsSorted}</span>
            <span className="text-[9px] text-slate-400">clasificados</span>
          </div>

          {/* Max Streak */}
          <div className="bg-slate-800/80 border border-rose-500/30 rounded-xl p-2.5 flex flex-col items-center">
            <span className="text-[10px] sm:text-xs font-black text-rose-400 uppercase">🔥 Mejor Racha</span>
            <span className="text-2xl sm:text-3xl font-black text-white mt-0.5">x{bestStreak}</span>
            <span className="text-[9px] text-slate-400">aciertos seguidos</span>
          </div>
        </div>

        {/* Recent Items History (last 8) */}
        {history.length > 0 && (
          <div className="w-full bg-slate-950/60 rounded-xl p-2 border border-slate-800 mb-3 max-h-24 overflow-y-auto">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1 text-left">
              Últimos residuos jugados:
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1">
              {history.slice(-8).map((h, i) => (
                <div
                  key={i}
                  className={`flex items-center gap-1 p-1 rounded-md text-[10px] font-semibold border ${
                    h.isCorrect
                      ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                      : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                  }`}
                >
                  <span>{h.item.emoji}</span>
                  <span className="truncate flex-1 text-left">{h.item.nombre}</span>
                  {h.isCorrect ? (
                    <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                  ) : (
                    <XCircle className="w-3 h-3 text-rose-400 shrink-0" />
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="w-full space-y-1.5">
          <button
            onClick={onPlayAgain}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-black text-xs sm:text-sm uppercase tracking-wider bg-gradient-to-r from-purple-600 to-amber-500 hover:from-purple-500 hover:to-amber-400 text-white shadow-md shadow-purple-500/20 hover:scale-[1.01] active:scale-[0.99] transition cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>JUGAR DE NUEVO (MODO INFINITO)</span>
          </button>

          <div className="grid grid-cols-2 gap-1.5">
            <button
              onClick={onSwitchToLevels}
              className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl font-bold text-xs uppercase text-emerald-300 hover:text-white bg-emerald-950/40 hover:bg-emerald-900/60 border border-emerald-500/30 transition cursor-pointer"
            >
              <Zap className="w-3.5 h-3.5 text-emerald-400" />
              <span>MODO NIVELES (1-10)</span>
            </button>

            <button
              onClick={onHome}
              className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl font-bold text-xs uppercase text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 transition cursor-pointer"
            >
              <Home className="w-3.5 h-3.5" />
              <span>MENÚ PRINCIPAL</span>
            </button>
          </div>

          {onShowMedals && (
            <button
              onClick={onShowMedals}
              className="w-full flex items-center justify-center gap-1.5 py-1 text-xs font-bold text-amber-300 hover:text-amber-100 transition cursor-pointer"
            >
              <Award className="w-3.5 h-3.5" />
              <span>Ver Medallas y Logros</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
