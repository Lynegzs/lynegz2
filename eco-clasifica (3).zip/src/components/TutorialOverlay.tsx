import React, { useState, useEffect } from 'react';
import { Sparkles, CheckCircle2, ArrowRight, Play, Eye, RotateCcw, X, Info } from 'lucide-react';
import { sound } from '../utils/audio';

interface TutorialOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  handDetected?: boolean;
  isPinching?: boolean;
  pinchDistance?: number;
}

export const TutorialOverlay: React.FC<TutorialOverlayProps> = ({
  isOpen,
  onClose,
  handDetected = false,
  isPinching = false,
  pinchDistance = 0.2
}) => {
  const [activeStep, setActiveStep] = useState<number>(0);
  const [dontShowAgain, setDontShowAgain] = useState<boolean>(false);
  const [hasTriedPinchSuccessfully, setHasTriedPinchSuccessfully] = useState<boolean>(false);

  // When player tries real pinch during tutorial, reward them with a success state
  useEffect(() => {
    if (isPinching && handDetected && !hasTriedPinchSuccessfully) {
      setHasTriedPinchSuccessfully(true);
      sound.playGrab();
    }
  }, [isPinching, handDetected, hasTriedPinchSuccessfully]);

  if (!isOpen) return null;

  const handleFinish = () => {
    sound.playCorrect();
    if (dontShowAgain) {
      try {
        localStorage.setItem('eco_tutorial_seen', 'true');
      } catch {
        // LocalStorage quota/sandbox safe fallback
      }
    }
    onClose();
  };

  const steps = [
    {
      num: 1,
      title: 'Apunta con tu mano',
      desc: 'Coloca tu mano frente a la cámara a una distancia cómoda (50cm a 1m). El cursor verde en pantalla seguirá la palma y dedos de tu mano en tiempo real.'
    },
    {
      num: 2,
      title: 'Gesto de Pinza (Pinch)',
      desc: 'Coloca el cursor sobre el residuo flotante. Junta las puntas de tu dedo índice y pulgar como si pellizcaras algo pequeño. El residuo quedará agarrado.'
    },
    {
      num: 3,
      title: 'Arrastra al contenedor',
      desc: 'Sin separar tus dedos, desplaza tu mano hacia abajo donde se encuentra el contenedor del color correspondiente (Verde, Azul, Gris o Rojo).'
    },
    {
      num: 4,
      title: 'Abre los dedos para soltar',
      desc: 'Cuando el residuo esté encima de la boca del contenedor, abre o separa tus dedos. El residuo caerá automáticamente sumando puntos a tu marcador.'
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/85 backdrop-blur-md select-none overflow-y-auto animate-fade-in">
      <div className="relative w-full max-w-2xl bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border border-emerald-500/40 rounded-3xl shadow-2xl p-5 sm:p-7 flex flex-col my-auto max-h-[95vh] overflow-y-auto">
        
        {/* Close Button top-right */}
        <button
          onClick={handleFinish}
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
          title="Cerrar tutorial"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Title */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center shadow-lg shadow-emerald-500/20 text-slate-950 font-black shrink-0">
            <span className="text-xl">🤏</span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] sm:text-xs font-black tracking-wider text-emerald-400 uppercase">
                TUTORIAL VISUAL INTERACTIVO
              </span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold">
                Paso a Paso
              </span>
            </div>
            <h2 className="text-lg sm:text-2xl font-black text-white tracking-tight">
              ¿Cómo hacer el gesto de pinza?
            </h2>
          </div>
        </div>

        {/* MAIN VISUAL ANIMATION THEATER */}
        <div className="relative w-full h-56 sm:h-64 rounded-2xl bg-slate-950 border border-slate-800 overflow-hidden flex flex-col items-center justify-between p-3 sm:p-4 mb-4 shadow-inner">
          
          {/* Subtle grid background */}
          <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:20px_20px] pointer-events-none" />

          {/* Top banner indicator of the cycle */}
          <div className="relative z-10 w-full flex items-center justify-between">
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900/90 border border-emerald-500/30 text-[11px] font-bold text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Simulación animada en bucle</span>
            </div>

            {/* Live Camera Hand Feedback Badge */}
            <div className={`flex items-center gap-2 px-3 py-1 rounded-full text-[11px] font-bold border transition ${
              handDetected 
                ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300' 
                : 'bg-slate-800/80 border-slate-700 text-slate-400'
            }`}>
              <span>{handDetected ? '🖐️ Tu mano está en pantalla' : '👀 Coloca tu mano frente a la cámara'}</span>
            </div>
          </div>

          {/* Central Simulation Stage */}
          <div className="relative w-full flex-1 flex items-center justify-center">
            
            {/* Target Waste Item (Botella de plástico) */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20 flex flex-col items-center animate-tutorial-waste">
              <div className="relative w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-br from-blue-500/30 to-indigo-600/40 border-2 border-blue-400/80 flex items-center justify-center shadow-lg shadow-blue-500/30">
                <span className="text-3xl sm:text-4xl filter drop-shadow">🍾</span>
                
                {/* Pinch target reticle with pulsating lock ring */}
                <div className="absolute -inset-2 rounded-3xl border border-dashed border-emerald-400/60 animate-spin-slow pointer-events-none" />
                <div className="absolute -inset-1 rounded-2xl bg-emerald-400/10 pointer-events-none" />
              </div>
              <span className="mt-1.5 px-2 py-0.5 rounded-full bg-blue-950/90 text-blue-200 border border-blue-500/30 text-[10px] font-extrabold uppercase">
                Botella de Plástico
              </span>
            </div>

            {/* Target Recycling Bin (Below) */}
            <div className="absolute bottom-1 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center pointer-events-none opacity-85">
              <div className="w-28 sm:w-36 h-10 sm:h-12 rounded-t-xl bg-gradient-to-b from-blue-600 to-blue-800 border-2 border-blue-400 flex items-center justify-center shadow-lg shadow-blue-500/20 text-white font-black text-xs uppercase tracking-wider">
                <span>🗑️ PLÁSTICOS</span>
              </div>
            </div>

            {/* ANIMATED VECTOR HAND DEMONSTRATING PINCH */}
            <div className="absolute top-1/2 left-1/2 z-30 pointer-events-none animate-tutorial-cycle">
              <div className="relative w-36 h-36 -translate-x-12 -translate-y-16">
                
                {/* Visual SVG Hand */}
                <svg
                  viewBox="0 0 160 160"
                  className="w-full h-full drop-shadow-[0_10px_20px_rgba(0,0,0,0.8)] filter"
                >
                  {/* Palm base */}
                  <path
                    d="M 60 90 C 50 115, 75 145, 95 130 C 115 115, 110 85, 95 75 Z"
                    fill="#10b981"
                    opacity="0.85"
                  />

                  {/* Middle, Ring, Pinky curled backwards for clean pinch silhouette */}
                  <path
                    d="M 95 75 C 105 60, 118 68, 112 80 C 108 88, 100 88, 95 82"
                    stroke="#059669"
                    strokeWidth="8"
                    strokeLinecap="round"
                    fill="none"
                  />
                  <path
                    d="M 98 86 C 110 76, 120 84, 114 94 C 110 100, 102 98, 98 94"
                    stroke="#047857"
                    strokeWidth="8"
                    strokeLinecap="round"
                    fill="none"
                  />

                  {/* Index Finger (Animated curl touching thumb) */}
                  <g className="animate-finger-pinch">
                    <path
                      d="M 70 70 C 60 45, 52 28, 42 32 C 34 35, 38 52, 48 68"
                      stroke="#34d399"
                      strokeWidth="11"
                      strokeLinecap="round"
                      fill="none"
                    />
                    {/* Index fingertip sensor point */}
                    <circle cx="42" cy="32" r="6" fill="#a7f3d0" />
                  </g>

                  {/* Thumb (Animated angle meeting index tip) */}
                  <g className="animate-thumb-pinch">
                    <path
                      d="M 55 95 C 40 85, 26 75, 28 65 C 30 55, 42 62, 52 75"
                      stroke="#10b981"
                      strokeWidth="12"
                      strokeLinecap="round"
                      fill="none"
                    />
                    {/* Thumb fingertip sensor point */}
                    <circle cx="28" cy="65" r="6.5" fill="#a7f3d0" />
                  </g>

                  {/* Contact Pinch Spark & Energy Ring (Explodes when tips meet) */}
                  <g className="animate-pinch-spark">
                    <circle cx="34" cy="46" r="16" fill="none" stroke="#facc15" strokeWidth="3" opacity="0.9" />
                    <circle cx="34" cy="46" r="8" fill="#fef08a" />
                    <polygon
                      points="34,30 38,42 50,46 38,50 34,62 30,50 18,46 30,42"
                      fill="#ffffff"
                    />
                  </g>
                </svg>

                {/* Hand label badge */}
                <div className="absolute -top-3 left-4 px-2 py-0.5 rounded-full bg-emerald-500 text-slate-950 font-black text-[9px] uppercase tracking-wider shadow">
                  Tu Mano (Pinza)
                </div>
              </div>
            </div>

          </div>

          {/* Bottom live prompt within the theater */}
          <div className="relative z-10 w-full flex items-center justify-between text-[11px] text-slate-300">
            <div className="flex items-center gap-1.5 font-bold">
              <span className="text-amber-400">💡 Tip:</span>
              <span>Junta el pulgar y el índice como un compás sobre el objeto.</span>
            </div>

            {hasTriedPinchSuccessfully ? (
              <span className="text-emerald-400 font-extrabold flex items-center gap-1 animate-bounce">
                <CheckCircle2 className="w-3.5 h-3.5" /> ¡Has probado la pinza con éxito!
              </span>
            ) : isPinching ? (
              <span className="text-emerald-300 font-extrabold flex items-center gap-1 animate-pulse">
                <span>🤏</span> ¡Pinza detectada ahora mismo!
              </span>
            ) : (
              <span className="text-slate-400 text-[10px]">
                {handDetected ? 'Junta tus dedos para probar aquí' : 'Muestra tu mano para probar'}
              </span>
            )}
          </div>
        </div>

        {/* STEP-BY-STEP EXPLANATION TABS */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-4">
          {steps.map((st, idx) => {
            const isSelected = activeStep === idx;
            return (
              <button
                key={st.num}
                onClick={() => setActiveStep(idx)}
                className={`p-2.5 rounded-xl border text-left transition cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'bg-emerald-500/15 border-emerald-500 text-white shadow-md shadow-emerald-500/10'
                    : 'bg-slate-800/40 border-slate-700/60 hover:bg-slate-800/70 text-slate-400'
                }`}
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <span className={`text-[10px] font-black px-1.5 py-0.2 rounded-md ${
                    isSelected ? 'bg-emerald-500 text-slate-950' : 'bg-slate-700 text-slate-300'
                  }`}>
                    PASO {st.num}
                  </span>
                  {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />}
                </div>
                <div className="text-xs font-bold leading-tight line-clamp-1 text-slate-200">
                  {st.title}
                </div>
              </button>
            );
          })}
        </div>

        {/* Selected Step Description Box */}
        <div className="p-3.5 sm:p-4 rounded-2xl bg-slate-950/70 border border-slate-800 flex items-start gap-3 mb-4">
          <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-black text-sm shrink-0 border border-emerald-500/30">
            {steps[activeStep].num}
          </div>
          <div className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            <strong className="text-emerald-400 block mb-0.5">{steps[activeStep].title}:</strong>
            {steps[activeStep].desc}
          </div>
        </div>

        {/* PRO-TIPS FOR BEST AR EXPERIENCE */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 mb-5 text-[11px] text-slate-300">
          <div className="p-2.5 rounded-xl bg-slate-800/40 border border-slate-800 flex items-center gap-2">
            <span className="text-base">💡</span>
            <span><strong>Iluminación:</strong> Juega en un lugar bien iluminado sin contraluz.</span>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-800/40 border border-slate-800 flex items-center gap-2">
            <span className="text-base">📐</span>
            <span><strong>Distancia:</strong> Mantén tu mano a 50cm – 80cm de la cámara.</span>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-800/40 border border-slate-800 flex items-center gap-2">
            <span className="text-base">✋</span>
            <span><strong>Palma visible:</strong> Orienta la palma de la mano hacia el lente.</span>
          </div>
        </div>

        {/* FOOTER ACTIONS */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-slate-800 mt-auto">
          {/* Don't show again checkbox */}
          <label className="flex items-center gap-2 text-xs text-slate-400 hover:text-slate-200 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={dontShowAgain}
              onChange={(e) => setDontShowAgain(e.target.checked)}
              className="w-4 h-4 rounded bg-slate-800 border-slate-700 text-emerald-500 focus:ring-emerald-400 focus:ring-offset-slate-900 cursor-pointer"
            />
            <span>No volver a mostrar al iniciar</span>
          </label>

          {/* Primary Action Button */}
          <button
            onClick={handleFinish}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-7 py-3.5 rounded-2xl font-black text-sm sm:text-base uppercase tracking-wider bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 shadow-xl shadow-emerald-500/25 hover:scale-102 active:scale-98 transition cursor-pointer"
          >
            <span>¡ENTENDIDO, A JUGAR!</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>

      </div>
    </div>
  );
};
