import React, { useState, useEffect } from 'react';
import { Music, Play, Pause, Volume2, VolumeX, SkipForward, Sparkles, ShieldCheck, Shuffle, X, Disc3 } from 'lucide-react';
import { bgm, BGM_TRACKS, BgmTrackId } from '../utils/bgm';
import { sound } from '../utils/audio';

interface MusicModalProps {
  onClose: () => void;
}

export const MusicModal: React.FC<MusicModalProps> = ({ onClose }) => {
  const [isPlaying, setIsPlaying] = useState<boolean>(() => bgm.getIsPlaying());
  const [currentTrack, setCurrentTrack] = useState(() => bgm.getCurrentTrack());
  const [isInfiniteMode, setIsInfiniteMode] = useState<boolean>(() => bgm.getIsInfiniteMode());
  const [volume, setVolume] = useState<number>(() => bgm.getVolume());

  useEffect(() => {
    const unsubscribe = bgm.subscribe(() => {
      setIsPlaying(bgm.getIsPlaying());
      setCurrentTrack(bgm.getCurrentTrack());
      setIsInfiniteMode(bgm.getIsInfiniteMode());
      setVolume(bgm.getVolume());
    });
    return unsubscribe;
  }, []);

  const handleTogglePlay = () => {
    sound.playGrab();
    bgm.toggle();
  };

  const handleNextTrack = () => {
    sound.playGrab();
    bgm.nextTrack();
  };

  const handleSelectTrack = (trackId: BgmTrackId) => {
    sound.playGrab();
    bgm.setTrack(trackId);
    if (!isPlaying) {
      bgm.play();
    }
  };

  const handleStartShuffle = () => {
    sound.playGrab();
    bgm.startInfiniteModeShuffle();
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    bgm.setVolume(val);
  };

  const handleToggleMute = () => {
    sound.playGrab();
    if (volume > 0) {
      bgm.setVolume(0);
    } else {
      bgm.setVolume(0.25);
      if (!isPlaying) bgm.play();
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in"
      onClick={onClose}
    >
      <div
        className="w-full max-w-xl bg-slate-900 border border-slate-700/80 rounded-2xl p-3.5 sm:p-4 shadow-2xl flex flex-col max-h-[92vh] my-auto overflow-hidden text-slate-100"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-2.5 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-teal-500 via-emerald-400 to-cyan-400 p-0.5 flex items-center justify-center shadow-md shadow-teal-500/20 shrink-0">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <Music className="w-4 h-4 sm:w-5 sm:h-5 text-teal-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-black tracking-wider text-teal-400 uppercase">
                  BANDA SONORA PROCEDURAL
                </span>
                <span className="px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[8px] font-black uppercase tracking-wider flex items-center gap-0.5">
                  <ShieldCheck className="w-2.5 h-2.5 text-emerald-400" />
                  Sin Copyright
                </span>
              </div>
              <h2 className="text-sm sm:text-base font-black text-white flex items-center gap-1.5 tracking-tight">
                10 Canciones Originales del Juego
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              </h2>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playGrab();
              onClose();
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
            title="Cerrar reproductor"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="overflow-y-auto pr-1 space-y-2.5 my-2.5 flex-1">
          {/* Now Playing Banner */}
          <div className="p-3.5 sm:p-4 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-inner">
            <div className="flex items-center gap-3 w-full sm:w-auto">
              <div className="relative">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shadow-md ${
                  isPlaying
                    ? 'bg-gradient-to-tr from-emerald-500/30 to-teal-500/30 border border-emerald-500/50'
                    : 'bg-slate-800 border border-slate-700'
                }`}>
                  {currentTrack.emoji}
                </div>
                {isPlaying && (
                  <span className="absolute -bottom-1 -right-1 flex h-3 w-3">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500" />
                  </span>
                )}
              </div>

              <div className="text-left flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[9px] font-black uppercase">
                    Nivel {currentTrack.level}
                  </span>
                  {isInfiniteMode && (
                    <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[9px] font-black uppercase flex items-center gap-0.5">
                      <Shuffle className="w-2.5 h-2.5" /> Aleatorio Infinito
                    </span>
                  )}
                  <span className="text-[10px] text-slate-400 font-bold">{currentTrack.bpm} BPM</span>
                </div>
                <div className="text-sm sm:text-base font-black text-white truncate mt-0.5">
                  {currentTrack.name}
                </div>
                <div className="text-[11px] text-slate-400 truncate">
                  {currentTrack.style}
                </div>
              </div>
            </div>

            {/* Quick Player Controls */}
            <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
              <button
                onClick={handleStartShuffle}
                title="Modo aleatorio para Modo Infinito (sin repetir canción anterior)"
                className={`p-2.5 rounded-xl font-bold text-xs transition cursor-pointer flex items-center gap-1.5 border ${
                  isInfiniteMode
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-sm'
                    : 'bg-slate-800 hover:bg-slate-750 text-slate-300 border-slate-700'
                }`}
              >
                <Shuffle className="w-4 h-4 text-amber-400" />
                <span className="text-[11px]">Aleatorio</span>
              </button>

              <button
                onClick={handleNextTrack}
                title="Siguiente pista"
                className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition cursor-pointer"
              >
                <SkipForward className="w-4 h-4" />
              </button>

              <button
                onClick={handleTogglePlay}
                className={`px-4 py-2.5 rounded-xl font-black text-xs transition cursor-pointer flex items-center gap-2 shadow-lg ${
                  isPlaying
                    ? 'bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40'
                    : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-emerald-500/20'
                }`}
              >
                {isPlaying ? (
                  <>
                    <Pause className="w-4 h-4 fill-current" />
                    <span>PAUSAR</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-current" />
                    <span>REPRODUCIR</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Volume Control Bar */}
          <div className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <button
                onClick={handleToggleMute}
                title={volume === 0 ? 'Activar sonido' : 'Silenciar'}
                className="p-1 rounded-lg text-slate-400 hover:text-emerald-400 transition cursor-pointer"
              >
                {volume === 0 ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
              </button>
              <span className="text-xs font-bold text-slate-300">Volumen de Música:</span>
            </div>

            <div className="flex items-center gap-2 flex-1 max-w-xs">
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={volume}
                onChange={handleVolumeChange}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
              />
              <span className="text-xs font-bold text-emerald-400 w-9 text-right">
                {Math.round(volume * 100)}%
              </span>
            </div>
          </div>

          {/* 10 Tracks Grid Header */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Disc3 className="w-3.5 h-3.5 text-teal-400" />
                Colección Completa (1 Canción por Nivel)
              </span>
              <span className="text-[11px] text-slate-400">
                Haz clic en cualquier canción para escucharla
              </span>
            </div>

            {/* Grid of 10 tracks */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {BGM_TRACKS.map((t) => {
                const isCurrent = currentTrack.id === t.id;
                return (
                  <button
                    key={t.id}
                    onClick={() => handleSelectTrack(t.id)}
                    className={`p-2.5 rounded-2xl text-left transition border cursor-pointer flex items-center justify-between gap-2.5 ${
                      isCurrent
                        ? 'bg-emerald-950/60 border-emerald-400 text-white shadow-md shadow-emerald-500/10 ring-1 ring-emerald-400'
                        : 'bg-slate-850/80 border-slate-800 hover:border-slate-700 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-9 h-9 rounded-xl bg-slate-900 border border-slate-700/80 flex items-center justify-center text-lg shrink-0">
                        {t.emoji}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="px-1.5 py-0.2 rounded bg-slate-900 text-[9px] font-black text-emerald-400">
                            NIVEL {t.level}
                          </span>
                          <span className="text-xs font-bold truncate text-white">
                            {t.name}
                          </span>
                        </div>
                        <div className="text-[10px] text-slate-400 truncate">
                          {t.style}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span className="text-[10px] font-mono text-slate-400">{t.bpm} BPM</span>
                      {isCurrent && isPlaying ? (
                        <span className="flex items-end gap-0.5 h-3 w-3">
                          <span className="w-0.5 bg-emerald-400 h-full animate-[pulse_0.6s_ease-in-out_infinite]" />
                          <span className="w-0.5 bg-teal-300 h-2/3 animate-[pulse_0.4s_ease-in-out_infinite_0.2s]" />
                          <span className="w-0.5 bg-emerald-400 h-4/5 animate-[pulse_0.8s_ease-in-out_infinite_0.4s]" />
                        </span>
                      ) : (
                        <div className="w-6 h-6 rounded-full bg-slate-800 flex items-center justify-center text-slate-400 group-hover:text-white">
                          <Play className="w-3 h-3 fill-current ml-0.5" />
                        </div>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-1.5 text-slate-400 text-[11px]">
            <Sparkles className="w-3.5 h-3.5 text-teal-400 shrink-0" />
            <span>Música sintetizada proceduralmente con Web Audio API (cero descargas, cero copyright).</span>
          </div>

          <button
            onClick={() => {
              sound.playGrab();
              onClose();
            }}
            className="w-full sm:w-auto px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold transition cursor-pointer"
          >
            Listo / Volver al Menú
          </button>
        </div>
      </div>
    </div>
  );
};
