import React from 'react';
import { WasteItem } from '../types';

interface WasteGraphicProps {
  item: WasteItem;
  className?: string;
}

/**
 * Returns the exact graphic archetype identifier for any of the 100 items
 */
export function getGraphicArchetype(item: WasteItem): string {
  // Explicit ID mapping for all 100 items across all 10 levels
  const idMap: Record<number, string> = {
    // NIVEL 1: Iniciación Básica
    1: 'banana',
    2: 'pet_bottle',
    3: 'apple',
    4: 'paper_sheet',
    5: 'battery',
    6: 'soda_can',
    7: 'greasy_napkin',
    8: 'glass_bottle',
    9: 'vegetable_salad',
    10: 'syringe',

    // NIVEL 2: Hogar Cotidiano
    11: 'cardboard_box',
    12: 'diaper',
    13: 'coffee_grounds',
    14: 'thermometer',
    15: 'juice_box',
    16: 'leaves',
    17: 'plastic_cup',
    18: 'dust_pan',
    19: 'toothpaste',
    20: 'blister_pack',

    // NIVEL 3: Cocina y Alimentos
    21: 'egg_shell',
    22: 'pizza_box',
    23: 'tuna_can',
    24: 'chicken_bone',
    25: 'paper_towel',
    26: 'glass_jar',
    27: 'tea_bag',
    28: 'bottle_caps',
    29: 'plastic_wrap',
    30: 'spray_can_toxic',

    // NIVEL 4: Oficina y Estudio
    31: 'paper_clips',
    32: 'ticket',
    33: 'newspaper',
    34: 'tape_roll',
    35: 'tippex',
    36: 'magazine',
    37: 'ballpoint_pen',
    38: 'highlighter',
    39: 'button_battery',
    40: 'citrus',

    // NIVEL 5: Baño y Cuidado Personal
    41: 'toothbrush',
    42: 'shampoo_bottle',
    43: 'cotton_swab',
    44: 'syrup_bottle',
    45: 'makeup_pad',
    46: 'perfume_bottle',
    47: 'nail_polish',
    48: 'wet_wipes',
    49: 'cream_jar',
    50: 'razor',

    // NIVEL 6: Trampas Frecuentes
    51: 'takeout_cup',
    52: 'foil_clean',
    53: 'foil_dirty',
    54: 'garden_pruning',
    55: 'lightbulb',
    56: 'fluorescent_tube',
    57: 'plastic_caps',
    58: 'broken_mirror',
    59: 'swollen_battery',
    60: 'yogurt_pot',

    // NIVEL 7: Garaje y Taller
    61: 'usb_cable',
    62: 'paint_can',
    63: 'bleach_bottle',
    64: 'solvent_flask',
    65: 'cd_disc',
    66: 'toner_cartridge',
    67: 'rechargeable_battery',
    68: 'wine_cork',
    69: 'silicone_stopper',
    70: 'oily_rag',

    // NIVEL 8: Residuos Especiales
    71: 'ceramic_plate',
    72: 'compost_bag',
    73: 'chewing_gum',
    74: 'wood_ash',
    75: 'coal_ash',
    76: 'snack_bag',
    77: 'glass_medicine_jar',
    78: 'bloody_gauze',
    79: 'lighter',
    80: 'rollon_deodorant',

    // NIVEL 9: Nivel Experto
    81: 'xray',
    82: 'coffee_filter',
    83: 'superglue',
    84: 'dental_floss',
    85: 'baking_paper',
    86: 'sardine_can',
    87: 'aerosol_deodorant',
    88: 'surgical_mask',
    89: 'coffee_pod',
    90: 'seashells',

    // NIVEL 10: Maestría Ambiental
    91: 'window_glass',
    92: 'styrofoam_tray',
    93: 'burger_box',
    94: 'watch_battery',
    95: 'sponge',
    96: 'fish_bones',
    97: 'ammonia_bottle',
    98: 'syringe_needleless',
    99: 'chamomile_bag',
    100: 'acetone_bottle',

    // 60 RESIDUOS EXTENDIDOS (101 a 160)
    101: 'juice_box',
    102: 'apple',
    103: 'chewing_gum',
    104: 'bleach_bottle',
    105: 'thermometer',
    106: 'wine_cork',
    107: 'tuna_can',
    108: 'egg_shell',
    109: 'surgical_mask',
    110: 'swollen_battery',
    111: 'glass_jar',
    112: 'tea_bag',
    113: 'ceramic_plate',
    114: 'lighter',
    115: 'spray_can_toxic',
    116: 'wine_cork',
    117: 'cardboard_box',
    118: 'coffee_grounds',
    119: 'broken_mirror',
    120: 'syrup_bottle',
    121: 'usb_cable',
    122: 'fish_bones',
    123: 'newspaper',
    124: 'greasy_napkin',
    125: 'paint_can',
    126: 'bleach_bottle',
    127: 'fluorescent_tube',
    128: 'snack_bag',
    129: 'cardboard_box',
    130: 'paper_sheet',
    131: 'garden_pruning',
    132: 'toothbrush',
    133: 'takeout_cup',
    134: 'leaves',
    135: 'toner_cartridge',
    136: 'paper_sheet',
    137: 'paper_clips',
    138: 'egg_shell',
    139: 'compost_bag',
    140: 'tape_roll',
    141: 'aerosol_deodorant',
    142: 'cotton_swab',
    143: 'blister_pack',
    144: 'diaper',
    145: 'vegetable_salad',
    146: 'makeup_pad',
    147: 'perfume_bottle',
    148: 'razor',
    149: 'cd_disc',
    150: 'foil_dirty',
    151: 'vegetable_salad',
    152: 'sardine_can',
    153: 'oily_rag',
    154: 'plastic_cup',
    155: 'cotton_swab',
    156: 'chicken_bone',
    157: 'toothpaste',
    158: 'battery',
    159: 'magazine',
    160: 'ceramic_plate'
  };

  if (idMap[item.id]) {
    return idMap[item.id];
  }

  return 'generic';
}

export const WasteGraphic: React.FC<WasteGraphicProps> = ({
  item,
  className = "w-full h-full"
}) => {
  const archetype = getGraphicArchetype(item);

  switch (archetype) {
    // 1: Banana
    case 'banana':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M48 16 C50 12 53 12 54 16 L52 24 L47 24 Z" fill="#713f12" />
          <path d="M47 24 C44 38 45 52 49 60 C53 52 54 38 52 24 Z" fill="#fef9c3" stroke="#ca8a04" strokeWidth="1" />
          <path d="M48 24 C40 32 20 42 14 58 C10 68 18 72 24 68 C34 60 42 46 46 36 Z" fill="#facc15" stroke="#a16207" strokeWidth="1.5" />
          <path d="M52 24 C60 32 80 42 86 58 C90 68 82 72 76 68 C66 60 58 46 54 36 Z" fill="#eab308" stroke="#a16207" strokeWidth="1.5" />
          <path d="M46 38 C42 55 36 75 48 85 C54 75 56 55 53 38 Z" fill="#ca8a04" stroke="#854d0e" strokeWidth="1.5" />
          <circle cx="20" cy="65" r="2.5" fill="#713f12" />
          <circle cx="80" cy="65" r="2.5" fill="#713f12" />
          <circle cx="48" cy="83" r="3" fill="#713f12" />
        </svg>
      );

    // 2: Botella PET
    case 'pet_bottle':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="42" y="14" width="16" height="8" rx="2" fill="#2563eb" stroke="#1d4ed8" strokeWidth="1.5" />
          <path d="M45 22 L45 28 L34 38 L34 82 C34 86 38 88 42 88 L58 88 C62 88 66 86 66 82 L66 38 L55 28 L55 22 Z" fill="#93c5fd" fillOpacity="0.4" stroke="#3b82f6" strokeWidth="2" />
          <rect x="36" y="52" width="28" height="18" rx="2" fill="#60a5fa" fillOpacity="0.7" />
          <path d="M42 38 L42 82 M50 38 L50 82 M58 38 L58 82" stroke="#60a5fa" strokeWidth="1" strokeDasharray="3 3" opacity="0.6" />
        </svg>
      );

    // 3: Manzana mordida
    case 'apple':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M50 20 C48 10 58 8 58 8" stroke="#713f12" strokeWidth="3" strokeLinecap="round" />
          <path d="M54 12 C62 10 66 14 62 18 C58 20 54 16 54 12 Z" fill="#22c55e" stroke="#15803d" strokeWidth="1" />
          <path d="M50 24 C40 24 24 30 24 50 C24 72 38 86 48 86 C50 86 50 84 52 84 C54 84 54 86 56 86 C66 86 80 72 80 50 C80 44 76 40 72 40 C66 40 68 48 64 54 C60 60 56 56 56 50 C56 42 66 34 68 28 C64 24 56 24 50 24 Z" fill="#ef4444" stroke="#b91c1c" strokeWidth="2" />
          <ellipse cx="64" cy="46" rx="4" ry="7" fill="#fef08a" />
          <ellipse cx="65" cy="46" rx="1.5" ry="3" fill="#713f12" />
        </svg>
      );

    // 4: Hoja de libreta
    case 'paper_sheet':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M26 16 L62 16 L74 28 L74 84 L26 84 Z" fill="#f8fafc" stroke="#94a3b8" strokeWidth="2" />
          <path d="M62 16 L62 28 L74 28 Z" fill="#cbd5e1" stroke="#94a3b8" strokeWidth="1.5" />
          <line x1="34" y1="36" x2="66" y2="36" stroke="#60a5fa" strokeWidth="1.5" />
          <line x1="34" y1="46" x2="66" y2="46" stroke="#93c5fd" strokeWidth="1.5" />
          <line x1="34" y1="56" x2="66" y2="56" stroke="#93c5fd" strokeWidth="1.5" />
          <line x1="34" y1="66" x2="56" y2="66" stroke="#93c5fd" strokeWidth="1.5" />
          <line x1="32" y1="20" x2="32" y2="80" stroke="#f87171" strokeWidth="1" />
        </svg>
      );

    // 5: Pila alcalina AA
    case 'battery':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="44" y="16" width="12" height="6" rx="2" fill="#d97706" />
          <rect x="34" y="22" width="32" height="64" rx="4" fill="#1e293b" stroke="#0f172a" strokeWidth="2" />
          <rect x="34" y="22" width="32" height="24" rx="3" fill="#f59e0b" />
          <text x="50" y="38" textAnchor="middle" fill="#78350f" fontSize="14" fontWeight="bold">+</text>
          <text x="50" y="74" textAnchor="middle" fill="#ef4444" fontSize="14" fontWeight="bold">-</text>
        </svg>
      );

    // 6: Lata de gaseosa
    case 'soda_can':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <ellipse cx="50" cy="22" rx="18" ry="6" fill="#cbd5e1" stroke="#64748b" strokeWidth="2" />
          <ellipse cx="50" cy="22" rx="7" ry="2.5" fill="#94a3b8" />
          <path d="M32 22 L32 78 C32 84 40 88 50 88 C60 88 68 84 68 78 L68 22" fill="#ef4444" stroke="#b91c1c" strokeWidth="2" />
          <ellipse cx="50" cy="78" rx="18" ry="6" fill="#dc2626" />
          <path d="M34 40 Q50 56 66 40 L66 60 Q50 76 34 60 Z" fill="#ffffff" fillOpacity="0.85" />
          <text x="50" y="55" textAnchor="middle" fill="#dc2626" fontSize="10" fontWeight="bold">COLA</text>
        </svg>
      );

    // 7: Servilleta con grasa
    case 'greasy_napkin':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M22 28 L48 18 L78 32 L68 78 L34 82 L20 62 Z" fill="#f1f5f9" stroke="#94a3b8" strokeWidth="1.5" />
          <path d="M35 35 Q52 38 58 52 Q62 66 48 70 Q34 74 30 58 Q28 44 35 35 Z" fill="#fef08a" stroke="#eab308" strokeWidth="1.5" fillOpacity="0.75" />
          <circle cx="42" cy="48" r="4" fill="#ca8a04" fillOpacity="0.6" />
          <circle cx="52" cy="58" r="3" fill="#ca8a04" fillOpacity="0.6" />
        </svg>
      );

    // 8: Botella de vidrio
    case 'glass_bottle':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="44" y="14" width="12" height="6" rx="2" fill="#15803d" />
          <path d="M46 20 L46 34 L36 46 L36 82 C36 86 40 88 50 88 C60 88 64 86 64 82 L64 46 L54 34 L54 20 Z" fill="#16a34a" fillOpacity="0.65" stroke="#15803d" strokeWidth="2" />
          <rect x="38" y="54" width="24" height="18" rx="2" fill="#fef08a" stroke="#ca8a04" strokeWidth="1" />
          <path d="M40 38 L40 82" stroke="#86efac" strokeWidth="1.5" opacity="0.8" />
        </svg>
      );

    // 9: Restos de lechuga / ensalada
    case 'vegetable_salad':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M22 68 C16 48 30 32 46 36 C52 24 72 26 78 42 C86 46 88 64 76 74 C66 82 34 84 22 68 Z" fill="#4ade80" stroke="#16a34a" strokeWidth="2" />
          <path d="M34 56 C38 42 50 44 60 52 C70 42 76 56 68 68" stroke="#15803d" strokeWidth="2" fill="none" />
          <circle cx="44" cy="50" r="4" fill="#ef4444" />
          <circle cx="62" cy="60" r="3.5" fill="#ef4444" />
        </svg>
      );

    // 10: Jeringa médica usada
    case 'syringe':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Subtle biohazard indicator badge */}
          <circle cx="82" cy="18" r="8" fill="#ef4444" stroke="#991b1b" strokeWidth="1" />
          <text x="82" y="21.5" textAnchor="middle" fill="#ffffff" fontSize="9" fontWeight="bold">☣</text>

          {/* Group rotated -45 deg around center (50, 50) */}
          <g transform="rotate(-45 50 50)">
            {/* Needle with sharp bevel tip */}
            <path d="M12 50 L28 48.5 L28 51.5 Z" fill="#94a3b8" />
            <line x1="10" y1="50" x2="28" y2="50" stroke="#cbd5e1" strokeWidth="1.5" strokeLinecap="round" />
            
            {/* Hanging blood / biohazard droplet */}
            <path d="M9 50 C7 50 5 52 5 54 C5 56.5 7 57.5 9 57.5 C11 57.5 13 56.5 13 54 C13 52 11 50 9 50 Z" fill="#dc2626" />
            
            {/* Luer slip collar / hub */}
            <polygon points="28,45 34,46 34,54 28,55" fill="#38bdf8" stroke="#0284c7" strokeWidth="1" />
            <rect x="34" y="47" width="4" height="6" fill="#0284c7" />

            {/* Clear plastic syringe barrel */}
            <rect x="38" y="41" width="34" height="18" rx="2" fill="#f8fafc" fillOpacity="0.85" stroke="#475569" strokeWidth="1.5" />
            {/* Glass highlight glare */}
            <rect x="39" y="42" width="32" height="3" fill="#ffffff" fillOpacity="0.6" rx="1" />

            {/* Biohazard / blood residue inside barrel */}
            <rect x="39" y="43" width="16" height="14" rx="1" fill="#ef4444" fillOpacity="0.85" />
            <path d="M55 43 Q54 50 55 57" stroke="#b91c1c" strokeWidth="1.5" fill="none" />

            {/* Precision graduation tick marks */}
            <line x1="43" y1="41" x2="43" y2="46" stroke="#334155" strokeWidth="1" />
            <line x1="47" y1="41" x2="47" y2="44.5" stroke="#334155" strokeWidth="0.8" />
            <line x1="51" y1="41" x2="51" y2="46" stroke="#334155" strokeWidth="1" />
            <line x1="55" y1="41" x2="55" y2="44.5" stroke="#334155" strokeWidth="0.8" />
            <line x1="59" y1="41" x2="59" y2="46" stroke="#334155" strokeWidth="1" />
            <line x1="63" y1="41" x2="63" y2="44.5" stroke="#334155" strokeWidth="0.8" />
            <line x1="67" y1="41" x2="67" y2="46" stroke="#334155" strokeWidth="1" />

            {/* Rubber plunger stopper inside barrel */}
            <rect x="55" y="42" width="4.5" height="16" rx="1" fill="#1e293b" />
            <rect x="59.5" y="43.5" width="2" height="13" fill="#334155" />

            {/* Finger flanges (back collar of barrel) */}
            <rect x="71" y="34" width="3.5" height="32" rx="1.5" fill="#cbd5e1" stroke="#475569" strokeWidth="1.5" />

            {/* Plunger shaft */}
            <rect x="61.5" y="48.5" width="23" height="3" fill="#94a3b8" />
            <line x1="61.5" y1="50" x2="84.5" y2="50" stroke="#64748b" strokeWidth="1" />

            {/* Thumb push disc */}
            <rect x="84.5" y="38" width="3.5" height="24" rx="1.5" fill="#cbd5e1" stroke="#475569" strokeWidth="1.5" />
          </g>
        </svg>
      );

    // 11: Caja de cartón de cereales
    case 'cardboard_box':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M24 32 L50 20 L76 32 L76 76 L50 88 L24 76 Z" fill="#d97706" stroke="#92400e" strokeWidth="2" />
          <path d="M50 20 L50 88 M24 32 L50 44 L76 32" stroke="#92400e" strokeWidth="2" />
          <rect x="32" y="46" width="12" height="18" fill="#f59e0b" rx="2" />
        </svg>
      );

    // 12: Pañal desechable usado
    case 'diaper':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M22 28 C34 26 66 26 78 28 L74 48 C68 46 64 54 62 62 C58 74 42 74 38 62 C36 54 32 46 26 48 Z" fill="#f8fafc" stroke="#94a3b8" strokeWidth="2" />
          <path d="M22 28 L32 32 M78 28 L68 32" stroke="#38bdf8" strokeWidth="3" />
          <ellipse cx="50" cy="50" rx="8" ry="5" fill="#ca8a04" fillOpacity="0.4" />
        </svg>
      );

    // 13: Posos de café molido
    case 'coffee_grounds':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M26 34 L74 34 L62 76 L38 76 Z" fill="#d4a373" stroke="#8d6e63" strokeWidth="2" />
          <ellipse cx="50" cy="34" rx="24" ry="8" fill="#3e2723" stroke="#5d4037" strokeWidth="2" />
          <ellipse cx="50" cy="34" rx="18" ry="5" fill="#271510" />
          <circle cx="44" cy="33" r="1.5" fill="#5d4037" />
          <circle cx="54" cy="35" r="1.5" fill="#5d4037" />
          <path d="M42 46 Q50 56 58 46" stroke="#4e342e" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );

    // 14: Termómetro de mercurio
    case 'thermometer':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Glass stem tube */}
          <rect x="44" y="14" width="12" height="54" rx="6" fill="#f8fafc" fillOpacity="0.85" stroke="#94a3b8" strokeWidth="1.5" />
          {/* Glass reflection highlight */}
          <line x1="46" y1="18" x2="46" y2="64" stroke="#ffffff" strokeWidth="1.5" strokeLinecap="round" opacity="0.8" />
          {/* Red/silver mercury bulb at base */}
          <circle cx="50" cy="74" r="13" fill="#ef4444" stroke="#b91c1c" strokeWidth="2" />
          <circle cx="47" cy="71" r="3.5" fill="#fca5a5" />
          {/* Mercury capillary column rising */}
          <line x1="50" y1="34" x2="50" y2="68" stroke="#ef4444" strokeWidth="3.5" strokeLinecap="round" />
          {/* Celsius temperature scale graduations */}
          <line x1="53" y1="24" x2="49" y2="24" stroke="#475569" strokeWidth="1.5" />
          <line x1="53" y1="30" x2="50" y2="30" stroke="#475569" strokeWidth="1" />
          <line x1="53" y1="36" x2="48" y2="36" stroke="#dc2626" strokeWidth="1.8" />
          <line x1="53" y1="42" x2="50" y2="42" stroke="#475569" strokeWidth="1" />
          <line x1="53" y1="48" x2="49" y2="48" stroke="#475569" strokeWidth="1.5" />
          <line x1="53" y1="54" x2="50" y2="54" stroke="#475569" strokeWidth="1" />
          <line x1="53" y1="60" x2="49" y2="60" stroke="#475569" strokeWidth="1.5" />
        </svg>
      );

    // 15: Brik de leche / jugo
    case 'juice_box':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M30 32 L46 22 L70 22 L54 32 Z" fill="#93c5fd" stroke="#2563eb" strokeWidth="1.5" />
          <path d="M70 22 L70 70 L54 80 L54 32 Z" fill="#3b82f6" stroke="#1d4ed8" strokeWidth="1.5" />
          <path d="M30 32 L54 32 L54 80 L30 80 Z" fill="#60a5fa" stroke="#1d4ed8" strokeWidth="2" />
          <circle cx="42" cy="52" r="6" fill="#ffffff" />
          <rect x="60" y="16" width="4" height="12" fill="#facc15" stroke="#ca8a04" strokeWidth="1" />
        </svg>
      );

    // 16: Hojas secas
    case 'leaves':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M30 76 C20 52 36 32 64 24 C68 46 54 68 30 76 Z" fill="#f59e0b" stroke="#b45309" strokeWidth="2" />
          <path d="M30 76 Q48 50 64 24" stroke="#92400e" strokeWidth="2" />
          <path d="M45 56 Q55 58 60 52" stroke="#92400e" strokeWidth="1.5" />
          <path d="M40 64 Q46 68 50 64" stroke="#92400e" strokeWidth="1.5" />
          <path d="M52 44 Q58 46 64 42" stroke="#92400e" strokeWidth="1.5" />
        </svg>
      );

    // 17: Vaso de plástico
    case 'plastic_cup':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <ellipse cx="50" cy="24" rx="22" ry="6" fill="#93c5fd" fillOpacity="0.4" stroke="#3b82f6" strokeWidth="2" />
          <path d="M28 24 L36 82 C36 86 42 88 50 88 C58 88 64 86 64 82 L72 24" fill="#60a5fa" fillOpacity="0.25" stroke="#2563eb" strokeWidth="2" />
          <line x1="30" y1="40" x2="70" y2="40" stroke="#93c5fd" strokeWidth="1.5" opacity="0.6" />
          <line x1="32" y1="56" x2="68" y2="56" stroke="#93c5fd" strokeWidth="1.5" opacity="0.6" />
          <line x1="34" y1="70" x2="66" y2="70" stroke="#93c5fd" strokeWidth="1.5" opacity="0.6" />
        </svg>
      );

    // 18: Polvo de barrer / recogedor
    case 'dust_pan':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Dustpan body */}
          <path d="M22 62 L78 62 L70 82 C68 85 64 86 60 86 L40 86 C36 86 32 85 30 82 Z" fill="#475569" stroke="#334155" strokeWidth="2" />
          {/* Rubber front edge lip */}
          <line x1="22" y1="62" x2="78" y2="62" stroke="#0284c7" strokeWidth="2.5" />
          {/* Handle */}
          <rect x="47" y="20" width="6" height="42" rx="3" fill="#64748b" stroke="#334155" strokeWidth="1.5" />
          <circle cx="50" cy="24" r="2" fill="#334155" />
          {/* Swept dust heap with debris particles */}
          <path d="M36 76 Q50 68 64 76 Q50 82 36 76 Z" fill="#94a3b8" />
          <circle cx="44" cy="74" r="1.5" fill="#1e293b" />
          <circle cx="52" cy="76" r="2" fill="#1e293b" />
          <circle cx="58" cy="73" r="1.5" fill="#334155" />
          <circle cx="48" cy="78" r="1.2" fill="#1e293b" />
        </svg>
      );

    // 19: Tubo de pasta dental
    case 'toothpaste':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="22" y="44" width="8" height="12" rx="2" fill="#0284c7" stroke="#0369a1" strokeWidth="1.5" />
          <path d="M30 46 L76 38 C78 38 80 40 80 44 L80 56 C80 60 78 62 76 62 L30 54 Z" fill="#38bdf8" stroke="#0284c7" strokeWidth="2" />
          <path d="M46 42 Q60 50 74 46" stroke="#ffffff" strokeWidth="3" strokeLinecap="round" />
          <line x1="78" y1="38" x2="78" y2="62" stroke="#0369a1" strokeWidth="2" />
        </svg>
      );

    // 20: Blíster de pastillas vacío
    case 'blister_pack':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Metallic foil card */}
          <rect x="22" y="20" width="56" height="60" rx="5" fill="#e2e8f0" stroke="#94a3b8" strokeWidth="2" />
          {/* Perforation divide grid */}
          <line x1="50" y1="20" x2="50" y2="80" stroke="#cbd5e1" strokeWidth="1" strokeDasharray="3 3" />
          <line x1="22" y1="50" x2="78" y2="50" stroke="#cbd5e1" strokeWidth="1" strokeDasharray="3 3" />

          {/* Pill cavity 1: empty popped crushed foil */}
          <ellipse cx="36" cy="35" rx="8" ry="8" fill="#cbd5e1" stroke="#64748b" strokeWidth="1.5" />
          <path d="M33 32 L39 38 M39 32 L33 38" stroke="#475569" strokeWidth="1.5" />

          {/* Pill cavity 2: empty popped foil */}
          <ellipse cx="64" cy="35" rx="8" ry="8" fill="#cbd5e1" stroke="#64748b" strokeWidth="1.5" />
          <path d="M61 32 L67 38 M67 32 L61 38" stroke="#475569" strokeWidth="1.5" />

          {/* Pill cavity 3: remaining pill */}
          <ellipse cx="36" cy="65" rx="8" ry="8" fill="#93c5fd" stroke="#3b82f6" strokeWidth="1.5" />
          <circle cx="36" cy="65" r="4.5" fill="#2563eb" />

          {/* Pill cavity 4: popped open foil */}
          <ellipse cx="64" cy="65" rx="8" ry="8" fill="#cbd5e1" stroke="#64748b" strokeWidth="1.5" />
          <circle cx="64" cy="65" r="4" fill="#64748b" fillOpacity="0.4" />
        </svg>
      );

    // 21: Cáscaras de huevo
    case 'egg_shell':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M26 68 C24 50 34 36 50 36 C54 44 48 50 56 46 C60 52 68 48 70 54 C74 62 66 74 50 76 C36 76 28 72 26 68 Z" fill="#fed7aa" stroke="#ea580c" strokeWidth="2" />
          <path d="M50 36 L46 48 L54 52 L50 62 L60 58 L56 68" stroke="#c2410c" strokeWidth="1.5" fill="none" />
        </svg>
      );

    // 22: Caja de pizza grasienta
    case 'pizza_box':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M22 36 L50 22 L78 36 L78 72 L50 86 L22 72 Z" fill="#d97706" stroke="#92400e" strokeWidth="2" />
          <ellipse cx="50" cy="54" rx="16" ry="10" fill="#ca8a04" fillOpacity="0.5" stroke="#a16207" strokeWidth="1.5" />
          <circle cx="46" cy="52" r="3" fill="#b91c1c" />
          <circle cx="56" cy="56" r="2.5" fill="#b91c1c" />
        </svg>
      );

    // 23: Lata de atún
    case 'tuna_can':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <ellipse cx="50" cy="36" rx="28" ry="10" fill="#e2e8f0" stroke="#64748b" strokeWidth="2" />
          <path d="M22 36 L22 64 C22 72 34 78 50 78 C66 78 78 72 78 64 L78 36" fill="#cbd5e1" stroke="#64748b" strokeWidth="2" />
          <ellipse cx="50" cy="64" rx="28" ry="10" fill="#94a3b8" />
          <ellipse cx="50" cy="36" rx="20" ry="7" fill="#64748b" fillOpacity="0.3" stroke="#475569" strokeWidth="1.5" />
        </svg>
      );

    // 24: Huesos de pollo
    case 'chicken_bone':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Main anatomical drumstick bone */}
          <g transform="rotate(-30 50 50)">
            {/* Top dual condyles */}
            <circle cx="28" cy="44" r="8" fill="#f8fafc" stroke="#cbd5e1" strokeWidth="1.5" />
            <circle cx="28" cy="56" r="8" fill="#f8fafc" stroke="#cbd5e1" strokeWidth="1.5" />
            {/* Shaft of the bone */}
            <path d="M28 46 L72 47 C76 47 78 49 80 47 C80 53 76 53 72 53 L28 54 Z" fill="#f8fafc" />
            <line x1="28" y1="46" x2="72" y2="47" stroke="#cbd5e1" strokeWidth="1.5" />
            <line x1="28" y1="54" x2="72" y2="53" stroke="#cbd5e1" strokeWidth="1.5" />
            {/* Bottom dual condyles */}
            <circle cx="74" cy="44" r="8" fill="#f8fafc" stroke="#cbd5e1" strokeWidth="1.5" />
            <circle cx="74" cy="56" r="8" fill="#f8fafc" stroke="#cbd5e1" strokeWidth="1.5" />
            {/* Cooked meat / gristle leftover residue */}
            <path d="M48 44 C45 42 42 45 44 48 C42 52 46 54 50 52 C54 55 58 52 56 47 C58 43 53 41 48 44 Z" fill="#b45309" stroke="#92400e" strokeWidth="1" />
          </g>
        </svg>
      );

    // 25: Papel de cocina sucio
    case 'paper_towel':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M26 24 L74 24 L70 78 L26 78 Z" fill="#f1f5f9" stroke="#94a3b8" strokeWidth="2" />
          <line x1="26" y1="42" x2="72" y2="42" stroke="#cbd5e1" strokeWidth="1.5" strokeDasharray="3 3" />
          <line x1="26" y1="60" x2="71" y2="60" stroke="#cbd5e1" strokeWidth="1.5" strokeDasharray="3 3" />
          <circle cx="48" cy="52" r="10" fill="#eab308" fillOpacity="0.5" />
          <circle cx="46" cy="50" r="4" fill="#ca8a04" fillOpacity="0.6" />
        </svg>
      );

    // 26: Frasco de mermelada / vidrio
    case 'glass_jar':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="36" y="20" width="28" height="8" rx="2" fill="#dc2626" stroke="#991b1b" strokeWidth="1.5" />
          <rect x="30" y="28" width="40" height="52" rx="6" fill="#bfdbfe" fillOpacity="0.4" stroke="#3b82f6" strokeWidth="2" />
          <rect x="34" y="44" width="32" height="22" rx="2" fill="#fef08a" stroke="#ca8a04" strokeWidth="1" />
          <text x="50" y="58" textAnchor="middle" fill="#854d0e" fontSize="9" fontWeight="bold">JAM</text>
        </svg>
      );

    // 27: Saquito de té
    case 'tea_bag':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M34 38 L42 24 L58 24 L66 38 L66 78 L34 78 Z" fill="#fef3c7" stroke="#d97706" strokeWidth="2" />
          <line x1="50" y1="24" x2="50" y2="10" stroke="#78350f" strokeWidth="1.5" />
          <rect x="44" y="8" width="12" height="8" fill="#ef4444" rx="1" />
          <rect x="40" y="48" width="20" height="22" rx="2" fill="#b45309" fillOpacity="0.4" />
        </svg>
      );

    // 28: Chapas metálicas
    case 'bottle_caps':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="42" cy="46" r="20" fill="#f59e0b" stroke="#b45309" strokeWidth="2" strokeDasharray="3 2" />
          <circle cx="42" cy="46" r="14" fill="#fbbf24" stroke="#d97706" strokeWidth="1.5" />
          <circle cx="62" cy="60" r="16" fill="#3b82f6" stroke="#1d4ed8" strokeWidth="2" strokeDasharray="3 2" />
          <circle cx="62" cy="60" r="10" fill="#60a5fa" stroke="#2563eb" strokeWidth="1.5" />
        </svg>
      );

    // 29: Papel film con grasa
    case 'plastic_wrap':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M24 34 Q50 20 76 36 Q64 60 72 80 Q46 72 26 76 Q34 54 24 34 Z" fill="#bae6fd" fillOpacity="0.5" stroke="#38bdf8" strokeWidth="2" />
          <circle cx="50" cy="54" r="12" fill="#eab308" fillOpacity="0.6" />
          <path d="M42 48 Q54 58 56 64" stroke="#a16207" strokeWidth="1.5" />
        </svg>
      );

    // 30: Aerosol insecticida
    case 'spray_can_toxic':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Spray nozzle actuator */}
          <rect x="46" y="14" width="8" height="9" rx="1" fill="#f8fafc" stroke="#94a3b8" strokeWidth="1" />
          <circle cx="47" cy="18" r="1" fill="#0f172a" />
          {/* Metal dome shoulder */}
          <path d="M34 32 C34 24 66 24 66 32 Z" fill="#cbd5e1" stroke="#94a3b8" strokeWidth="1.5" />
          {/* Cylindrical can body */}
          <rect x="34" y="32" width="32" height="52" rx="2" fill="#ef4444" stroke="#b91c1c" strokeWidth="2" />
          {/* Metal bottom rim */}
          <ellipse cx="50" cy="84" rx="16" ry="3" fill="#94a3b8" stroke="#64748b" strokeWidth="1" />
          {/* Hazard warning label band */}
          <rect x="34" y="48" width="32" height="24" fill="#0f172a" />
          <circle cx="50" cy="60" r="9" fill="#facc15" />
          <text x="50" y="64" textAnchor="middle" fill="#000000" fontSize="12" fontWeight="bold">☠</text>
        </svg>
      );

    // 31: Clips y grapas
    case 'paper_clips':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Main silver paper clip */}
          <path d="M38 36 L38 68 C38 78 56 78 56 68 L56 24 C56 14 26 14 26 24 L26 72 C26 86 68 86 68 72 L68 36" stroke="#94a3b8" strokeWidth="4" fill="none" strokeLinecap="round" strokeLinejoin="round" />
          {/* Highlight shine on metal clip */}
          <path d="M38 36 L38 68 C38 78 56 78 56 68 L56 24" stroke="#f1f5f9" strokeWidth="1.5" fill="none" strokeLinecap="round" opacity="0.8" />
          {/* Second small colorful plastic-coated clip */}
          <path d="M60 46 L60 62 C60 68 72 68 72 62 L72 38 C72 30 52 30 52 38 L52 66" stroke="#38bdf8" strokeWidth="3" fill="none" strokeLinecap="round" />
        </svg>
      );

    // 32: Ticket de compra
    case 'ticket':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M30 18 L70 18 L70 82 L65 78 L60 82 L55 78 L50 82 L45 78 L40 82 L35 78 L30 82 Z" fill="#f8fafc" stroke="#94a3b8" strokeWidth="1.5" />
          <line x1="38" y1="30" x2="62" y2="30" stroke="#475569" strokeWidth="2" />
          <line x1="38" y1="40" x2="56" y2="40" stroke="#94a3b8" strokeWidth="1.5" />
          <line x1="38" y1="48" x2="60" y2="48" stroke="#94a3b8" strokeWidth="1.5" />
          <line x1="38" y1="56" x2="52" y2="56" stroke="#94a3b8" strokeWidth="1.5" />
          <line x1="38" y1="68" x2="62" y2="68" stroke="#0f172a" strokeWidth="2" strokeDasharray="2 2" />
        </svg>
      );

    // 33: Periódico viejo
    case 'newspaper':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="22" y="24" width="56" height="56" rx="2" fill="#e2e8f0" stroke="#64748b" strokeWidth="2" />
          <rect x="28" y="32" width="44" height="8" fill="#1e293b" />
          <rect x="28" y="44" width="20" height="16" fill="#94a3b8" />
          <line x1="52" y1="44" x2="72" y2="44" stroke="#475569" strokeWidth="2" />
          <line x1="52" y1="50" x2="72" y2="50" stroke="#475569" strokeWidth="1.5" />
          <line x1="52" y1="56" x2="72" y2="56" stroke="#475569" strokeWidth="1.5" />
          <line x1="28" y1="66" x2="72" y2="66" stroke="#475569" strokeWidth="1.5" />
          <line x1="28" y1="72" x2="60" y2="72" stroke="#475569" strokeWidth="1.5" />
        </svg>
      );

    // 34: Cinta adhesiva usada
    case 'tape_roll':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <ellipse cx="50" cy="46" rx="26" ry="18" fill="#d97706" stroke="#92400e" strokeWidth="2" />
          <ellipse cx="50" cy="46" rx="14" ry="9" fill="#fef3c7" stroke="#b45309" strokeWidth="2" />
          <path d="M64 54 L78 72 L66 76" stroke="#b45309" strokeWidth="3" fill="none" strokeLinecap="round" />
        </svg>
      );

    // 35: Tipp-ex / corrector
    case 'tippex':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="42" y="16" width="16" height="14" rx="2" fill="#2563eb" stroke="#1d4ed8" strokeWidth="1.5" />
          <path d="M34 30 L66 30 L62 82 L38 82 Z" fill="#ffffff" stroke="#94a3b8" strokeWidth="2" />
          <rect x="38" y="44" width="24" height="14" rx="2" fill="#ef4444" />
          <text x="50" y="55" textAnchor="middle" fill="#ffffff" fontSize="8" fontWeight="bold">FIX</text>
        </svg>
      );

    // 36: Revista vieja
    case 'magazine':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M26 22 L70 20 L76 76 L32 80 Z" fill="#ec4899" stroke="#be185d" strokeWidth="2" />
          <rect x="36" y="32" width="28" height="24" fill="#fbcfe8" rx="2" />
          <line x1="36" y1="62" x2="68" y2="62" stroke="#ffffff" strokeWidth="2" />
          <line x1="36" y1="68" x2="60" y2="68" stroke="#ffffff" strokeWidth="2" />
        </svg>
      );

    // 37: Bolígrafo gastado
    case 'ballpoint_pen':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <g transform="rotate(-45 50 50)">
            {/* Writing point ball / brass tip */}
            <polygon points="12,50 20,47 20,53" fill="#f59e0b" stroke="#b45309" strokeWidth="1" />
            <circle cx="12" cy="50" r="1.5" fill="#0f172a" />
            
            {/* Front grip cone */}
            <rect x="20" y="46" width="6" height="8" rx="1" fill="#2563eb" stroke="#1d4ed8" strokeWidth="1" />

            {/* Clear plastic barrel showing empty ink tube */}
            <rect x="26" y="45" width="46" height="10" rx="1" fill="#f8fafc" fillOpacity="0.8" stroke="#64748b" strokeWidth="1.5" />
            {/* Empty internal ink cartridge tube */}
            <rect x="26" y="48.5" width="44" height="3" fill="#e2e8f0" stroke="#cbd5e1" strokeWidth="0.5" />
            {/* Residue drop at very end */}
            <line x1="26" y1="50" x2="34" y2="50" stroke="#1d4ed8" strokeWidth="2" />

            {/* Pen cap / back plug */}
            <rect x="72" y="44" width="14" height="12" rx="2" fill="#2563eb" stroke="#1d4ed8" strokeWidth="1.5" />
            {/* Pocket clip */}
            <path d="M84 46 L84 40 L60 41 L60 43" fill="none" stroke="#1d4ed8" strokeWidth="2.5" strokeLinecap="round" />
          </g>
        </svg>
      );

    // 38: Resaltador fluorescente
    case 'highlighter':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="38" y="32" width="24" height="48" rx="3" fill="#facc15" stroke="#ca8a04" strokeWidth="2" />
          <rect x="42" y="16" width="16" height="16" rx="2" fill="#84cc16" stroke="#4d7c0f" strokeWidth="1.5" />
          <polygon points="44,16 56,16 52,8 48,8" fill="#4d7c0f" />
        </svg>
      );

    // 39: Pila de botón
    case 'button_battery':
    case 'watch_battery':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <ellipse cx="50" cy="46" rx="24" ry="12" fill="#cbd5e1" stroke="#64748b" strokeWidth="2" />
          <path d="M26 46 L26 56 C26 62 36 68 50 68 C64 68 74 62 74 56 L74 46" fill="#94a3b8" stroke="#64748b" strokeWidth="2" />
          <ellipse cx="50" cy="56" rx="24" ry="12" fill="#94a3b8" />
          <text x="50" y="50" textAnchor="middle" fill="#334155" fontSize="10" fontWeight="bold">CR2032</text>
        </svg>
      );

    // 40: Cáscara de mandarina / cítrico
    case 'citrus':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="50" cy="52" r="28" fill="#f97316" stroke="#c2410c" strokeWidth="2" />
          <path d="M50 24 C50 20 54 18 56 16" stroke="#15803d" strokeWidth="3" strokeLinecap="round" />
          <path d="M50 52 L36 34 M50 52 L64 34 M50 52 L68 56 M50 52 L54 74 M50 52 L34 68" stroke="#fdba74" strokeWidth="2" />
        </svg>
      );

    // 41: Cepillo de dientes
    case 'toothbrush':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <g transform="rotate(-45 50 50)">
            {/* Multi-height bristles */}
            <path d="M16 40 L36 40 L36 47 L16 47 Z" fill="#38bdf8" />
            <path d="M22 36 L30 36 L30 40 L22 40 Z" fill="#22c55e" />
            <line x1="20" y1="38" x2="20" y2="47" stroke="#0284c7" strokeWidth="1" />
            <line x1="24" y1="36" x2="24" y2="47" stroke="#16a34a" strokeWidth="1" />
            <line x1="28" y1="36" x2="28" y2="47" stroke="#16a34a" strokeWidth="1" />
            <line x1="32" y1="38" x2="32" y2="47" stroke="#0284c7" strokeWidth="1" />

            {/* Brush head */}
            <rect x="15" y="47" width="22" height="7" rx="3" fill="#06b6d4" stroke="#0891b2" strokeWidth="1.5" />
            
            {/* Tapered neck */}
            <path d="M37 49 L46 50 L46 52 L37 53 Z" fill="#06b6d4" />

            {/* Ergonomic handle with rubber grip */}
            <path d="M46 49 C54 48 64 47 74 48 C82 49 88 52 88 53 C88 54 82 57 74 58 C64 59 54 58 46 53 Z" fill="#06b6d4" stroke="#0891b2" strokeWidth="1.5" />
            <ellipse cx="64" cy="53" rx="10" ry="3.5" fill="#f8fafc" stroke="#0891b2" strokeWidth="1" />
            <line x1="58" y1="53" x2="70" y2="53" stroke="#0891b2" strokeWidth="1.5" />
          </g>
        </svg>
      );

    // 42: Bote de champú
    case 'shampoo_bottle':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="42" y="16" width="16" height="8" rx="2" fill="#8b5cf6" stroke="#6d28d9" strokeWidth="1.5" />
          <path d="M36 24 C36 24 32 36 32 64 C32 80 40 84 50 84 C60 84 68 80 68 64 C68 36 64 24 64 24 Z" fill="#a78bfa" stroke="#7c3aed" strokeWidth="2" />
          <ellipse cx="50" cy="54" rx="10" ry="14" fill="#ede9fe" />
          <path d="M46 50 Q50 44 54 50 Q50 62 46 50" fill="#7c3aed" />
        </svg>
      );

    // 43: Bastoncillos para oídos
    case 'cotton_swab':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Swab 1 */}
          <line x1="22" y1="78" x2="78" y2="22" stroke="#38bdf8" strokeWidth="3" strokeLinecap="round" />
          <ellipse cx="20" cy="80" rx="6" ry="4" transform="rotate(-45 20 80)" fill="#f8fafc" stroke="#cbd5e1" strokeWidth="1.2" />
          <ellipse cx="80" cy="20" rx="6" ry="4" transform="rotate(-45 80 20)" fill="#f8fafc" stroke="#cbd5e1" strokeWidth="1.2" />

          {/* Swab 2 (crossed) */}
          <line x1="24" y1="64" x2="76" y2="36" stroke="#0284c7" strokeWidth="3" strokeLinecap="round" />
          <ellipse cx="23" cy="65" rx="6" ry="4" transform="rotate(-30 23 65)" fill="#f8fafc" stroke="#cbd5e1" strokeWidth="1.2" />
          <ellipse cx="77" cy="35" rx="6" ry="4" transform="rotate(-30 77 35)" fill="#f8fafc" stroke="#cbd5e1" strokeWidth="1.2" />
        </svg>
      );

    // 44: Jarabe caducado
    case 'syrup_bottle':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="42" y="18" width="16" height="10" rx="2" fill="#ffffff" stroke="#94a3b8" strokeWidth="1.5" />
          <rect x="34" y="28" width="32" height="54" rx="6" fill="#b45309" fillOpacity="0.75" stroke="#78350f" strokeWidth="2" />
          <rect x="38" y="44" width="24" height="20" rx="2" fill="#ffffff" />
          <line x1="50" y1="48" x2="50" y2="60" stroke="#dc2626" strokeWidth="2.5" strokeLinecap="round" />
          <line x1="44" y1="54" x2="56" y2="54" stroke="#dc2626" strokeWidth="2.5" strokeLinecap="round" />
        </svg>
      );

    // 45: Discos desmaquillantes
    case 'makeup_pad':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="50" cy="50" r="26" fill="#f8fafc" stroke="#cbd5e1" strokeWidth="2" />
          <path d="M42 40 Q56 46 62 38 Q58 54 48 58 Z" fill="#f43f5e" fillOpacity="0.65" />
          <circle cx="56" cy="58" r="4" fill="#a855f7" fillOpacity="0.5" />
        </svg>
      );

    // 46: Frasco de perfume
    case 'perfume_bottle':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="44" y="18" width="12" height="12" rx="2" fill="#f59e0b" stroke="#b45309" strokeWidth="1.5" />
          <rect x="32" y="30" width="36" height="52" rx="8" fill="#fbcfe8" fillOpacity="0.5" stroke="#ec4899" strokeWidth="2" />
          <ellipse cx="50" cy="56" rx="10" ry="12" fill="#f472b6" fillOpacity="0.6" />
        </svg>
      );

    // 47: Esmalte de uñas
    case 'nail_polish':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="44" y="16" width="12" height="24" rx="2" fill="#0f172a" stroke="#334155" strokeWidth="1.5" />
          <rect x="34" y="40" width="32" height="42" rx="6" fill="#e11d48" stroke="#be123c" strokeWidth="2" />
          <ellipse cx="50" cy="62" rx="8" ry="10" fill="#fb7185" />
        </svg>
      );

    // 48: Toallitas húmedas
    case 'wet_wipes':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="22" y="32" width="56" height="44" rx="8" fill="#38bdf8" stroke="#0284c7" strokeWidth="2" />
          <ellipse cx="50" cy="54" rx="16" ry="8" fill="#0284c7" />
          <path d="M46 54 C46 42 54 42 54 54" stroke="#ffffff" strokeWidth="3" fill="none" />
        </svg>
      );

    // 49: Tarro de crema
    case 'cream_jar':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="26" y="28" width="48" height="12" rx="3" fill="#ec4899" stroke="#db2777" strokeWidth="1.5" />
          <rect x="28" y="40" width="44" height="42" rx="6" fill="#fdf2f8" stroke="#f472b6" strokeWidth="2" />
          <path d="M38 58 Q50 66 62 58" stroke="#f472b6" strokeWidth="2" />
        </svg>
      );

    // 50: Cuchilla de afeitar
    case 'razor':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Razor pivoting head */}
          <rect x="22" y="18" width="56" height="18" rx="4" fill="#0284c7" stroke="#0369a1" strokeWidth="2" />
          {/* Aloe vera lubricating strip (green) */}
          <rect x="26" y="21" width="48" height="3" rx="1.5" fill="#4ade80" />
          {/* Twin silver steel blades */}
          <rect x="26" y="26" width="48" height="2" rx="0.5" fill="#e2e8f0" stroke="#64748b" strokeWidth="0.5" />
          <rect x="26" y="29.5" width="48" height="2" rx="0.5" fill="#e2e8f0" stroke="#64748b" strokeWidth="0.5" />
          {/* Safety guard bottom */}
          <line x1="26" y1="33" x2="74" y2="33" stroke="#38bdf8" strokeWidth="1" strokeDasharray="3 2" />

          {/* Pivoting neck connector */}
          <polygon points="44,36 56,36 53,44 47,44" fill="#0369a1" />

          {/* Curved ergonomic razor handle */}
          <path d="M47 44 C46 54 44 68 47 84 C48 86 52 86 53 84 C56 68 54 54 53 44 Z" fill="#0284c7" stroke="#0369a1" strokeWidth="2" />
          {/* Non-slip grip rubber ridges */}
          <ellipse cx="50" cy="54" rx="3.5" ry="1.5" fill="#38bdf8" />
          <ellipse cx="50" cy="62" rx="3.5" ry="1.5" fill="#38bdf8" />
          <ellipse cx="50" cy="70" rx="3" ry="1.5" fill="#38bdf8" />
        </svg>
      );

    // 51: Vaso de café para llevar
    case 'takeout_cup':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="30" y="20" width="40" height="8" rx="2" fill="#1e293b" />
          <path d="M32 28 L38 82 L62 82 L68 28 Z" fill="#f8fafc" stroke="#94a3b8" strokeWidth="2" />
          <rect x="35" y="44" width="30" height="18" fill="#78350f" rx="2" />
        </svg>
      );

    // 52: Papel de aluminio limpio
    case 'foil_clean':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M26 34 L74 24 L68 76 L22 68 Z" fill="#e2e8f0" stroke="#94a3b8" strokeWidth="2" />
          <path d="M32 40 L64 32 L58 68 L28 62 Z" fill="#f8fafc" stroke="#cbd5e1" strokeWidth="1" />
          <line x1="42" y1="28" x2="38" y2="70" stroke="#ffffff" strokeWidth="2" />
          <line x1="56" y1="26" x2="52" y2="72" stroke="#94a3b8" strokeWidth="1.5" />
        </svg>
      );

    // 53: Papel de aluminio quemado con grasa
    case 'foil_dirty':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M24 36 L72 26 L66 78 L20 66 Z" fill="#cbd5e1" stroke="#64748b" strokeWidth="2" />
          <circle cx="48" cy="52" r="14" fill="#78350f" fillOpacity="0.75" />
          <path d="M36 44 L44 58 L56 50" stroke="#1c1917" strokeWidth="2" />
        </svg>
      );

    // 54: Ramas y poda
    case 'garden_pruning':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <line x1="26" y1="78" x2="74" y2="24" stroke="#78350f" strokeWidth="4" strokeLinecap="round" />
          <line x1="44" y1="58" x2="34" y2="40" stroke="#78350f" strokeWidth="3" strokeLinecap="round" />
          <line x1="56" y1="44" x2="68" y2="52" stroke="#78350f" strokeWidth="3" strokeLinecap="round" />
          <ellipse cx="34" cy="38" rx="6" ry="3" fill="#22c55e" />
          <ellipse cx="68" cy="54" rx="5" ry="3" fill="#22c55e" />
        </svg>
      );

    // 55: Bombilla incandescente
    case 'lightbulb':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M34 40 C34 28 42 20 50 20 C58 20 66 28 66 40 C66 50 60 56 58 64 L42 64 C40 56 34 50 34 40 Z" fill="#fef08a" fillOpacity="0.6" stroke="#ca8a04" strokeWidth="2" />
          <rect x="42" y="64" width="16" height="12" fill="#94a3b8" stroke="#64748b" strokeWidth="1" />
          <path d="M46 76 L54 76 L52 82 L48 82 Z" fill="#475569" />
          <path d="M46 44 L50 36 L54 44" stroke="#eab308" strokeWidth="1.5" />
        </svg>
      );

    // 56: Tubo fluorescente
    case 'fluorescent_tube':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="18" y="44" width="64" height="12" rx="6" fill="#f8fafc" stroke="#cbd5e1" strokeWidth="2" />
          <rect x="14" y="46" width="6" height="8" rx="1" fill="#94a3b8" />
          <rect x="80" y="46" width="6" height="8" rx="1" fill="#94a3b8" />
          <line x1="28" y1="50" x2="72" y2="50" stroke="#38bdf8" strokeWidth="1.5" opacity="0.6" />
        </svg>
      );

    // 57: Tapitas de botellas plásticas
    case 'plastic_caps':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <ellipse cx="40" cy="46" rx="18" ry="10" fill="#2563eb" stroke="#1d4ed8" strokeWidth="2" />
          <path d="M22 46 L22 56 C22 62 30 66 40 66 C50 66 58 62 58 56 L58 46" fill="#1d4ed8" stroke="#1e40af" strokeWidth="1.5" />
          <ellipse cx="64" cy="56" rx="14" ry="8" fill="#16a34a" stroke="#15803d" strokeWidth="2" />
        </svg>
      );

    // 58: Espejo roto
    case 'broken_mirror':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="24" y="20" width="52" height="60" rx="4" fill="#cbd5e1" stroke="#64748b" strokeWidth="2" />
          <path d="M24 44 L46 54 L38 80 M46 54 L76 38 M46 54 L62 80" stroke="#334155" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );

    // 59: Batería smartphone hinchada
    case 'swollen_battery':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M30 28 C42 22 58 22 70 28 C76 44 76 56 70 72 C58 78 42 78 30 72 C24 56 24 44 30 28 Z" fill="#1e293b" stroke="#dc2626" strokeWidth="2.5" />
          <rect x="44" y="16" width="12" height="6" fill="#ca8a04" />
          <text x="50" y="54" textAnchor="middle" fill="#ef4444" fontSize="12" fontWeight="bold">⚠</text>
        </svg>
      );

    // 60: Envase de yogur
    case 'yogurt_pot':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <ellipse cx="50" cy="26" rx="20" ry="6" fill="#f1f5f9" stroke="#94a3b8" strokeWidth="1.5" />
          <path d="M30 26 L36 78 C36 82 42 86 50 86 C58 86 64 82 64 78 L70 26" fill="#e0e7ff" stroke="#6366f1" strokeWidth="2" />
          <rect x="34" y="44" width="32" height="16" rx="2" fill="#818cf8" />
        </svg>
      );

    // 61: Cable USB roto
    case 'usb_cable':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* USB-A metal connector plug */}
          <rect x="14" y="44" width="22" height="14" rx="2" fill="#cbd5e1" stroke="#64748b" strokeWidth="1.5" />
          {/* USB holes */}
          <rect x="18" y="47" width="5" height="3" fill="#1e293b" />
          <rect x="18" y="52" width="5" height="3" fill="#1e293b" />
          {/* Plastic overmold grip */}
          <rect x="34" y="42" width="16" height="18" rx="3" fill="#1e293b" stroke="#0f172a" strokeWidth="1.5" />

          {/* S-curved thick insulated wire */}
          <path d="M50 51 C62 51 64 68 76 68" stroke="#1e293b" strokeWidth="5.5" fill="none" strokeLinecap="round" />

          {/* Frayed split ends showing bare copper and colored wiring */}
          <path d="M76 68 Q84 62 88 58" stroke="#ef4444" strokeWidth="2" fill="none" strokeLinecap="round" />
          <path d="M76 68 Q86 68 90 66" stroke="#22c55e" strokeWidth="2" fill="none" strokeLinecap="round" />
          <path d="M76 68 Q84 74 88 78" stroke="#eab308" strokeWidth="2" fill="none" strokeLinecap="round" />
        </svg>
      );

    // 62: Lata de pintura con restos
    case 'paint_can':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <ellipse cx="50" cy="28" rx="24" ry="8" fill="#e2e8f0" stroke="#64748b" strokeWidth="2" />
          <path d="M26 28 L26 76 C26 84 36 88 50 88 C64 88 74 84 74 76 L74 28" fill="#cbd5e1" stroke="#64748b" strokeWidth="2" />
          <path d="M34 28 Q40 46 44 38 Q48 54 52 40" fill="#dc2626" stroke="#b91c1c" strokeWidth="1.5" />
        </svg>
      );

    // 63: Botella de lavandina con asa
    case 'bleach_bottle':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="42" y="16" width="14" height="8" rx="2" fill="#ef4444" stroke="#dc2626" strokeWidth="1.5" />
          <path d="M42 24 L34 36 L34 82 C34 86 42 88 50 88 C58 88 66 86 66 82 L66 36 L56 24 Z" fill="#ffffff" stroke="#94a3b8" strokeWidth="2" />
          <path d="M34 40 C24 44 24 64 34 68" stroke="#94a3b8" strokeWidth="4" fill="none" strokeLinecap="round" />
          <rect x="40" y="50" width="20" height="18" fill="#facc15" rx="2" />
        </svg>
      );

    // 64: Frasco de aguarrás / solvente
    case 'solvent_flask':
    case 'acetone_bottle':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="44" y="14" width="12" height="10" rx="2" fill="#dc2626" />
          <path d="M46 24 L46 40 L26 74 C24 78 28 84 34 84 L66 84 C72 84 76 78 74 74 L54 40 L54 24 Z" fill="#fee2e2" stroke="#ef4444" strokeWidth="2" />
          <path d="M32 70 Q50 64 68 70 L66 82 L34 82 Z" fill="#f87171" />
          <text x="50" y="60" textAnchor="middle" fill="#991b1b" fontSize="12" fontWeight="bold">☠</text>
        </svg>
      );

    // 65: Disco CD / DVD rayado
    case 'cd_disc':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="50" cy="50" r="30" fill="#e2e8f0" stroke="#94a3b8" strokeWidth="2" />
          <circle cx="50" cy="50" r="10" fill="#ffffff" stroke="#94a3b8" strokeWidth="1.5" />
          <circle cx="50" cy="50" r="4" fill="#64748b" />
          {/* Scratches */}
          <line x1="30" y1="36" x2="48" y2="44" stroke="#475569" strokeWidth="1.5" />
          <line x1="58" y1="56" x2="72" y2="68" stroke="#475569" strokeWidth="1.5" />
        </svg>
      );

    // 66: Cartucho de tóner
    case 'toner_cartridge':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="22" y="36" width="56" height="34" rx="4" fill="#0f172a" stroke="#334155" strokeWidth="2" />
          <circle cx="34" cy="53" r="6" fill="#38bdf8" />
          <circle cx="50" cy="53" r="6" fill="#f43f5e" />
          <circle cx="66" cy="53" r="6" fill="#facc15" />
          <rect x="40" y="30" width="20" height="6" fill="#64748b" rx="1" />
        </svg>
      );

    // 67: Pila recargable
    case 'rechargeable_battery':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="44" y="16" width="12" height="6" rx="2" fill="#16a34a" />
          <rect x="34" y="22" width="32" height="64" rx="4" fill="#166534" stroke="#14532d" strokeWidth="2" />
          <path d="M50 36 L44 50 L50 50 L46 64 L56 48 L50 48 Z" fill="#facc15" stroke="#ca8a04" strokeWidth="1" />
        </svg>
      );

    // 68: Corcho natural de vino
    case 'wine_cork':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <ellipse cx="50" cy="28" rx="16" ry="6" fill="#d4a373" stroke="#8c5835" strokeWidth="1.5" />
          <path d="M34 28 L34 72 C34 78 40 82 50 82 C60 82 66 78 66 72 L66 28" fill="#bc8a5f" stroke="#8c5835" strokeWidth="2" />
          <line x1="42" y1="40" x2="44" y2="40" stroke="#754728" strokeWidth="2" strokeLinecap="round" />
          <line x1="54" y1="52" x2="56" y2="52" stroke="#754728" strokeWidth="2" strokeLinecap="round" />
          <line x1="46" y1="64" x2="48" y2="64" stroke="#754728" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );

    // 69: Tapón sintético de silicona
    case 'silicone_stopper':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <ellipse cx="50" cy="30" rx="18" ry="7" fill="#38bdf8" stroke="#0284c7" strokeWidth="2" />
          <path d="M32 30 L36 74 C36 78 42 82 50 82 C58 82 64 78 64 74 L68 30" fill="#0284c7" stroke="#0369a1" strokeWidth="2" />
          <ellipse cx="50" cy="48" rx="14" ry="4" fill="#bae6fd" opacity="0.6" />
        </svg>
      );

    // 70: Trapo con grasa de motor
    case 'oily_rag':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M24 38 L48 20 L76 34 L72 74 L46 84 L22 70 Z" fill="#e2e8f0" stroke="#94a3b8" strokeWidth="2" />
          <circle cx="48" cy="52" r="14" fill="#0f172a" />
          <path d="M34 58 Q46 68 54 62" stroke="#0f172a" strokeWidth="4" />
        </svg>
      );

    // 71: Plato de cerámica quebrado
    case 'ceramic_plate':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <ellipse cx="50" cy="50" rx="36" ry="26" fill="#f8fafc" stroke="#94a3b8" strokeWidth="2" />
          <ellipse cx="50" cy="50" rx="24" ry="16" fill="#f1f5f9" stroke="#cbd5e1" strokeWidth="1.5" />
          <path d="M32 32 L46 52 L42 62 L64 74" stroke="#475569" strokeWidth="2.5" strokeLinecap="round" />
        </svg>
      );

    // 72: Bolsa compostable PLA
    case 'compost_bag':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M30 36 L34 82 C34 86 42 88 50 88 C58 88 66 86 66 82 L70 36 Z" fill="#86efac" stroke="#16a34a" strokeWidth="2" />
          <path d="M40 36 C40 24 60 24 60 36" stroke="#15803d" strokeWidth="3" fill="none" />
          <text x="50" y="64" textAnchor="middle" fill="#15803d" fontSize="12" fontWeight="bold">PLA</text>
        </svg>
      );

    // 73: Chicle mascado
    case 'chewing_gum':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M32 50 C26 42 42 32 54 36 C66 38 74 46 68 56 C64 66 50 70 38 64 C30 60 34 54 32 50 Z" fill="#f472b6" stroke="#db2777" strokeWidth="2" />
          <path d="M42 46 Q52 48 58 44" stroke="#fbcfe8" strokeWidth="3" strokeLinecap="round" />
        </svg>
      );

    // 74: Cenizas de madera
    case 'wood_ash':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <ellipse cx="50" cy="62" rx="28" ry="16" fill="#cbd5e1" stroke="#94a3b8" strokeWidth="2" />
          <circle cx="42" cy="58" r="4" fill="#94a3b8" />
          <circle cx="56" cy="62" r="3" fill="#64748b" />
          <line x1="38" y1="68" x2="62" y2="60" stroke="#78350f" strokeWidth="3" strokeLinecap="round" />
        </svg>
      );

    // 75: Cenizas de carbón
    case 'coal_ash':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <ellipse cx="50" cy="64" rx="28" ry="16" fill="#475569" stroke="#1e293b" strokeWidth="2" />
          <circle cx="44" cy="60" r="5" fill="#1e293b" />
          <circle cx="58" cy="62" r="4" fill="#0f172a" />
          <circle cx="50" cy="68" r="3" fill="#334155" />
        </svg>
      );

    // 76: Bolsa metalizada de snacks
    case 'snack_bag':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M28 20 L72 20 L66 82 L34 82 Z" fill="#ef4444" stroke="#b91c1c" strokeWidth="2" />
          <line x1="28" y1="24" x2="72" y2="24" stroke="#facc15" strokeWidth="3" />
          <line x1="34" y1="78" x2="66" y2="78" stroke="#facc15" strokeWidth="3" />
          <polygon points="50,42 56,54 44,54" fill="#facc15" />
        </svg>
      );

    // 77: Frasco de jarabe vacío
    case 'glass_medicine_jar':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="42" y="16" width="16" height="8" rx="2" fill="#ffffff" stroke="#94a3b8" strokeWidth="1.5" />
          <rect x="34" y="24" width="32" height="58" rx="6" fill="#bfdbfe" fillOpacity="0.4" stroke="#3b82f6" strokeWidth="2" />
          <rect x="38" y="42" width="24" height="22" rx="2" fill="#ffffff" stroke="#94a3b8" strokeWidth="1" />
          <text x="50" y="56" textAnchor="middle" fill="#2563eb" fontSize="10" fontWeight="bold">Rx</text>
        </svg>
      );

    // 78: Gasas con sangre y yodo
    case 'bloody_gauze':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="26" y="26" width="48" height="48" rx="4" fill="#f8fafc" stroke="#cbd5e1" strokeWidth="2" />
          <line x1="26" y1="42" x2="74" y2="42" stroke="#e2e8f0" strokeWidth="1.5" strokeDasharray="3 3" />
          <line x1="26" y1="58" x2="74" y2="58" stroke="#e2e8f0" strokeWidth="1.5" strokeDasharray="3 3" />
          <circle cx="50" cy="50" r="12" fill="#dc2626" fillOpacity="0.8" />
          <circle cx="58" cy="56" r="6" fill="#b45309" fillOpacity="0.75" />
        </svg>
      );

    // 79: Mechero / encendedor
    case 'lighter':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="40" y="16" width="14" height="12" rx="2" fill="#94a3b8" stroke="#475569" strokeWidth="1.5" />
          <rect x="36" y="28" width="28" height="56" rx="4" fill="#ef4444" stroke="#b91c1c" strokeWidth="2" />
          <circle cx="44" cy="22" r="3" fill="#cbd5e1" />
        </svg>
      );

    // 80: Desodorante roll-on
    case 'rollon_deodorant':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="50" cy="28" r="12" fill="#f1f5f9" stroke="#94a3b8" strokeWidth="2" />
          <path d="M36 34 L34 80 C34 84 42 86 50 86 C58 86 66 84 66 80 L64 34 Z" fill="#0284c7" stroke="#0369a1" strokeWidth="2" />
          <rect x="38" y="48" width="24" height="18" rx="2" fill="#ffffff" />
        </svg>
      );

    // 81: Placa de radiografía médica
    case 'xray':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="20" y="16" width="60" height="68" rx="3" fill="#090d16" stroke="#334155" strokeWidth="2" />
          <line x1="50" y1="24" x2="50" y2="76" stroke="#94a3b8" strokeWidth="3" strokeLinecap="round" />
          <path d="M34 36 C42 34 46 36 50 40 C54 36 58 34 66 36" stroke="#cbd5e1" strokeWidth="2.5" fill="none" />
          <path d="M32 46 C42 44 46 46 50 50 C54 46 58 44 68 46" stroke="#cbd5e1" strokeWidth="2.5" fill="none" />
          <path d="M32 56 C42 54 46 56 50 60 C54 56 58 54 68 56" stroke="#cbd5e1" strokeWidth="2.5" fill="none" />
        </svg>
      );

    // 82: Filtro de café con restos
    case 'coffee_filter':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M22 30 L78 30 L60 76 L40 76 Z" fill="#fef3c7" stroke="#d97706" strokeWidth="2" />
          <ellipse cx="50" cy="30" rx="28" ry="8" fill="#3e2723" />
          <ellipse cx="50" cy="30" rx="20" ry="5" fill="#271510" />
        </svg>
      );

    // 83: Pegamento cianoacrilato
    case 'superglue':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <polygon points="46,14 54,14 52,28 48,28" fill="#dc2626" />
          <rect x="42" y="28" width="16" height="56" rx="3" fill="#facc15" stroke="#ca8a04" strokeWidth="2" />
          <text x="50" y="58" textAnchor="middle" fill="#000000" fontSize="8" fontWeight="bold">GLUE</text>
        </svg>
      );

    // 84: Hilo dental usado
    case 'dental_floss':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Floss dispenser casing */}
          <rect x="26" y="32" width="48" height="46" rx="10" fill="#38bdf8" stroke="#0284c7" strokeWidth="2" />
          <rect x="30" y="36" width="40" height="38" rx="8" fill="#e0f2fe" />
          {/* Inner spool circle */}
          <circle cx="50" cy="56" r="14" fill="#ffffff" stroke="#94a3b8" strokeWidth="1.5" />
          <circle cx="50" cy="56" r="5" fill="#38bdf8" />
          {/* Dispenser top lid and metal cutter */}
          <rect x="34" y="26" width="32" height="7" rx="2" fill="#0284c7" />
          <polygon points="47,26 53,26 50,23" fill="#cbd5e1" stroke="#64748b" strokeWidth="0.8" />
          {/* Pulled thread of used floss curling out */}
          <path d="M50 25 Q62 14 74 22 Q84 30 78 40" stroke="#f8fafc" strokeWidth="2.5" fill="none" strokeLinecap="round" />
        </svg>
      );

    // 85: Papel de hornear quemado
    case 'baking_paper':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M24 24 L76 20 L70 78 L22 74 Z" fill="#d4a373" stroke="#8d6e63" strokeWidth="2" />
          <circle cx="48" cy="48" r="12" fill="#3e2723" fillOpacity="0.7" />
          <path d="M28 28 L36 32" stroke="#4e342e" strokeWidth="2" />
        </svg>
      );

    // 86: Lata de sardinas lavada
    case 'sardine_can':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="20" y="34" width="60" height="34" rx="6" fill="#cbd5e1" stroke="#64748b" strokeWidth="2" />
          <rect x="24" y="38" width="52" height="26" rx="4" fill="#94a3b8" fillOpacity="0.5" stroke="#475569" strokeWidth="1.5" />
          <path d="M34 51 Q46 44 58 51 Q46 58 34 51 Z" fill="#64748b" stroke="#334155" strokeWidth="1" />
        </svg>
      );

    // 87: Aerosol desodorante vacío
    case 'aerosol_deodorant':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="46" y="16" width="8" height="8" fill="#cbd5e1" />
          <rect x="36" y="24" width="28" height="60" rx="4" fill="#38bdf8" stroke="#0284c7" strokeWidth="2" />
          <line x1="36" y1="48" x2="64" y2="48" stroke="#ffffff" strokeWidth="2" />
        </svg>
      );

    // 88: Mascarilla quirúrgica
    case 'surgical_mask':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Elastic ear loops */}
          <path d="M26 38 C12 36 12 64 26 62 M74 38 C88 36 88 64 74 62" stroke="#cbd5e1" strokeWidth="2.5" fill="none" />
          {/* Mask 3-ply pleated body */}
          <rect x="24" y="32" width="52" height="36" rx="4" fill="#38bdf8" stroke="#0284c7" strokeWidth="2" />
          {/* Upper nose wire strip */}
          <line x1="30" y1="36" x2="70" y2="36" stroke="#0284c7" strokeWidth="2.5" strokeLinecap="round" />
          {/* Pleat horizontal folds */}
          <line x1="24" y1="44" x2="76" y2="44" stroke="#0369a1" strokeWidth="1.5" />
          <line x1="24" y1="52" x2="76" y2="52" stroke="#0369a1" strokeWidth="1.5" />
          <line x1="24" y1="60" x2="76" y2="60" stroke="#0369a1" strokeWidth="1.5" />
          {/* Soft highlights */}
          <rect x="28" y="38" width="44" height="4" fill="#bae6fd" fillOpacity="0.5" />
        </svg>
      );

    // 89: Cápsula de café
    case 'coffee_pod':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <ellipse cx="50" cy="32" rx="22" ry="6" fill="#cbd5e1" stroke="#64748b" strokeWidth="2" />
          <path d="M28 32 L34 68 C34 72 40 76 50 76 C60 76 66 72 66 68 L72 32" fill="#f59e0b" stroke="#b45309" strokeWidth="2" />
          <ellipse cx="50" cy="32" rx="14" ry="3" fill="#94a3b8" stroke="#475569" strokeWidth="1" strokeDasharray="2 2" />
        </svg>
      );

    // 90: Conchas de mejillones y almejas
    case 'seashells':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M28 66 C22 42 38 28 50 28 C62 28 78 42 72 66 C62 72 38 72 28 66 Z" fill="#fed7aa" stroke="#c2410c" strokeWidth="2" />
          <line x1="50" y1="28" x2="50" y2="70" stroke="#ea580c" strokeWidth="1.5" />
          <line x1="50" y1="28" x2="38" y2="68" stroke="#ea580c" strokeWidth="1.5" />
          <line x1="50" y1="28" x2="62" y2="68" stroke="#ea580c" strokeWidth="1.5" />
          <line x1="50" y1="28" x2="30" y2="62" stroke="#ea580c" strokeWidth="1.5" />
          <line x1="50" y1="28" x2="70" y2="62" stroke="#ea580c" strokeWidth="1.5" />
        </svg>
      );

    // 91: Cristal de ventana quebrado
    case 'window_glass':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <polygon points="22,76 34,24 74,32 68,82" fill="#bae6fd" fillOpacity="0.5" stroke="#0284c7" strokeWidth="2" />
          <line x1="34" y1="24" x2="52" y2="56" stroke="#0369a1" strokeWidth="2" />
          <line x1="52" y1="56" x2="68" y2="82" stroke="#0369a1" strokeWidth="2" />
          <line x1="52" y1="56" x2="74" y2="32" stroke="#0369a1" strokeWidth="2" />
        </svg>
      );

    // 92: Bandeja de poliestireno (telgopor)
    case 'styrofoam_tray':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="22" y="32" width="56" height="40" rx="6" fill="#f8fafc" stroke="#cbd5e1" strokeWidth="2.5" />
          <rect x="28" y="38" width="44" height="28" rx="4" fill="#ffffff" stroke="#e2e8f0" strokeWidth="1.5" />
        </svg>
      );

    // 93: Caja de hamburguesa con salsa
    case 'burger_box':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M24 44 C24 32 36 26 50 26 C64 26 76 32 76 44 Z" fill="#f1f5f9" stroke="#94a3b8" strokeWidth="2" />
          <path d="M24 46 L28 72 C28 76 36 80 50 80 C64 80 72 76 72 72 L76 46 Z" fill="#e2e8f0" stroke="#94a3b8" strokeWidth="2" />
          <circle cx="50" cy="56" r="8" fill="#dc2626" fillOpacity="0.8" />
          <circle cx="56" cy="62" r="4" fill="#eab308" fillOpacity="0.8" />
        </svg>
      );

    // 95: Esponja de lavar platos
    case 'sponge':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="22" y="28" width="56" height="14" rx="3" fill="#16a34a" stroke="#15803d" strokeWidth="2" />
          <rect x="22" y="42" width="56" height="34" rx="3" fill="#facc15" stroke="#ca8a04" strokeWidth="2" />
          <circle cx="34" cy="54" r="3" fill="#eab308" />
          <circle cx="50" cy="62" r="4" fill="#eab308" />
          <circle cx="64" cy="52" r="3" fill="#eab308" />
        </svg>
      );

    // 96: Espinas de pescado y restos
    case 'fish_bones':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Fish head skeleton */}
          <path d="M22 50 C24 40 32 36 38 42 L38 58 C32 64 24 60 22 50 Z" fill="#e2e8f0" stroke="#64748b" strokeWidth="2" />
          {/* Eye socket hollow */}
          <circle cx="28" cy="46" r="3.5" fill="#475569" />
          <path d="M22 50 L30 53" stroke="#64748b" strokeWidth="1.5" />

          {/* Central spine column */}
          <line x1="38" y1="50" x2="74" y2="50" stroke="#64748b" strokeWidth="3.5" strokeLinecap="round" />

          {/* Rib bones pairs */}
          <path d="M46 34 Q45 42 46 50 Q45 58 46 66" stroke="#64748b" strokeWidth="2.5" fill="none" strokeLinecap="round" />
          <path d="M54 36 Q53 43 54 50 Q53 57 54 64" stroke="#64748b" strokeWidth="2.5" fill="none" strokeLinecap="round" />
          <path d="M62 38 Q61 44 62 50 Q61 56 62 62" stroke="#64748b" strokeWidth="2.5" fill="none" strokeLinecap="round" />
          <path d="M70 41 Q69 45 70 50 Q69 55 70 59" stroke="#64748b" strokeWidth="2.5" fill="none" strokeLinecap="round" />

          {/* Tail fin skeleton */}
          <polygon points="74,50 86,38 82,50 86,62" fill="#e2e8f0" stroke="#64748b" strokeWidth="2" strokeLinejoin="round" />
        </svg>
      );

    // 97: Botella de amoníaco
    case 'ammonia_bottle':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="42" y="16" width="16" height="8" rx="2" fill="#2563eb" stroke="#1d4ed8" strokeWidth="1.5" />
          <path d="M42 24 L34 38 L34 82 C34 86 42 88 50 88 C58 88 66 86 66 82 L66 38 L58 24 Z" fill="#ffffff" stroke="#94a3b8" strokeWidth="2" />
          <rect x="38" y="48" width="24" height="20" rx="2" fill="#3b82f6" />
          <text x="50" y="62" textAnchor="middle" fill="#ffffff" fontSize="9" fontWeight="bold">NH3</text>
        </svg>
      );

    // 98: Jeringa sin aguja
    case 'syringe_needleless':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <g transform="rotate(-45 50 50)">
            {/* Front luer slip nozzle tip */}
            <polygon points="28,47 38,46 38,54 28,53" fill="#38bdf8" stroke="#0284c7" strokeWidth="1" />
            <rect x="25" y="48" width="4" height="4" rx="0.5" fill="#0284c7" />

            {/* Clear plastic syringe barrel */}
            <rect x="38" y="41" width="34" height="18" rx="2" fill="#f8fafc" fillOpacity="0.85" stroke="#475569" strokeWidth="1.5" />
            <rect x="39" y="42" width="32" height="3" fill="#ffffff" fillOpacity="0.6" rx="1" />

            {/* Residual liquid inside barrel */}
            <rect x="39" y="43" width="14" height="14" rx="1" fill="#ef4444" fillOpacity="0.75" />

            {/* Precision graduation tick marks */}
            <line x1="43" y1="41" x2="43" y2="46" stroke="#334155" strokeWidth="1" />
            <line x1="47" y1="41" x2="47" y2="44.5" stroke="#334155" strokeWidth="0.8" />
            <line x1="51" y1="41" x2="51" y2="46" stroke="#334155" strokeWidth="1" />
            <line x1="55" y1="41" x2="55" y2="44.5" stroke="#334155" strokeWidth="0.8" />
            <line x1="59" y1="41" x2="59" y2="46" stroke="#334155" strokeWidth="1" />
            <line x1="63" y1="41" x2="63" y2="44.5" stroke="#334155" strokeWidth="0.8" />
            <line x1="67" y1="41" x2="67" y2="46" stroke="#334155" strokeWidth="1" />

            {/* Rubber plunger stopper */}
            <rect x="53" y="42" width="4.5" height="16" rx="1" fill="#1e293b" />
            <rect x="57.5" y="43.5" width="2" height="13" fill="#334155" />

            {/* Finger flanges */}
            <rect x="71" y="34" width="3.5" height="32" rx="1.5" fill="#cbd5e1" stroke="#475569" strokeWidth="1.5" />

            {/* Plunger shaft */}
            <rect x="59.5" y="48.5" width="25" height="3" fill="#94a3b8" />
            <line x1="59.5" y1="50" x2="84.5" y2="50" stroke="#64748b" strokeWidth="1" />

            {/* Thumb push disc */}
            <rect x="84.5" y="38" width="3.5" height="24" rx="1.5" fill="#cbd5e1" stroke="#475569" strokeWidth="1.5" />
          </g>
        </svg>
      );

    // 99: Saquito de manzanilla
    case 'chamomile_bag':
      return (
        <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M34 38 L42 24 L58 24 L66 38 L66 78 L34 78 Z" fill="#fef9c3" stroke="#eab308" strokeWidth="2" />
          <line x1="50" y1="24" x2="50" y2="10" stroke="#a16207" strokeWidth="1.5" />
          <rect x="44" y="8" width="12" height="8" fill="#facc15" rx="1" />
          <circle cx="50" cy="56" r="6" fill="#eab308" />
        </svg>
      );

    default:
      return (
        <div className="w-full h-full flex items-center justify-center">
          <span className="text-4xl sm:text-5xl select-none filter drop-shadow-md transform hover:scale-110 transition-transform">
            {item.emoji}
          </span>
        </div>
      );
  }
};
