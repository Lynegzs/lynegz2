import React, { useRef, useEffect, useState } from 'react';
import { Camera, Eye, EyeOff, RefreshCw, Hand, Sparkles } from 'lucide-react';

interface CameraViewProps {
  handDetected: boolean;
  isPinching: boolean;
  pinchDistance?: number;
  normX?: number;
  normY?: number;
  videoRef: React.RefObject<HTMLVideoElement | null>;
  onSwitchCamera?: () => Promise<void>;
  facingMode?: 'user' | 'environment';
  onReCalibrate?: () => void;
  compact?: boolean;
}

export const CameraView: React.FC<CameraViewProps> = ({
  handDetected,
  isPinching,
  pinchDistance = 1.0,
  normX = 0.5,
  normY = 0.5,
  videoRef,
  onSwitchCamera,
  facingMode = 'user',
  onReCalibrate,
  compact = false
}) => {
  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const [isMinimized, setIsMinimized] = useState<boolean>(false);
  const [isSwitching, setIsSwitching] = useState<boolean>(false);

  // Sync stream to local viewfinder video element
  useEffect(() => {
    const syncStream = () => {
      if (localVideoRef.current && videoRef.current?.srcObject) {
        if (localVideoRef.current.srcObject !== videoRef.current.srcObject) {
          localVideoRef.current.srcObject = videoRef.current.srcObject;
          localVideoRef.current.muted = true;
          localVideoRef.current.play().catch(() => {});
        }
      }
    };

    syncStream();
    const interval = setInterval(syncStream, 1000);
    return () => clearInterval(interval);
  }, [videoRef]);

  const handleSwitch = async () => {
    if (!onSwitchCamera || isSwitching) return;
    setIsSwitching(true);
    try {
      await onSwitchCamera();
    } finally {
      setIsSwitching(false);
    }
  };

  return (
    <aside
      id="camara-miniatura"
      aria-label="Monitor de Cámara en Vivo"
      className="fixed bottom-4 right-4 z-40 bg-slate-900/90 backdrop-blur-md rounded-2xl border border-emerald-500/40 shadow-2xl shadow-emerald-500/10 p-2 sm:p-2.5 flex flex-col gap-2 transition-all select-none max-w-[210px] sm:max-w-[240px]"
    >
      {/* Header bar with status badge and minimize toggle */}
      <div className="flex items-center justify-between gap-1.5">
        <div className="flex items-center gap-1.5">
          <Camera className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-[10px] sm:text-[11px] font-black text-slate-200 uppercase tracking-wider">
            Cámara en Vivo
          </span>
        </div>

        <div className="flex items-center gap-1">
          {/* Status Dot */}
          <span
            className={`w-2 h-2 rounded-full ${
              handDetected ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'
            }`}
            title={handDetected ? 'Mano en cuadro' : 'Buscando mano'}
          />

          {/* Minimize / Expand Button */}
          <button
            onClick={() => setIsMinimized(!isMinimized)}
            className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
            title={isMinimized ? 'Expandir visor' : 'Minimizar visor'}
          >
            {isMinimized ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
          </button>
        </div>
      </div>

      {/* Live Viewfinder Preview */}
      {!isMinimized && (
        <div className="flex flex-col gap-2 animate-fade-in">
          <div className="relative w-full aspect-[4/3] rounded-xl overflow-hidden bg-slate-950 border border-slate-700/80 shadow-inner group">
            {/* The actual live hardware-accelerated video feed */}
            <video
              ref={localVideoRef}
              playsInline
              muted
              autoPlay
              className={`absolute inset-0 w-full h-full object-cover ${
                facingMode === 'user' ? '-scale-x-100' : 'scale-x-100'
              }`}
            />

            {/* Hand Cursor Tracking Pip in viewfinder */}
            {handDetected && (
              <div
                style={{
                  left: `${normX * 100}%`,
                  top: `${normY * 100}%`
                }}
                className="absolute -translate-x-1/2 -translate-y-1/2 pointer-events-none transition-all duration-75"
              >
                <div
                  className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                    isPinching
                      ? 'border-emerald-400 bg-emerald-400/40 scale-125'
                      : 'border-cyan-400 bg-cyan-400/20'
                  }`}
                >
                  <div
                    className={`w-1.5 h-1.5 rounded-full ${
                      isPinching ? 'bg-emerald-300' : 'bg-cyan-300'
                    }`}
                  />
                </div>
              </div>
            )}

            {/* Overlay hint when no hand is detected */}
            {!handDetected && (
              <div className="absolute inset-0 bg-slate-950/40 backdrop-blur-[1px] flex flex-col items-center justify-center p-2 text-center pointer-events-none">
                <Hand className="w-6 h-6 text-amber-300 animate-bounce mb-1" />
                <span className="text-[9px] font-bold text-amber-200 uppercase leading-tight">
                  Coloca tu mano frente a la cámara
                </span>
              </div>
            )}

            {/* Gesture Pill Watermark */}
            <div className="absolute bottom-1 left-1 px-1.5 py-0.5 rounded bg-slate-950/80 backdrop-blur-xs text-[8px] sm:text-[9px] font-mono text-slate-200 border border-slate-700/50 flex items-center gap-1">
              <span>{isPinching ? '🤏 Pinza: SÍ' : '🖐️ Abierta'}</span>
            </div>
          </div>

          {/* Quick Toolbar (Switch camera / Calibrate) */}
          <div className="flex items-center justify-between gap-1 text-[9px] sm:text-[10px] text-slate-400">
            <span className="font-semibold truncate">
              {handDetected ? (
                <span className="text-emerald-400 font-bold">🟢 Detectada</span>
              ) : (
                <span className="text-amber-300">🟠 Buscando mano...</span>
              )}
            </span>

            <div className="flex items-center gap-1">
              {onSwitchCamera && (
                <button
                  onClick={handleSwitch}
                  disabled={isSwitching}
                  title={`Girar cámara (${facingMode === 'user' ? 'Frontal' : 'Trasera'})`}
                  className="flex items-center gap-1 p-1 rounded hover:bg-slate-800 text-slate-300 hover:text-white transition cursor-pointer"
                >
                  <RefreshCw className={`w-3 h-3 text-cyan-400 ${isSwitching ? 'animate-spin' : ''}`} />
                  <span className="hidden sm:inline">{facingMode === 'user' ? 'Girar' : 'Frontal'}</span>
                </button>
              )}

              {onReCalibrate && (
                <button
                  onClick={onReCalibrate}
                  title="Calibrar sensibilidad"
                  className="p-1 rounded hover:bg-slate-800 text-slate-300 hover:text-white transition cursor-pointer"
                >
                  <Sparkles className="w-3 h-3 text-amber-400" />
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </aside>
  );
};
