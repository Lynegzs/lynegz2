import React, { memo } from 'react';
import { WasteCategory } from '../types';

interface RecyclingBinProps {
  category: WasteCategory;
  isHovered?: boolean;
  isTargeted?: boolean;
  dropFeedback?: 'correct' | 'incorrect' | null;
}

export const RecyclingBin: React.FC<RecyclingBinProps> = memo(({
  category,
  isHovered = false,
  dropFeedback = null
}) => {
  // Pure color palette for each container - High definition industrial tones
  const getContainerPalette = () => {
    switch (category) {
      case 'verde':
        return {
          main: '#16a34a',
          dark: '#14532d',
          darker: '#052e16',
          light: '#4ade80',
          shine: '#bbf7d0',
          glow: 'rgba(34, 197, 94, 0.4)'
        };
      case 'azul':
        return {
          main: '#2563eb',
          dark: '#1e3a8a',
          darker: '#172554',
          light: '#60a5fa',
          shine: '#bfdbfe',
          glow: 'rgba(59, 130, 246, 0.4)'
        };
      case 'gris':
        return {
          main: '#475569',
          dark: '#1e293b',
          darker: '#0f172a',
          light: '#94a3b8',
          shine: '#e2e8f0',
          glow: 'rgba(148, 163, 184, 0.35)'
        };
      case 'rojo':
        return {
          main: '#dc2626',
          dark: '#991b1b',
          darker: '#450a0a',
          light: '#f87171',
          shine: '#fecaca',
          glow: 'rgba(239, 68, 68, 0.4)'
        };
    }
  };

  const pal = getContainerPalette();

  return (
    <div
      id={`contenedor-${category}`}
      className={`relative flex flex-col items-center justify-end transition-all duration-300 select-none group ${
        isHovered
          ? 'scale-105 -translate-y-2'
          : 'hover:-translate-y-0.5'
      } ${
        dropFeedback === 'correct' ? 'ring-4 ring-emerald-400 animate-bounce' : ''
      } ${
        dropFeedback === 'incorrect' ? 'ring-4 ring-rose-500 animate-shake' : ''
      }`}
    >
      {/* Dynamic ambient ground shadow */}
      <div
        className={`w-14 min-[400px]:w-16 sm:w-18 md:w-20 h-2 sm:h-2.5 rounded-full bg-black/40 blur-xs -mb-1 transition-all duration-300 ${
          isHovered ? 'scale-110 opacity-60' : 'opacity-40'
        }`}
      />

      {/* Floating glow aura on hover */}
      {isHovered && (
        <div
          className="absolute inset-x-1 bottom-0 top-3 rounded-2xl blur-lg pointer-events-none transition-opacity duration-300"
          style={{ backgroundColor: pal.glow }}
        />
      )}

      {/* Correct Deposit Glowing Aura & Shockwave Ring */}
      {dropFeedback === 'correct' && (
        <>
          <div className="absolute -inset-2 rounded-2xl bg-emerald-400/35 blur-lg pointer-events-none animate-pulse-glow" />
          <div className="absolute -bottom-1 w-16 sm:w-20 md:w-24 h-4 rounded-full border border-emerald-400 animate-ping pointer-events-none opacity-80" />
          {/* Floating mini celebration tag */}
          <div className="absolute -top-7 sm:-top-8 z-30 pointer-events-none flex items-center gap-1 animate-float-up">
            <span className="text-sm">✨</span>
            <span className="text-[9px] sm:text-[10px] font-black text-emerald-300 bg-slate-950/95 px-2 py-0.5 rounded-full border border-emerald-400 shadow-lg">
              +10 ⭐
            </span>
          </div>
        </>
      )}

      {/* Incorrect Deposit Warning Flash Aura */}
      {dropFeedback === 'incorrect' && (
        <div className="absolute -inset-2 rounded-2xl bg-rose-500/35 blur-lg pointer-events-none" />
      )}

      {/* Target drop indicator badge (NO category name, NO logo) */}
      {isHovered && (
        <div className="absolute -top-6 sm:-top-7 z-30 px-2 py-0.5 bg-slate-900/90 text-white font-black text-[8px] min-[400px]:text-[9px] sm:text-[10px] rounded-full shadow-lg border border-white/20 whitespace-nowrap animate-bounce flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
          <span>¡SOLTAR AQUÍ!</span>
        </div>
      )}

      {/* 3D Realistic Industrial Wheelie Bin (Compact scale for zero-zoom required) */}
      <div className="relative w-15 min-[380px]:w-16 min-[440px]:w-18 sm:w-20 md:w-22 lg:w-24 aspect-[1/1.25] drop-shadow-xl">
        <svg
          viewBox="0 0 100 125"
          className="w-full h-full overflow-visible"
        >
          <defs>
            {/* Body 3D cylinder gradient */}
            <linearGradient id={`body-grad-${category}`} x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor={pal.light} />
              <stop offset="25%" stopColor={pal.main} />
              <stop offset="70%" stopColor={pal.dark} />
              <stop offset="100%" stopColor={pal.darker} />
            </linearGradient>

            {/* Lid surface lighting gradient */}
            <linearGradient id={`lid-grad-${category}`} x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor={pal.light} />
              <stop offset="35%" stopColor={pal.main} />
              <stop offset="85%" stopColor={pal.dark} />
              <stop offset="100%" stopColor={pal.darker} />
            </linearGradient>

            {/* Inner rim drop-shadow */}
            <linearGradient id="inner-shadow" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#000000" stopOpacity="0.5" />
              <stop offset="100%" stopColor="#000000" stopOpacity="0" />
            </linearGradient>

            {/* Heavy rubber wheel gradient */}
            <radialGradient id="wheel-rubber" cx="35%" cy="35%" r="65%">
              <stop offset="0%" stopColor="#475569" />
              <stop offset="60%" stopColor="#1e293b" />
              <stop offset="100%" stopColor="#020617" />
            </radialGradient>

            {/* Steel rim gradient for wheels */}
            <linearGradient id="wheel-rim" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#cbd5e1" />
              <stop offset="50%" stopColor="#64748b" />
              <stop offset="100%" stopColor="#334155" />
            </linearGradient>

            {/* Molded plastic specular highlight stripe */}
            <linearGradient id="specular-stripe" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#ffffff" stopOpacity="0.25" />
              <stop offset="50%" stopColor="#ffffff" stopOpacity="0.08" />
              <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
            </linearGradient>
          </defs>

          {/* 1. STEEL AXLE & REAR WHEELS */}
          {/* Steel axle connecting bar */}
          <rect x="15" y="98" width="70" height="4.5" rx="2" fill="#0f172a" stroke="#334155" strokeWidth="0.8" />

          {/* Left heavy rubber tire */}
          <g>
            <ellipse cx="13" cy="100" rx="8.5" ry="16" fill="url(#wheel-rubber)" stroke="#020617" strokeWidth="1.2" />
            <ellipse cx="13" cy="100" rx="4.5" ry="9" fill="url(#wheel-rim)" stroke="#1e293b" strokeWidth="0.8" />
            <circle cx="13" cy="100" r="2" fill="#0f172a" />
          </g>

          {/* Right heavy rubber tire */}
          <g>
            <ellipse cx="87" cy="100" rx="8.5" ry="16" fill="url(#wheel-rubber)" stroke="#020617" strokeWidth="1.2" />
            <ellipse cx="87" cy="100" rx="4.5" ry="9" fill="url(#wheel-rim)" stroke="#1e293b" strokeWidth="0.8" />
            <circle cx="87" cy="100" r="2" fill="#0f172a" />
          </g>

          {/* 2. REAR HINGES & HANDLE AT BACK */}
          <rect x="22" y="24" width="6" height="10" rx="1.5" fill="#0f172a" />
          <rect x="72" y="24" width="6" height="10" rx="1.5" fill="#0f172a" />
          <rect x="28" y="22" width="44" height="4" rx="2" fill="#1e293b" />

          {/* 3. MAIN CONTAINER TAPERED BODY */}
          {/* Base outer hull */}
          <path
            d="M18 34 L24 104 C24 107.5, 27.5 110, 32 110 L68 110 C72.5 110, 76 107.5, 76 104 L82 34 Z"
            fill={`url(#body-grad-${category})`}
            stroke={pal.darker}
            strokeWidth="1.5"
          />

          {/* Molded Front Recessed Panel (Giving realistic modern container geometry) */}
          <path
            d="M26 42 L30 102 C30 104, 32.5 105.5, 36 105.5 L64 105.5 C67.5 105.5, 70 104, 70 102 L74 42 Z"
            fill="#000000"
            opacity="0.1"
          />
          <path
            d="M27 43 L31 101 C31 102.5, 33 104, 36 104 L64 104 C67 104, 69 102.5, 69 101 L73 43 Z"
            fill="none"
            stroke={pal.dark}
            strokeWidth="1"
            opacity="0.6"
          />

          {/* Left Vertical Specular Curved Light Reflection Streak */}
          <path
            d="M22 36 L26 102 C26 103, 28 103.5, 30 103.5 L34 103.5 L30 36 Z"
            fill="url(#specular-stripe)"
          />

          {/* Structural Horizontal Reinforcement Ribs (Commercial design) */}
          <g opacity="0.35">
            {/* Top rib */}
            <path d="M22 52 L78 52" stroke={pal.light} strokeWidth="1.5" strokeLinecap="round" />
            <path d="M22 53.5 L78 53.5" stroke={pal.darker} strokeWidth="1.5" strokeLinecap="round" />

            {/* Mid rib */}
            <path d="M24 72 L76 72" stroke={pal.light} strokeWidth="1.5" strokeLinecap="round" />
            <path d="M24 73.5 L76 73.5" stroke={pal.darker} strokeWidth="1.5" strokeLinecap="round" />

            {/* Lower rib */}
            <path d="M25 90 L75 90" stroke={pal.light} strokeWidth="1.5" strokeLinecap="round" />
            <path d="M25 91.5 L75 91.5" stroke={pal.darker} strokeWidth="1.5" strokeLinecap="round" />
          </g>

          {/* Front Pickup Bar (Peine elevador de camión de basura) */}
          <rect x="34" y="99" width="32" height="3" rx="1" fill="#0f172a" opacity="0.4" />

          {/* 4. UPPER COLLAR / REINFORCED RIM */}
          <rect
            x="15"
            y="29"
            width="70"
            height="7"
            rx="2.5"
            fill={`url(#lid-grad-${category})`}
            stroke={pal.darker}
            strokeWidth="1.3"
          />
          {/* Rim light highlight line */}
          <line x1="17" y1="30.5" x2="83" y2="30.5" stroke={pal.shine} strokeWidth="1" strokeLinecap="round" opacity="0.7" />

          {/* 5. INTERACTIVE HINGED LID */}
          {/* When hovered, lid tilts slightly upward (open ready effect) */}
          <g
            className="transition-transform duration-300 origin-[50%_25%]"
            style={{
              transform: isHovered ? 'rotate(-10deg) translateY(-4px)' : 'none'
            }}
          >
            {/* Main Lid Sloped Shell */}
            <path
              d="M16 29 L21 16 C22.5 13.5, 25 12, 29 12 L71 12 C75 12, 77.5 13.5, 79 16 L84 29 Z"
              fill={`url(#lid-grad-${category})`}
              stroke={pal.darker}
              strokeWidth="1.4"
            />

            {/* Lid top bevel reflection */}
            <path
              d="M22 17 L28 14 L72 14 L78 17 Z"
              fill={pal.light}
              opacity="0.3"
            />

            {/* Front overhang lip */}
            <path
              d="M15 28 L85 28 L84 32 L16 32 Z"
              fill={pal.dark}
              opacity="0.5"
            />

            {/* Molded ergonomic top grab handle */}
            <rect
              x="36"
              y="7"
              width="28"
              height="6.5"
              rx="3"
              fill={pal.main}
              stroke={pal.darker}
              strokeWidth="1.2"
            />
            {/* Handle grip indentation & shine */}
            <rect
              x="41"
              y="8.5"
              width="18"
              height="2"
              rx="1"
              fill={pal.shine}
              opacity="0.85"
            />
            <rect
              x="41"
              y="11"
              width="18"
              height="1.5"
              rx="0.5"
              fill={pal.darker}
              opacity="0.6"
            />
          </g>
        </svg>
      </div>
    </div>
  );
});
