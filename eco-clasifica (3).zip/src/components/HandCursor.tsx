import React, { memo } from 'react';

interface HandCursorProps {
  x: number;
  y: number;
  isPinching: boolean;
  isHoldingItem: boolean;
  detected: boolean;
  pinchDistance?: number;
}

export const HandCursor: React.FC<HandCursorProps> = memo(({
  x,
  y,
  isPinching,
  isHoldingItem,
  detected,
  pinchDistance = 0.2
}) => {
  if (!detected) return null;

  // Ring radius based on pinch proximity
  const ringSize = Math.max(28, Math.min(64, pinchDistance * 320));

  return (
    <div
      id="cursor-virtual-mano"
      style={{
        transform: `translate3d(${x}px, ${y}px, 0)`,
        willChange: 'transform'
      }}
      className="absolute top-0 left-0 pointer-events-none z-50 -translate-x-1/2 -translate-y-1/2 select-none"
    >
      {/* Outer Proximity / Pinch Ring */}
      <div
        style={{
          width: `${ringSize}px`,
          height: `${ringSize}px`
        }}
        className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 transition-transform duration-75 ${
          isPinching
            ? 'border-emerald-400 bg-emerald-500/20 scale-90 ring-4 ring-emerald-400/40'
            : 'border-amber-400/70 bg-amber-400/10'
        }`}
      />

      {/* Central Solid Dot ● */}
      <div
        className={`w-3.5 h-3.5 rounded-full shadow-lg border border-white mx-auto ${
          isPinching ? 'bg-emerald-400' : 'bg-amber-400'
        }`}
      />

      {/* Hand Emoji Icon floating above */}
      <div className="absolute -top-9 left-1/2 -translate-x-1/2 text-2xl filter drop-shadow animate-pulse">
        {isPinching || isHoldingItem ? '🤏' : '🖐️'}
      </div>

      {/* Pinch status indicator */}
      <div className="absolute top-4 left-1/2 -translate-x-1/2 whitespace-nowrap">
        <span
          className={`text-[9px] font-black uppercase px-1.5 py-0.5 rounded shadow ${
            isPinching
              ? 'bg-emerald-500 text-slate-950 ring-1 ring-emerald-300'
              : 'bg-slate-800/80 text-amber-300 border border-amber-400/30'
          }`}
        >
          {isHoldingItem ? 'AGARRADO' : isPinching ? 'PINZA' : 'ABIERTA'}
        </span>
      </div>
    </div>
  );
});
