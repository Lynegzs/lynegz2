import { WasteItem, CategoryInfo, WasteCategory, GameLevel } from '../types';

export const CATEGORIAS: Record<WasteCategory, CategoryInfo> = {
  verde: {
    id: 'verde',
    nombre: 'Verde',
    etiqueta: 'ORGÁNICOS',
    descripcion: 'Restos de comida, frutas, verduras, cáscaras y materia biodegradable compostable',
    colorHex: '#16a34a',
    bgTailwind: 'bg-emerald-600',
    borderTailwind: 'border-emerald-500',
    badgeTailwind: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
    tipo: 'Orgánico'
  },
  azul: {
    id: 'azul',
    nombre: 'Azul',
    etiqueta: 'RECICLABLES / APROVECHABLES',
    descripcion: 'Plásticos limpios, botellas PET, papel, cartón limpio, latas de aluminio y vidrio entero',
    colorHex: '#2563eb',
    bgTailwind: 'bg-blue-600',
    borderTailwind: 'border-blue-500',
    badgeTailwind: 'bg-blue-500/20 text-blue-300 border-blue-500/40',
    tipo: 'Aprovechable'
  },
  gris: {
    id: 'gris',
    nombre: 'Gris',
    etiqueta: 'NO APROVECHABLES / ORDINARIOS',
    descripcion: 'Papel higiénico, servilletas usadas, cartón manchado con grasa, cerámica rota, colillas y plásticos no reciclables',
    colorHex: '#475569',
    bgTailwind: 'bg-slate-600',
    borderTailwind: 'border-slate-500',
    badgeTailwind: 'bg-slate-500/20 text-slate-300 border-slate-500/40',
    tipo: 'No Aprovechable'
  },
  rojo: {
    id: 'rojo',
    nombre: 'Rojo',
    etiqueta: 'PELIGROSOS / HOSPITALARIOS / QUÍMICOS',
    descripcion: 'Pilas, baterías, medicamentos caducados, jeringas, químicos, solventes y desechos biológico-infecciosos',
    colorHex: '#dc2626',
    bgTailwind: 'bg-rose-600',
    borderTailwind: 'border-rose-500',
    badgeTailwind: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
    tipo: 'Peligroso'
  }
};

/**
 * 10 NIVELES DE DIFICULTAD CRECIENTE
 * Cada nivel cuenta con exactamente 10 objetos representativos y didácticos.
 */
export const NIVELES_JUEGO: GameLevel[] = [
  // NIVEL 1: INICIACIÓN BÁSICA (Muy Fácil)
  {
    levelNumber: 1,
    title: 'Nivel 1: Iniciación Ecológica',
    subtitle: 'Residuos Cotidanos Básicos',
    difficulty: 'Muy Fácil',
    description: 'Aprende los colores básicos identificando los residuos más obvios y directos.',
    items: [
      {
        id: 1,
        nombre: 'Cáscara de banana',
        categoria: 'verde',
        emoji: '🍌',
        descripcion: 'Materia orgánica biodegradable directa al compost.'
      },
      {
        id: 2,
        nombre: 'Botella de agua PET',
        categoria: 'azul',
        emoji: '🧴',
        descripcion: 'Plástico transparente 100% reciclable para nuevos envases.'
      },
      {
        id: 3,
        nombre: 'Manzana mordida',
        categoria: 'verde',
        emoji: '🍎',
        descripcion: 'Resto de fruta fresca rica en nutrientes orgánicos.'
      },
      {
        id: 4,
        nombre: 'Hoja de papel de libreta',
        categoria: 'azul',
        emoji: '📄',
        descripcion: 'Papel seco y limpio listo para procesarse como pasta de papel.'
      },
      {
        id: 5,
        nombre: 'Pila alcalina AA',
        categoria: 'rojo',
        emoji: '🔋',
        descripcion: 'Contiene metales pesados altamente contaminantes para el agua.'
      },
      {
        id: 6,
        nombre: 'Lata de gaseosa',
        categoria: 'azul',
        emoji: '🥤',
        descripcion: 'Aluminio puro fundible indefinidamente sin perder propiedades.'
      },
      {
        id: 7,
        nombre: 'Servilleta con grasa',
        categoria: 'gris',
        emoji: '🧻',
        descripcion: 'El papel manchado de comida no puede reciclarse.'
      },
      {
        id: 8,
        nombre: 'Botella de vidrio',
        categoria: 'azul',
        emoji: '🍾',
        descripcion: 'Vidrio transparente entero 100% reciclable.'
      },
      {
        id: 9,
        nombre: 'Restos de lechuga',
        categoria: 'verde',
        emoji: '🥗',
        descripcion: 'Vegetal orgánico degradable rápidamente en abono.'
      },
      {
        id: 10,
        nombre: 'Jeringa médica usada',
        categoria: 'rojo',
        emoji: '💉',
        descripcion: 'Residuo biosanitario punzocortante de riesgo biológico.'
      }
    ]
  },

  // NIVEL 2: HOGAR COTIDIANO (Fácil)
  {
    levelNumber: 2,
    title: 'Nivel 2: Hogar Cotidiano',
    subtitle: 'Separación en la Casa',
    difficulty: 'Fácil',
    description: 'Distingue entre empaques comunes, restos de alimentos y residuos domésticos.',
    items: [
      {
        id: 11,
        nombre: 'Caja de cereales limpia',
        categoria: 'azul',
        emoji: '📦',
        descripcion: 'Cartón seco no contaminado perfecto para reciclaje.'
      },
      {
        id: 12,
        nombre: 'Pañal desechable usado',
        categoria: 'gris',
        emoji: '🧷',
        descripcion: 'Residuo higiénico contaminado que va directo al vertedero.'
      },
      {
        id: 13,
        nombre: 'Posos de café molido',
        categoria: 'verde',
        emoji: '☕',
        descripcion: 'Materia orgánica rica en nitrógeno para abono.'
      },
      {
        id: 14,
        nombre: 'Termómetro de mercurio',
        categoria: 'rojo',
        emoji: '🌡️',
        descripcion: 'Peligroso por mercurio líquido tóxico en caso de rotura.'
      },
      {
        id: 15,
        nombre: 'Brik de leche enjuagado',
        categoria: 'azul',
        emoji: '🧃',
        descripcion: 'Envase multicapa reciclable en el circuito de envases.'
      },
      {
        id: 16,
        nombre: 'Hojas secas del jardín',
        categoria: 'verde',
        emoji: '🍂',
        descripcion: 'Biomasa vegetal compostable.'
      },
      {
        id: 17,
        nombre: 'Vaso de plástico descartable',
        categoria: 'azul',
        emoji: '🥛',
        descripcion: 'Envase de polipropileno reciclable si está vacío.'
      },
      {
        id: 18,
        nombre: 'Polvo de barrer el piso',
        categoria: 'gris',
        emoji: '🧹',
        descripcion: 'Mezcla inorgánica de suciedad y ácaros no aprovechable.'
      },
      {
        id: 19,
        nombre: 'Tubo de pasta dental vacío',
        categoria: 'azul',
        emoji: '🪥',
        descripcion: 'Envase plástico flexible que se procesa en reciclaje de polímeros.'
      },
      {
        id: 20,
        nombre: 'Blíster de pastillas vacío',
        categoria: 'azul',
        emoji: '💊',
        descripcion: 'Blíster plástico/aluminio vacío sin restos de medicina.'
      }
    ]
  },

  // NIVEL 3: COCINA Y ALIMENTOS (Media)
  {
    levelNumber: 3,
    title: 'Nivel 3: Cocina y Despensa',
    subtitle: 'Comida vs Grasas y Empaques',
    difficulty: 'Media',
    description: 'Aprende qué hacer con empaques manchados de aceite y restos de cocina.',
    items: [
      {
        id: 21,
        nombre: 'Cáscaras de huevo',
        categoria: 'verde',
        emoji: '🥚',
        descripcion: 'Calcio puro orgánico excelente para la tierra y compost.'
      },
      {
        id: 22,
        nombre: 'Caja de pizza grasienta',
        categoria: 'gris',
        emoji: '🍕',
        descripcion: '¡Cuidado! El cartón con grasa NO puede reciclarse con el papel.'
      },
      {
        id: 23,
        nombre: 'Lata de atún enjuagada',
        categoria: 'azul',
        emoji: '🥫',
        descripcion: 'Hojalata metálica limpia 100% reutilizable en siderurgia.'
      },
      {
        id: 24,
        nombre: 'Huesos de pollo',
        categoria: 'verde',
        emoji: '🍗',
        descripcion: 'Resto cárnico orgánico biodegradable.'
      },
      {
        id: 25,
        nombre: 'Papel de cocina sucio',
        categoria: 'gris',
        emoji: '📜',
        descripcion: 'Papel tisú degradado y lleno de grasa culinaria.'
      },
      {
        id: 26,
        nombre: 'Frasco de mermelada',
        categoria: 'azul',
        emoji: '🫙',
        descripcion: 'Envase de vidrio que se funde indefinidamente.'
      },
      {
        id: 27,
        nombre: 'Saquito de té usado',
        categoria: 'verde',
        emoji: '🍵',
        descripcion: 'Hierbas y filtro natural compostable.'
      },
      {
        id: 28,
        nombre: 'Chapas metálicas de botella',
        categoria: 'azul',
        emoji: '🍺',
        descripcion: 'Metal ferroso recuperable por imanes en plantas de reciclaje.'
      },
      {
        id: 29,
        nombre: 'Papel film con grasa pegada',
        categoria: 'gris',
        emoji: '🥪',
        descripcion: 'Plástico ultrafino manchado imposible de procesar.'
      },
      {
        id: 30,
        nombre: 'Insecticida en aerosol con restos',
        categoria: 'rojo',
        emoji: '🪲',
        descripcion: 'Químico tóxico inflamable con propelente a presión.'
      }
    ]
  },

  // NIVEL 4: OFICINA Y ESTUDIO (Media-Alta)
  {
    levelNumber: 4,
    title: 'Nivel 4: Oficina y Estudio',
    subtitle: 'Papelería y Químicos Escolares',
    difficulty: 'Media-Alta',
    description: 'Descubre los falsos amigos del papel y útiles de oficina.',
    items: [
      {
        id: 31,
        nombre: 'Clips y grapas metálicas',
        categoria: 'azul',
        emoji: '📎',
        descripcion: 'Metal férrico reciclable.'
      },
      {
        id: 32,
        nombre: 'Ticket de compra térmico',
        categoria: 'gris',
        emoji: '🧾',
        descripcion: '¡Atención! El papel térmico contiene Bisfenol A y arruina el reciclaje de papel.'
      },
      {
        id: 33,
        nombre: 'Periódico seco viejo',
        categoria: 'azul',
        emoji: '📰',
        descripcion: 'Papel prensa ideal para transformarse en cartón reciclado.'
      },
      {
        id: 34,
        nombre: 'Cinta adhesiva usada',
        categoria: 'gris',
        emoji: '🩹',
        descripcion: 'Polímero plástico con adhesivo sintético no reciclable.'
      },
      {
        id: 35,
        nombre: 'Líquido corrector / Tipp-ex',
        categoria: 'rojo',
        emoji: '🖊️',
        descripcion: 'Compuesto químico con solventes orgánicos volátiles.'
      },
      {
        id: 36,
        nombre: 'Revista vieja de papel couché',
        categoria: 'azul',
        emoji: '📑',
        descripcion: 'Papel impreso brillante recuperable en la industria papelera.'
      },
      {
        id: 37,
        nombre: 'Bolígrafo gastado de plástico',
        categoria: 'gris',
        emoji: '✒️',
        descripcion: 'No es envase: compuesto de múltiples plásticos mezclados con tinta.'
      },
      {
        id: 38,
        nombre: 'Resaltador fluorescente seco',
        categoria: 'gris',
        emoji: '🖍️',
        descripcion: 'Plástico multimaterial con esponja sintética seca.'
      },
      {
        id: 39,
        nombre: 'Pila de botón de reloj',
        categoria: 'rojo',
        emoji: '⏱️',
        descripcion: 'Microbatería de litio/óxido de plata sumamente peligrosa.'
      },
      {
        id: 40,
        nombre: 'Cáscara de mandarina',
        categoria: 'verde',
        emoji: '🍊',
        descripcion: 'Piel cítrica biodegradable.'
      }
    ]
  },

  // NIVEL 5: BAÑO, HIGIENE Y BELLEZA (Intermedia)
  {
    levelNumber: 5,
    title: 'Nivel 5: Baño y Cosmética',
    subtitle: 'Higiene Personal y Salud',
    difficulty: 'Intermedia',
    description: 'Los productos del aseo personal tienen reglas de reciclaje muy particulares.',
    items: [
      {
        id: 41,
        nombre: 'Cepillo de dientes de plástico',
        categoria: 'gris',
        emoji: '🪥',
        descripcion: '¡Error común! No es un envase, contiene cerdas de nylon mixtas.'
      },
      {
        id: 42,
        nombre: 'Bote de champú vacío',
        categoria: 'azul',
        emoji: '🧴',
        descripcion: 'Plástico PEAD rígido de alto valor para reciclado.'
      },
      {
        id: 43,
        nombre: 'Bastoncillos para oídos',
        categoria: 'gris',
        emoji: '👂',
        descripcion: 'Algodón con restos biológicos que atascan las redes sanitarias.'
      },
      {
        id: 44,
        nombre: 'Jarabe caducado en frasco',
        categoria: 'rojo',
        emoji: '💊',
        descripcion: 'Fármacos químicos que contaminan ríos y fuentes hídricas.'
      },
      {
        id: 45,
        nombre: 'Discos desmaquillantes usados',
        categoria: 'gris',
        emoji: '💄',
        descripcion: 'Algodón manchado con químicos y tintes cosméticos.'
      },
      {
        id: 46,
        nombre: 'Frasco de perfume de vidrio',
        categoria: 'azul',
        emoji: '✨',
        descripcion: 'Vidrio cosmético apto para trituración y fundición.'
      },
      {
        id: 47,
        nombre: 'Esmalte de uñas con acetona',
        categoria: 'rojo',
        emoji: '💅',
        descripcion: 'Laca con disolventes químicos inflamables y tóxicos.'
      },
      {
        id: 48,
        nombre: 'Toallitas húmedas higiénicas',
        categoria: 'gris',
        emoji: '🧻',
        descripcion: 'Hechas con fibras plásticas no biodegradables que no se deshacen.'
      },
      {
        id: 49,
        nombre: 'Tarro de crema facial enjuagado',
        categoria: 'azul',
        emoji: '🧴',
        descripcion: 'Envase cosmético limpio de polipropileno.'
      },
      {
        id: 50,
        nombre: 'Cuchilla de afeitar desechable',
        categoria: 'rojo',
        emoji: '🪒',
        descripcion: 'Objeto punzocortante de riesgo higiénico y sanitario.'
      }
    ]
  },

  // NIVEL 6: MATERIALES COMPLEJOS Y MIXTOS (Avanzada)
  {
    levelNumber: 6,
    title: 'Nivel 6: Materiales Mixtos',
    subtitle: 'Capas y Compuestos Tramposos',
    difficulty: 'Avanzada',
    description: 'Identifica la diferencia entre envases compuestos y materiales no reciclables.',
    items: [
      {
        id: 51,
        nombre: 'Vaso de café para llevar con film',
        categoria: 'gris',
        emoji: '☕',
        descripcion: 'El cartón está plastificado por dentro con polietileno inseparable.'
      },
      {
        id: 52,
        nombre: 'Papel de aluminio limpio',
        categoria: 'azul',
        emoji: '🌯',
        descripcion: 'Metal de aluminio puro sin restos de grasa.'
      },
      {
        id: 53,
        nombre: 'Papel de aluminio quemado con grasa',
        categoria: 'gris',
        emoji: '🍳',
        descripcion: 'Aluminio carbonizado con grasas quemadas inseparables.'
      },
      {
        id: 54,
        nombre: 'Ramas secas y poda del jardín',
        categoria: 'verde',
        emoji: '🌿',
        descripcion: 'Materia leñosa natural ideal para compost vegetal.'
      },
      {
        id: 55,
        nombre: 'Bombilla incandescente vieja',
        categoria: 'gris',
        emoji: '💡',
        descripcion: '¡No va con el vidrio! Lleva filamentos de tungsteno y vidrio no fundible igual.'
      },
      {
        id: 56,
        nombre: 'Tubo fluorescente largo',
        categoria: 'rojo',
        emoji: '⚡',
        descripcion: 'Peligro grave por vapor de mercurio y fósforo altamente venenoso.'
      },
      {
        id: 57,
        nombre: 'Tapitas de botellas plásticas',
        categoria: 'azul',
        emoji: '🔵',
        descripcion: 'Polietileno de alta densidad ideal para fundir en nuevos productos.'
      },
      {
        id: 58,
        nombre: 'Espejo roto en pedazos',
        categoria: 'gris',
        emoji: '🪞',
        descripcion: 'Lleva nitrato de plata y plomo detrás que arruina el reciclaje de vidrio.'
      },
      {
        id: 59,
        nombre: 'Batería de smartphone hinchada',
        categoria: 'rojo',
        emoji: '📱',
        descripcion: 'Químico de litio presurizado con riesgo inminente de explosión.'
      },
      {
        id: 60,
        nombre: 'Envase de yogur limpio',
        categoria: 'azul',
        emoji: '🥛',
        descripcion: 'Envase de poliestireno apto para el contenedor de reciclables.'
      }
    ]
  },

  // NIVEL 7: TECNOLOGÍA Y RESIDUOS URBANOS (Experto)
  {
    levelNumber: 7,
    title: 'Nivel 7: Electrónica y Químicos',
    subtitle: 'Desechos Tecnológicos y Urbanos',
    difficulty: 'Experto',
    description: 'Desafíos con cables, envases de solventes y piezas tecnológicas.',
    items: [
      {
        id: 61,
        nombre: 'Cable USB roto con cobre',
        categoria: 'azul',
        emoji: '🔌',
        descripcion: 'Contiene cobre y metales preciosos recuperables.'
      },
      {
        id: 62,
        nombre: 'Lata de pintura con restos secos',
        categoria: 'rojo',
        emoji: '🎨',
        descripcion: 'Pigmentos sintéticos con disolventes químicos peligrosos.'
      },
      {
        id: 63,
        nombre: 'Botella de lavandina enjuagada',
        categoria: 'azul',
        emoji: '🧴',
        descripcion: 'Plástico PEAD limpio sin restos líquidos.'
      },
      {
        id: 64,
        nombre: 'Frasco de aguarrás / solvente',
        categoria: 'rojo',
        emoji: '🧪',
        descripcion: 'Hidrocarburo inflamable de alta toxicidad ambiental.'
      },
      {
        id: 65,
        nombre: 'Disco CD / DVD rayado',
        categoria: 'gris',
        emoji: '💿',
        descripcion: 'Policarbonato con capa de aluminio que no se procesa en reciclaje común.'
      },
      {
        id: 66,
        nombre: 'Cartucho de tóner / tinta',
        categoria: 'rojo',
        emoji: '🖨️',
        descripcion: 'Micropartículas de carbón y resinas tóxicas para el sistema respiratorio.'
      },
      {
        id: 67,
        nombre: 'Pila recargable de níquel-cadmio',
        categoria: 'rojo',
        emoji: '🔋',
        descripcion: 'El cadmio es un metal pesado cancerígeno de manejo especial.'
      },
      {
        id: 68,
        nombre: 'Corcho natural de vino',
        categoria: 'verde',
        emoji: '🍾',
        descripcion: 'Corteza de alcornoque 100% natural, vegetal y biodegradable.'
      },
      {
        id: 69,
        nombre: 'Tapón sintético de silicona',
        categoria: 'gris',
        emoji: '🔘',
        descripcion: 'Polímero plástico no reciclable en el circuito municipal.'
      },
      {
        id: 70,
        nombre: 'Trapo con grasa de motor',
        categoria: 'rojo',
        emoji: '🧯',
        descripcion: 'Textil saturado de hidrocarburos inflamables de taller.'
      }
    ]
  },

  // NIVEL 8: MITOS ECOLÓGICOS (Muy Difícil)
  {
    levelNumber: 8,
    title: 'Nivel 8: Mitos Ecológicos',
    subtitle: 'Trampas Frecuentes en el Reciclaje',
    difficulty: 'Muy Difícil',
    description: 'Pon a prueba tus conocimientos desmintiendo mitos de clasificación urbana.',
    items: [
      {
        id: 71,
        nombre: 'Plato de cerámica partido',
        categoria: 'gris',
        emoji: '🍽️',
        descripcion: '¡Mito peligroso! La cerámica NO es vidrio y tiene otro punto de fusión.'
      },
      {
        id: 72,
        nombre: 'Bolsa de bioplástico PLA compostable',
        categoria: 'verde',
        emoji: '🛍️',
        descripcion: 'Hecha de almidón de maíz con certificado industrial de compostaje.'
      },
      {
        id: 73,
        nombre: 'Chicle mascado',
        categoria: 'gris',
        emoji: '🍬',
        descripcion: 'Goma sintética plástica que no se degrada orgánicamente.'
      },
      {
        id: 74,
        nombre: 'Cenizas de madera natural pura',
        categoria: 'verde',
        emoji: '🪵',
        descripcion: 'Potasio y fósforo vegetal orgánico para abonar plantas.'
      },
      {
        id: 75,
        nombre: 'Cenizas de carbón mineral procesado',
        categoria: 'gris',
        emoji: '🔥',
        descripcion: 'Residuo mineral cargado de azufre y compuestos no agrícolas.'
      },
      {
        id: 76,
        nombre: 'Bolsa metalizada de snacks',
        categoria: 'gris',
        emoji: '🥔',
        descripcion: 'Capas inseparables de polipropileno y aluminio microscópico.'
      },
      {
        id: 77,
        nombre: 'Frasco de jarabe vacío y enjuagado',
        categoria: 'azul',
        emoji: '🍯',
        descripcion: 'Vidrio medicinal esterilizado y enjuagado apto para reciclaje.'
      },
      {
        id: 78,
        nombre: 'Gasas con sangre y yodo',
        categoria: 'rojo',
        emoji: '🩹',
        descripcion: 'Material biológico de curación infectocontagioso.'
      },
      {
        id: 79,
        nombre: 'Mechero / encendedor vacío de plástico',
        categoria: 'gris',
        emoji: '🔥',
        descripcion: 'Resorte de metal con plástico mixto y restos de gas.'
      },
      {
        id: 80,
        nombre: 'Desodorante roll-on limpio',
        categoria: 'azul',
        emoji: '🧴',
        descripcion: 'Envase de plástico reciclable en el contenedor azul.'
      }
    ]
  },

  // NIVEL 9: CRITERIO TÉCNICO AVANZADO (Maestro)
  {
    levelNumber: 9,
    title: 'Nivel 9: Gestión Técnica',
    subtitle: 'Criterio Ambiental Especializado',
    difficulty: 'Maestro',
    description: 'Residuos que requieren conocimiento técnico preciso de separación de materiales.',
    items: [
      {
        id: 81,
        nombre: 'Placa de radiografía médica',
        categoria: 'rojo',
        emoji: '🩻',
        descripcion: 'Emulsión fotográfica con haluros y sales de plata pesada.'
      },
      {
        id: 82,
        nombre: 'Filtro de café con restos de molienda',
        categoria: 'verde',
        emoji: '☕',
        descripcion: 'Papel sin clorar y granos 100% orgánicos biodegradables.'
      },
      {
        id: 83,
        nombre: 'Tubo de pegamento cianoacrilato',
        categoria: 'rojo',
        emoji: '🧪',
        descripcion: 'Polímero reactivo irritante con vapores químicos peligrosos.'
      },
      {
        id: 84,
        nombre: 'Hilo dental usado con cera',
        categoria: 'gris',
        emoji: '🧵',
        descripcion: 'Filamentos sintéticos encerados no biodegradables.'
      },
      {
        id: 85,
        nombre: 'Papel de hornear sulfurizado quemado',
        categoria: 'gris',
        emoji: '🍪',
        descripcion: 'Papel tratado con silicona y ácido sulfúrico resistente al agua.'
      },
      {
        id: 86,
        nombre: 'Lata de sardinas lavada',
        categoria: 'azul',
        emoji: '🐟',
        descripcion: 'Hojalata de acero estañado reciclable.'
      },
      {
        id: 87,
        nombre: 'Aerosol de desodorante vacío',
        categoria: 'azul',
        emoji: '💨',
        descripcion: 'Aluminio presurizado totalmente desgasificado y seco.'
      },
      {
        id: 88,
        nombre: 'Mascarilla quirúrgica usada',
        categoria: 'gris',
        emoji: '😷',
        descripcion: 'Polipropileno termosellado con fluidos respiratorios.'
      },
      {
        id: 89,
        nombre: 'Cápsula de café de aluminio vaciada',
        categoria: 'azul',
        emoji: '☕',
        descripcion: 'Metal de aluminio limpio sin los posos orgánicos.'
      },
      {
        id: 90,
        nombre: 'Conchas de mejillones y almejas',
        categoria: 'verde',
        emoji: '🦪',
        descripcion: 'Carbonato cálcico biogénico degradable en compostaje.'
      }
    ]
  },

  // NIVEL 10: EL DESAFÍO DEFINITIVO (Leyenda)
  {
    levelNumber: 10,
    title: 'Nivel 10: Desafío Legendario',
    subtitle: 'El Examen Definitivo del Reciclaje AR',
    difficulty: 'Leyenda',
    description: 'Los 10 residuos más complejos y debatidos del mundo. ¡Demuestra tu maestría!',
    items: [
      {
        id: 91,
        nombre: 'Cristal de ventana roto',
        categoria: 'gris',
        emoji: '🪟',
        descripcion: 'Vidrio plano sódico-cálcico que contamina los hornos de vidrio hueco.'
      },
      {
        id: 92,
        nombre: 'Bandeja de poliestireno expandido limpio',
        categoria: 'azul',
        emoji: '📦',
        descripcion: 'Porexpán EPS limpio 100% termoplástico reciclable.'
      },
      {
        id: 93,
        nombre: 'Caja de hamburguesa con salsa impregnada',
        categoria: 'gris',
        emoji: '🍔',
        descripcion: 'Cartón empapado en mayonesa y grasa irrecuperable.'
      },
      {
        id: 94,
        nombre: 'Pila de botón de óxido de plata',
        categoria: 'rojo',
        emoji: '⌚',
        descripcion: 'Metal pesado sumamente tóxico para acuíferos subterráneos.'
      },
      {
        id: 95,
        nombre: 'Esponja de lavar platos desgastada',
        categoria: 'gris',
        emoji: '🧽',
        descripcion: 'Poliuretano sintético lleno de bacterias y microplásticos.'
      },
      {
        id: 96,
        nombre: 'Espinas de pescado y poda de rosas',
        categoria: 'verde',
        emoji: '🌹',
        descripcion: 'Materia orgánica biodegradable rica en minerales.'
      },
      {
        id: 97,
        nombre: 'Botella de amoníaco con triple lavado',
        categoria: 'azul',
        emoji: '🧴',
        descripcion: 'Envase de plástico PEAD neutralizado y apto para triturado.'
      },
      {
        id: 98,
        nombre: 'Jeringa sin aguja de uso doméstico',
        categoria: 'rojo',
        emoji: '💉',
        descripcion: 'Instrumental médico contaminado que exige disposición hospitalaria.'
      },
      {
        id: 99,
        nombre: 'Saquito de manzanilla con hilo de algodón',
        categoria: 'verde',
        emoji: '🌼',
        descripcion: 'Fibras naturales y flores 100% compostables en la tierra.'
      },
      {
        id: 100,
        nombre: 'Bote de acetona pura vaciado',
        categoria: 'rojo',
        emoji: '🧪',
        descripcion: 'Residuo químico volátil con vapores inflamables y cancerígenos.'
      }
    ]
  }
];

// Fallback legacy export
export const RESIDUOS: WasteItem[] = NIVELES_JUEGO[0].items;

/**
 * 60 RESIDUOS EXTENDIDOS ADICIONALES (IDs 101 a 160)
 * Amplían la base a 160 residuos reales con rigor pedagógico y didáctico
 */
export const RESIDUOS_EXTENDIDOS: WasteItem[] = [
  // 101 a 115
  {
    id: 101,
    nombre: 'Brik de leche enjuagado',
    categoria: 'azul',
    emoji: '🥛',
    descripcion: 'Envase multicapa tipo Tetra Pak 100% reciclable en el contenedor de envases.'
  },
  {
    id: 102,
    nombre: 'Hueso de aguacate / palta',
    categoria: 'verde',
    emoji: '🥑',
    descripcion: 'Semilla leñosa biodegradable que aporta minerales valiosos al compost.'
  },
  {
    id: 103,
    nombre: 'Chicle masticado en papel',
    categoria: 'gris',
    emoji: '🍬',
    descripcion: 'Polímero sintético elástico no biodegradable ni reciclable, va a resto.'
  },
  {
    id: 104,
    nombre: 'Botella de lejía vacía',
    categoria: 'azul',
    emoji: '🧴',
    descripcion: 'Plástico PEAD rígido apto para reciclaje una vez escurrido y vacío.'
  },
  {
    id: 105,
    nombre: 'Termómetro digital roto',
    categoria: 'rojo',
    emoji: '🌡️',
    descripcion: 'Aparato electrónico RAEE con microchip y batería de litio peligrosa.'
  },
  {
    id: 106,
    nombre: 'Corcho sintético de vino',
    categoria: 'gris',
    emoji: '🍾',
    descripcion: 'Plástico elastómero que no tiene línea de reciclaje de envases.'
  },
  {
    id: 107,
    nombre: 'Lata de conservas aplastada',
    categoria: 'azul',
    emoji: '🥫',
    descripcion: 'Hojalata de acero infinitamente reciclable en acerías de fundición.'
  },
  {
    id: 108,
    nombre: 'Cáscaras de huevo trituradas',
    categoria: 'verde',
    emoji: '🥚',
    descripcion: 'Carbonato de calcio natural que nutre la tierra en el compostaje.'
  },
  {
    id: 109,
    nombre: 'Guantes de látex usados',
    categoria: 'gris',
    emoji: '🧤',
    descripcion: 'Material contaminado con suciedad doméstica que va al vertedero.'
  },
  {
    id: 110,
    nombre: 'Batería de laptop hinchada',
    categoria: 'rojo',
    emoji: '💻',
    descripcion: 'Peligro inminente de explosión e incendio químico por litio presurizado.'
  },
  {
    id: 111,
    nombre: 'Tarro de yogur de cristal',
    categoria: 'azul',
    emoji: '🍶',
    descripcion: 'Vidrio limpio reutilizable y reciclable al 100% sin pérdida de pureza.'
  },
  {
    id: 112,
    nombre: 'Filtro con hojas de té húmedas',
    categoria: 'verde',
    emoji: '🍵',
    descripcion: 'Hierbas aromáticas y celulosa natural biodegradables para compost.'
  },
  {
    id: 113,
    nombre: 'Taza de porcelana rota',
    categoria: 'gris',
    emoji: '☕',
    descripcion: 'Cerámica silícea con temperatura de fusión distinta al vidrio común.'
  },
  {
    id: 114,
    nombre: 'Mechero de gas sin carga',
    categoria: 'gris',
    emoji: '🔥',
    descripcion: 'Objeto mixto de plástico, resorte de acero y piedra no reciclable.'
  },
  {
    id: 115,
    nombre: 'Spray de pintura en aerosol',
    categoria: 'rojo',
    emoji: '🎨',
    descripcion: 'Bote bajo presión con vapores volátiles y solventes químicos tóxicos.'
  },

  // 116 a 130
  {
    id: 116,
    nombre: 'Tapón de corcho 100% natural',
    categoria: 'verde',
    emoji: '🪵',
    descripcion: 'Corteza vegetal natural de alcornoque totalmente biodegradable.'
  },
  {
    id: 117,
    nombre: 'Huevera de cartón limpia',
    categoria: 'azul',
    emoji: '📦',
    descripcion: 'Pasta de celulosa moldeada de alta calidad para reciclaje de papel.'
  },
  {
    id: 118,
    nombre: 'Posos de café de cafetera',
    categoria: 'verde',
    emoji: '☕',
    descripcion: 'Residuo orgánico rico en nitrógeno, fósforo y potasio para plantas.'
  },
  {
    id: 119,
    nombre: 'Espejo de bolsillo roto',
    categoria: 'gris',
    emoji: '🪞',
    descripcion: 'Cristal con recubrimiento reflectante de plata incompatible con envases.'
  },
  {
    id: 120,
    nombre: 'Frasco con jarabe caducado',
    categoria: 'rojo',
    emoji: '💊',
    descripcion: 'Medicamento tóxico para ríos y acuíferos; requiere punto SIGRE / especial.'
  },
  {
    id: 121,
    nombre: 'Teclado de PC descompuesto',
    categoria: 'rojo',
    emoji: '⌨️',
    descripcion: 'Chatarra electrónica con circuitos de cobre y retardantes de llama.'
  },
  {
    id: 122,
    nombre: 'Cáscaras de gambas y marisco',
    categoria: 'verde',
    emoji: '🦐',
    descripcion: 'Materia biológica marina rica en quitina que enriquece el compost.'
  },
  {
    id: 123,
    nombre: 'Sobre con ventana plástica',
    categoria: 'azul',
    emoji: '✉️',
    descripcion: 'Papel reciclable; la película fina de polietileno se separa en planta.'
  },
  {
    id: 124,
    nombre: 'Pañuelo con mucosidad',
    categoria: 'gris',
    emoji: '🤧',
    descripcion: 'Desecho sanitario personal no reciclable que debe ir a contenedor de restos.'
  },
  {
    id: 125,
    nombre: 'Bote de barniz con restos',
    categoria: 'rojo',
    emoji: '🖌️',
    descripcion: 'Compuesto químico corrosivo y nocivo para el medio ambiente.'
  },
  {
    id: 126,
    nombre: 'Botella de aceite de cocina usado',
    categoria: 'rojo',
    emoji: '🛢️',
    descripcion: 'Un solo litro de aceite doméstico puede contaminar mil litros de agua.'
  },
  {
    id: 127,
    nombre: 'Tubo fluorescente fundido',
    categoria: 'rojo',
    emoji: '💡',
    descripcion: 'Contiene polvo de fósforo y vapor de mercurio altamente neurotóxico.'
  },
  {
    id: 128,
    nombre: 'Envoltorio de chocolatina',
    categoria: 'gris',
    emoji: '🍫',
    descripcion: 'Plástico metalizado termosellado no aprovechable en líneas estándar.'
  },
  {
    id: 129,
    nombre: 'Caja de cereales plegada',
    categoria: 'azul',
    emoji: '🥣',
    descripcion: 'Cartón fino de fibra virgen y reciclada idóneo para hacer nuevo papel.'
  },
  {
    id: 130,
    nombre: 'Servilleta limpia sin usar',
    categoria: 'azul',
    emoji: '📄',
    descripcion: 'Celulosa seca sin restos de grasa ni suciedad orgánica, apta para reciclaje.'
  },

  // 131 a 145
  {
    id: 131,
    nombre: 'Poda de césped y hierba',
    categoria: 'verde',
    emoji: '🌱',
    descripcion: 'Restos verdes de jardín con alta humedad que aceleran la descomposición.'
  },
  {
    id: 132,
    nombre: 'Cepillo eléctrico roto',
    categoria: 'rojo',
    emoji: '⚡',
    descripcion: 'Aparato electrónico con batería recargable sellada y motor de cobre.'
  },
  {
    id: 133,
    nombre: 'Vaso encerado de café',
    categoria: 'gris',
    emoji: '🥤',
    descripcion: 'Vaso de papel laminado con plástico interior impermeable no reciclable.'
  },
  {
    id: 134,
    nombre: 'Hojas secas de otoño',
    categoria: 'verde',
    emoji: '🍂',
    descripcion: 'Materia marrón rica en carbono indispensable para un compost equilibrado.'
  },
  {
    id: 135,
    nombre: 'Cartucho de tóner de tinta',
    categoria: 'rojo',
    emoji: '🖨️',
    descripcion: 'Polvo microparticulado tóxico por inhalación y contaminante hídrico.'
  },
  {
    id: 136,
    nombre: 'Folios impresos a dos caras',
    categoria: 'azul',
    emoji: '📑',
    descripcion: 'Papel de fotocopia limpio procesable en pasta de papel reciclado.'
  },
  {
    id: 137,
    nombre: 'Goma elástica estirada',
    categoria: 'gris',
    emoji: '➰',
    descripcion: 'Caucho vulcanizado sintético que no se funde ni recicla en envases.'
  },
  {
    id: 138,
    nombre: 'Cáscaras de nueces y pistachos',
    categoria: 'verde',
    emoji: '🥜',
    descripcion: 'Estructura vegetal dura biodegradable que airea el montón de compost.'
  },
  {
    id: 139,
    nombre: 'Bolsa de plástico limpia',
    categoria: 'azul',
    emoji: '🛍️',
    descripcion: 'Polietileno de baja densidad (PEBD) reciclable para nuevas bolsas o tuberías.'
  },
  {
    id: 140,
    nombre: 'Trozos de cinta aislante',
    categoria: 'gris',
    emoji: '🩹',
    descripcion: 'Plástico PVC adhesivo con pegamentos que contaminan la pulpa de reciclado.'
  },
  {
    id: 141,
    nombre: 'Bote desodorante de aluminio',
    categoria: 'azul',
    emoji: '🧴',
    descripcion: 'Metal ligero 100% aprovechable una vez que el aerosol está vacío.'
  },
  {
    id: 142,
    nombre: 'Tiritas y apósitos usados',
    categoria: 'gris',
    emoji: '🩹',
    descripcion: 'Residuo sanitario doméstico no reciclable para vertedero controlado.'
  },
  {
    id: 143,
    nombre: 'Blíster plástico de bombones',
    categoria: 'azul',
    emoji: '🍬',
    descripcion: 'Termoplástico rígido PET limpio listo para reciclaje en envases.'
  },
  {
    id: 144,
    nombre: 'Pañal sucio de bebé',
    categoria: 'gris',
    emoji: '👶',
    descripcion: 'Material absorbente polimérico impregnado de heces, va a contenedor gris.'
  },
  {
    id: 145,
    nombre: 'Restos de pan duro y migas',
    categoria: 'verde',
    emoji: '🥖',
    descripcion: 'Cereales fermentables biodegradables perfectos para abono natural.'
  },

  // 146 a 160
  {
    id: 146,
    nombre: 'Algodón desmaquillante usado',
    categoria: 'gris',
    emoji: '💄',
    descripcion: 'Disco de algodón impregnado con químicos sintéticos y maquillaje.'
  },
  {
    id: 147,
    nombre: 'Frasco de perfume de cristal',
    categoria: 'azul',
    emoji: '✨',
    descripcion: 'Vidrio de alta densidad sin válvula que se recicla en nuevos envases.'
  },
  {
    id: 148,
    nombre: 'Cuchilla de bisturí médica',
    categoria: 'rojo',
    emoji: '🔪',
    descripcion: 'Objeto cortante biosanitario con riesgo biológico de transmisión patógena.'
  },
  {
    id: 149,
    nombre: 'Tarjeta de plástico caducada',
    categoria: 'gris',
    emoji: '💳',
    descripcion: 'Policloruro de vinilo (PVC) laminado con banda magnética no reciclable.'
  },
  {
    id: 150,
    nombre: 'Papel de regalo metalizado',
    categoria: 'gris',
    emoji: '🎁',
    descripcion: 'Película de polipropileno brillante irrecuperable en plantas de celulosa.'
  },
  {
    id: 151,
    nombre: 'Peladuras de patata y tubérculos',
    categoria: 'verde',
    emoji: '🥔',
    descripcion: 'Restos vegetales ricos en almidón que se descomponen con rapidez.'
  },
  {
    id: 152,
    nombre: 'Lata de atún limpia',
    categoria: 'azul',
    emoji: '🐟',
    descripcion: 'Metal de hojalata sin grasa residual, fundible al 100% para nueva chapa.'
  },
  {
    id: 153,
    nombre: 'Trapo con gasolina y grasa',
    categoria: 'rojo',
    emoji: '⛽',
    descripcion: 'Textil impregnado con hidrocarburos inflamables altamente tóxicos.'
  },
  {
    id: 154,
    nombre: 'Bote de salsa plástico vacío',
    categoria: 'azul',
    emoji: '🍅',
    descripcion: 'Polipropileno o PEAD enjuagado apto para reprocesado mecánico.'
  },
  {
    id: 155,
    nombre: 'Hisopo con varilla plástica',
    categoria: 'gris',
    emoji: '👂',
    descripcion: 'Microplástico que no se debe tirar al inodoro ni al reciclaje común.'
  },
  {
    id: 156,
    nombre: 'Huesos de carne cocida',
    categoria: 'verde',
    emoji: '🍖',
    descripcion: 'Restos animales de comida que se transforman en abono en composteras.'
  },
  {
    id: 157,
    nombre: 'Tubo de pasta dental aplastado',
    categoria: 'gris',
    emoji: '🪥',
    descripcion: 'Laminado multicapa con película interna de aluminio inseparable.'
  },
  {
    id: 158,
    nombre: 'Pila AAA agotada',
    categoria: 'rojo',
    emoji: '🔋',
    descripcion: 'Residuo peligroso doméstico con electrolito químico corrosivo.'
  },
  {
    id: 159,
    nombre: 'Folleto de revista satinada',
    categoria: 'azul',
    emoji: '📖',
    descripcion: 'Papel satinado con tinta no grasa procesable en fábricas de reciclaje.'
  },
  {
    id: 160,
    nombre: 'Maceta de barro cocido rota',
    categoria: 'gris',
    emoji: '🪴',
    descripcion: 'Cerámica cocida porosa que debe gestionarse como escombros o resto.'
  }
];

/**
 * CATÁLOGO GLOBAL COMPLETO DE 160 RESIDUOS
 * Reúne los 100 residuos de los 10 niveles y los 60 residuos extendidos.
 */
export const TODOS_LOS_RESIDUOS: WasteItem[] = [
  ...NIVELES_JUEGO.flatMap((lvl) => lvl.items),
  ...RESIDUOS_EXTENDIDOS
];

/**
 * Fisher-Yates shuffle optimizado para crear un mazo aleatorio sin sesgos
 */
export function shuffleItems(items: WasteItem[]): WasteItem[] {
  const deck = [...items];
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const temp = deck[i];
    deck[i] = deck[j];
    deck[j] = temp;
  }
  return deck;
}

/**
 * Generador optimizado de baraja para Modo Infinito
 * Garantiza rotación continua de los 160 objetos sin repeticiones inmediatas
 */
export function createInfiniteDeck(): WasteItem[] {
  return shuffleItems(TODOS_LOS_RESIDUOS);
}

