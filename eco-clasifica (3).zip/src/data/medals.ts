import { Medal, UserStats } from '../types';

export const ALL_MEDALS: Medal[] = [
  {
    id: 'first_correct',
    title: 'Primer Acierto',
    subtitle: '¡Primer paso ecológico!',
    description: 'Deposita con éxito tu primer residuo en el contenedor correspondiente.',
    icon: '🌱',
    tier: 'bronze',
    tierLabel: 'Bronce',
    accentColor: '#ca8a04',
    borderColor: '#eab308',
    bgGradient: 'from-amber-950/80 via-yellow-900/60 to-amber-950/90',
    targetValue: 1,
    statKey: 'totalCorrect',
    unit: 'residuo',
    category: 'hito'
  },
  {
    id: 'correct_25',
    title: 'Reciclador Activo',
    subtitle: '¡25 residuos clasificados!',
    description: 'Alcanza un total acumulado de 25 residuos depositados correctamente.',
    icon: '🌿',
    tier: 'bronze',
    tierLabel: 'Bronce',
    accentColor: '#10b981',
    borderColor: '#34d399',
    bgGradient: 'from-emerald-950/80 via-teal-900/60 to-emerald-950/90',
    targetValue: 25,
    statKey: 'totalCorrect',
    unit: 'residuos',
    category: 'hito'
  },
  {
    id: 'correct_50',
    title: '50 Residuos Clasificados',
    subtitle: '¡Hito de 50 residuos logrados!',
    description: 'Clasifica con éxito 50 residuos en sus contenedores correspondientes.',
    icon: '♻️',
    tier: 'silver',
    tierLabel: 'Plata',
    accentColor: '#0ea5e9',
    borderColor: '#38bdf8',
    bgGradient: 'from-sky-950/90 via-blue-900/70 to-indigo-950/90',
    targetValue: 50,
    statKey: 'totalCorrect',
    unit: 'residuos',
    category: 'hito'
  },
  {
    id: 'correct_100',
    title: 'Centenario del Reciclaje',
    subtitle: '¡100 residuos salvados!',
    description: 'Clasifica 100 residuos correctamente demostrando un compromiso ambiental ejemplar.',
    icon: '🌍',
    tier: 'gold',
    tierLabel: 'Oro',
    accentColor: '#f59e0b',
    borderColor: '#fbbf24',
    bgGradient: 'from-amber-950/90 via-yellow-900/70 to-amber-950/90',
    targetValue: 100,
    statKey: 'totalCorrect',
    unit: 'residuos',
    category: 'hito'
  },
  {
    id: 'streak_5',
    title: 'Racha Imparable (x5)',
    subtitle: '¡5 aciertos consecutivos!',
    description: 'Consigue una racha de 5 aciertos seguidos sin cometer ningún error.',
    icon: '🔥',
    tier: 'bronze',
    tierLabel: 'Bronce',
    accentColor: '#f97316',
    borderColor: '#fb923c',
    bgGradient: 'from-orange-950/80 via-amber-900/60 to-slate-900',
    targetValue: 5,
    statKey: 'bestStreak',
    unit: 'aciertos',
    category: 'racha'
  },
  {
    id: 'perfect_streak',
    title: 'Racha Perfecta (x10)',
    subtitle: '¡10 aciertos sin fallar!',
    description: 'Encadena una racha perfecta de 10 aciertos seguidos sin cometer ningún fallo.',
    icon: '⚡',
    tier: 'gold',
    tierLabel: 'Oro',
    accentColor: '#eab308',
    borderColor: '#fde047',
    bgGradient: 'from-yellow-950/90 via-amber-900/80 to-yellow-950/90',
    targetValue: 10,
    statKey: 'bestStreak',
    unit: 'aciertos',
    category: 'racha'
  },
  {
    id: 'streak_15',
    title: 'Concentración Zen (x15)',
    subtitle: '¡15 aciertos impecables!',
    description: 'Alcanza una legendaria racha de 15 aciertos continuos en alta concentración.',
    icon: '✨',
    tier: 'diamond',
    tierLabel: 'Diamante',
    accentColor: '#38bdf8',
    borderColor: '#e0f2fe',
    bgGradient: 'from-cyan-950 via-sky-900 to-indigo-950',
    targetValue: 15,
    statKey: 'bestStreak',
    unit: 'aciertos',
    category: 'racha'
  },
  {
    id: 'level_cleared',
    title: 'Nivel Superado',
    subtitle: '¡Misión completada!',
    description: 'Supera satisfactoriamente cualquiera de los niveles de reciclaje.',
    icon: '🏆',
    tier: 'bronze',
    tierLabel: 'Bronce',
    accentColor: '#10b981',
    borderColor: '#34d399',
    bgGradient: 'from-emerald-950 via-teal-950 to-slate-900',
    targetValue: 1,
    statKey: 'totalLevelsCleared',
    unit: 'nivel',
    category: 'maestria'
  },
  {
    id: 'clean_sheet',
    title: 'Nivel Impecable',
    subtitle: '¡0 fallos y 3 vidas intactas!',
    description: 'Completa un nivel entero con tus 3 vidas intactas y cero errores cometidos.',
    icon: '🛡️',
    tier: 'gold',
    tierLabel: 'Oro',
    accentColor: '#f59e0b',
    borderColor: '#fbbf24',
    bgGradient: 'from-amber-950 via-yellow-900 to-slate-900',
    targetValue: 1,
    statKey: 'cleanSheetLevels',
    unit: 'nivel',
    category: 'maestria'
  },
  {
    id: 'toxic_expert',
    title: 'Guardián Tóxico',
    subtitle: '¡Peligro neutralizado!',
    description: 'Clasifica con éxito un residuo biológico o peligroso en el contenedor Rojo.',
    icon: '☣️',
    tier: 'silver',
    tierLabel: 'Plata',
    accentColor: '#f43f5e',
    borderColor: '#fb7185',
    bgGradient: 'from-rose-950 via-red-950 to-slate-900',
    targetValue: 1,
    statKey: 'toxicWasteSorted',
    unit: 'residuo',
    category: 'especial'
  },
  {
    id: 'speed_sorter',
    title: 'Reflejo Instantáneo',
    subtitle: '¡Clasificación relámpago!',
    description: 'Deposita un residuo en su contenedor en menos de 3.5 segundos tras aparecer.',
    icon: '⏱️',
    tier: 'silver',
    tierLabel: 'Plata',
    accentColor: '#a855f7',
    borderColor: '#c084fc',
    bgGradient: 'from-purple-950 via-indigo-950 to-slate-900',
    targetValue: 1,
    unit: 'segundos',
    category: 'especial'
  },
  {
    id: 'eco_legend',
    title: 'Héroe del Planeta',
    subtitle: '¡10 niveles completados!',
    description: 'Supera los 10 niveles y demuestra ser el máximo maestro del reciclaje.',
    icon: '👑',
    tier: 'diamond',
    tierLabel: 'Diamante',
    accentColor: '#38bdf8',
    borderColor: '#e0f2fe',
    bgGradient: 'from-cyan-950 via-blue-900 to-indigo-950',
    targetValue: 10,
    statKey: 'totalLevelsCleared',
    unit: 'niveles',
    category: 'maestria'
  }
];

const STATS_STORAGE_KEY = 'eco_clasifica_user_stats_v2';
const LEGACY_STORAGE_KEY = 'eco_clasifica_medals_v1';

export const INITIAL_USER_STATS: UserStats = {
  totalCorrect: 0,
  bestStreak: 0,
  currentStreak: 0,
  totalGames: 0,
  totalLevelsCleared: 0,
  cleanSheetLevels: 0,
  toxicWasteSorted: 0,
  fastestSortSeconds: 999,
  totalScore: 0,
  unlockedMedalIds: [],
  unlockedDates: {},
  bestInfiniteScore: 0,
  bestInfiniteStreak: 0,
  totalInfiniteSorted: 0
};

/**
 * Retrieve persistent user stats with backward-compatibility migration
 */
export function getUserStats(): UserStats {
  try {
    const raw = localStorage.getItem(STATS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        ...INITIAL_USER_STATS,
        ...parsed,
        unlockedMedalIds: Array.isArray(parsed.unlockedMedalIds) ? parsed.unlockedMedalIds : [],
        unlockedDates: typeof parsed.unlockedDates === 'object' && parsed.unlockedDates !== null ? parsed.unlockedDates : {}
      };
    }

    // Check legacy storage migration
    const legacyRaw = localStorage.getItem(LEGACY_STORAGE_KEY);
    if (legacyRaw) {
      const legacyIds = JSON.parse(legacyRaw);
      if (Array.isArray(legacyIds) && legacyIds.length > 0) {
        const migrated: UserStats = {
          ...INITIAL_USER_STATS,
          totalCorrect: legacyIds.length * 5,
          bestStreak: legacyIds.includes('streak_10') ? 10 : legacyIds.includes('streak_5') ? 5 : 1,
          unlockedMedalIds: legacyIds,
          unlockedDates: legacyIds.reduce((acc, id) => {
            acc[id] = new Date().toISOString();
            return acc;
          }, {} as Record<string, string>)
        };
        saveUserStats(migrated);
        return migrated;
      }
    }

    return { ...INITIAL_USER_STATS };
  } catch {
    return { ...INITIAL_USER_STATS };
  }
}

/**
 * Persist user statistics locally
 */
export function saveUserStats(stats: UserStats): void {
  try {
    localStorage.setItem(STATS_STORAGE_KEY, JSON.stringify(stats));
    // Also sync legacy key for backwards compatibility
    localStorage.setItem(LEGACY_STORAGE_KEY, JSON.stringify(stats.unlockedMedalIds));
  } catch {
    // LocalStorage quota or private mode fallback
  }
}

/**
 * Convenience method for legacy components
 */
export function getStoredUnlockedMedalIds(): string[] {
  return getUserStats().unlockedMedalIds;
}

/**
 * Convenience save for legacy single-id calls
 */
export function saveUnlockedMedalId(id: string): string[] {
  const stats = getUserStats();
  if (!stats.unlockedMedalIds.includes(id)) {
    stats.unlockedMedalIds.push(id);
    stats.unlockedDates[id] = new Date().toISOString();
    saveUserStats(stats);
  }
  return stats.unlockedMedalIds;
}

/**
 * Evaluate all medal conditions against current stats and return any newly unlocked medals
 */
export function evaluateMedals(stats: UserStats): { newlyUnlocked: Medal[]; stats: UserStats } {
  const newlyUnlocked: Medal[] = [];
  const updatedUnlockedIds = [...stats.unlockedMedalIds];
  const updatedDates = { ...stats.unlockedDates };

  for (const medal of ALL_MEDALS) {
    if (updatedUnlockedIds.includes(medal.id)) {
      continue;
    }

    let isEarned = false;

    switch (medal.id) {
      case 'first_correct':
        isEarned = stats.totalCorrect >= 1;
        break;
      case 'correct_25':
        isEarned = stats.totalCorrect >= 25;
        break;
      case 'correct_50':
        isEarned = stats.totalCorrect >= 50;
        break;
      case 'correct_100':
        isEarned = stats.totalCorrect >= 100;
        break;
      case 'streak_5':
        isEarned = stats.bestStreak >= 5;
        break;
      case 'perfect_streak':
        isEarned = stats.bestStreak >= 10;
        break;
      case 'streak_15':
        isEarned = stats.bestStreak >= 15;
        break;
      case 'level_cleared':
        isEarned = stats.totalLevelsCleared >= 1;
        break;
      case 'clean_sheet':
        isEarned = stats.cleanSheetLevels >= 1;
        break;
      case 'toxic_expert':
        isEarned = stats.toxicWasteSorted >= 1;
        break;
      case 'speed_sorter':
        isEarned = stats.fastestSortSeconds <= 3.5;
        break;
      case 'eco_legend':
        isEarned = stats.totalLevelsCleared >= 10;
        break;
      default:
        if (medal.statKey && medal.targetValue !== undefined) {
          const val = stats[medal.statKey];
          if (typeof val === 'number') {
            isEarned = val >= medal.targetValue;
          }
        }
    }

    if (isEarned) {
      updatedUnlockedIds.push(medal.id);
      updatedDates[medal.id] = new Date().toISOString();
      newlyUnlocked.push({
        ...medal,
        unlockedAt: updatedDates[medal.id]
      });
    }
  }

  const updatedStats: UserStats = {
    ...stats,
    unlockedMedalIds: updatedUnlockedIds,
    unlockedDates: updatedDates
  };

  if (newlyUnlocked.length > 0) {
    saveUserStats(updatedStats);
  }

  return { newlyUnlocked, stats: updatedStats };
}

/**
 * Record a classified item and check for unlocks (e.g. 50 items, streaks, speed, toxic)
 */
export function recordItemClassified(
  isCorrect: boolean,
  elapsedSeconds: number,
  isToxic: boolean,
  points: number = 10
): { newlyUnlocked: Medal[]; stats: UserStats } {
  const current = getUserStats();

  if (isCorrect) {
    const newStreak = current.currentStreak + 1;
    const newBestStreak = Math.max(current.bestStreak, newStreak);
    const newToxic = isToxic ? current.toxicWasteSorted + 1 : current.toxicWasteSorted;
    const newFastest = Math.min(current.fastestSortSeconds, elapsedSeconds);

    const nextStats: UserStats = {
      ...current,
      totalCorrect: current.totalCorrect + 1,
      currentStreak: newStreak,
      bestStreak: newBestStreak,
      toxicWasteSorted: newToxic,
      fastestSortSeconds: newFastest,
      totalScore: current.totalScore + points
    };

    saveUserStats(nextStats);
    return evaluateMedals(nextStats);
  } else {
    // Error breaks current streak
    const nextStats: UserStats = {
      ...current,
      currentStreak: 0
    };
    saveUserStats(nextStats);
    return { newlyUnlocked: [], stats: nextStats };
  }
}

/**
 * Record a level completion or clean sheet
 */
export function recordLevelResult(
  levelCleared: boolean,
  livesRemaining: number,
  errors: number,
  isGameComplete: boolean
): { newlyUnlocked: Medal[]; stats: UserStats } {
  const current = getUserStats();

  if (!levelCleared) {
    return { newlyUnlocked: [], stats: current };
  }

  const isCleanSheet = errors === 0 && livesRemaining === 3;

  const nextStats: UserStats = {
    ...current,
    totalLevelsCleared: current.totalLevelsCleared + 1,
    cleanSheetLevels: isCleanSheet ? current.cleanSheetLevels + 1 : current.cleanSheetLevels
  };

  saveUserStats(nextStats);
  return evaluateMedals(nextStats);
}

/**
 * Record an Infinite Mode match session and update high score / best streak records
 */
export function recordInfiniteGameResult(
  score: number,
  itemsSorted: number,
  bestStreak: number
): { isNewRecord: boolean; stats: UserStats; newlyUnlocked: Medal[] } {
  const current = getUserStats();
  const prevBest = current.bestInfiniteScore || 0;
  const isNewRecord = score > prevBest;
  const newBestScore = Math.max(prevBest, score);
  const newBestStreak = Math.max(current.bestInfiniteStreak || 0, bestStreak);
  const newTotalSorted = (current.totalInfiniteSorted || 0) + itemsSorted;

  const nextStats: UserStats = {
    ...current,
    totalGames: current.totalGames + 1,
    bestInfiniteScore: newBestScore,
    bestInfiniteStreak: newBestStreak,
    totalInfiniteSorted: newTotalSorted
  };

  saveUserStats(nextStats);
  const evaluated = evaluateMedals(nextStats);
  return {
    isNewRecord,
    stats: evaluated.stats,
    newlyUnlocked: evaluated.newlyUnlocked
  };
}

/**
 * Reset all user stats and medals (for player reset option)
 */
export function resetUserStats(): UserStats {
  try {
    localStorage.removeItem(STATS_STORAGE_KEY);
    localStorage.removeItem(LEGACY_STORAGE_KEY);
  } catch {}
  return { ...INITIAL_USER_STATS };
}
