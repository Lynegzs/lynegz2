import React, { useState, useRef, useEffect, useCallback } from 'react';
import { GameState, GameMode, RoundResult } from './types';
import { HandTracker } from './utils/handTracker';
import { sound } from './utils/audio';
import { bgm } from './utils/bgm';
import { MenuScreen } from './components/MenuScreen';
import { CameraPermissionModal } from './components/CameraPermissionModal';
import { CalibrationScreen } from './components/CalibrationScreen';
import { GameArea } from './components/GameArea';
import { GameOverModal } from './components/GameOverModal';

export default function App() {
  // State Machine conforming to Section 35
  const [gameState, setGameState] = useState<GameState>('MENU');
  const [gameMode, setGameMode] = useState<GameMode>('levels');

  // Camera orientation (front vs rear camera for smartphones and tablets)
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');

  // Camera & Tracking states
  const [isCameraLoading, setIsCameraLoading] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);

  // Batched hand tracking state for high-performance 60fps rendering
  const [handData, setHandData] = useState<{
    detected: boolean;
    normX: number;
    normY: number;
    isPinching: boolean;
    pinchDistance: number;
  }>({
    detected: false,
    normX: 0.5,
    normY: 0.5,
    isPinching: false,
    pinchDistance: 0.2
  });

  const pendingHandDataRef = useRef<any>(null);
  const handRafIdRef = useRef<number | null>(null);

  // Sound settings
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  // Game metrics for final summary
  const [finalScore, setFinalScore] = useState<number>(0);
  const [finalErrors, setFinalErrors] = useState<number>(0);
  const [finalHistory, setFinalHistory] = useState<RoundResult[]>([]);

  // Persistent Media References
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const trackerRef = useRef<HandTracker | null>(null);
  const targetStateAfterCamera = useRef<'JUGANDO' | 'CALIBRACION'>('JUGANDO');

  // Toggle sound
  const handleToggleSound = useCallback(() => {
    setSoundEnabled((prev) => {
      const next = !prev;
      sound.enabled = next;
      return next;
    });
  }, []);

  // Initialize Camera and HandTracker with optimized RAF batching
  const initCameraAndTracker = async () => {
    setIsCameraLoading(true);
    setCameraError(null);

    try {
      if (!trackerRef.current) {
        trackerRef.current = new HandTracker();
      }

      if (!videoRef.current) {
        throw new Error('Elemento de video no disponible.');
      }

      await trackerRef.current.initialize(videoRef.current, canvasRef.current, {
        onHandUpdate: (data) => {
          pendingHandDataRef.current = data;
          if (handRafIdRef.current === null) {
            handRafIdRef.current = requestAnimationFrame(() => {
              handRafIdRef.current = null;
              const cur = pendingHandDataRef.current;
              if (cur) {
                setHandData({
                  detected: cur.detected,
                  normX: cur.normX,
                  normY: cur.normY,
                  isPinching: cur.isPinching,
                  pinchDistance: cur.pinchDistance
                });
              }
            });
          }
        },
        onError: (err) => {
          console.error('Hand tracker error:', err);
          setCameraError(err.message || 'Error al procesar el seguimiento de mano.');
        }
      });

      setIsCameraLoading(false);
      // Start game directly without requiring calibration
      setGameState(targetStateAfterCamera.current);
    } catch (err: any) {
      console.error('Camera initialization failed:', err);
      setIsCameraLoading(false);
      setCameraError(
        err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError'
          ? 'No se concedieron permisos de cámara. Por favor autoriza el acceso a la cámara web para jugar.'
          : err.message || 'No fue posible acceder a la cámara web.'
      );
    }
  };

  // Synchronize active canvas with tracker across screen transitions
  useEffect(() => {
    if (trackerRef.current) {
      trackerRef.current.setCanvas(canvasRef.current);
      if (gameState === 'CALIBRACION' || gameState === 'JUGANDO') {
        trackerRef.current.resume();
      } else {
        trackerRef.current.pause();
      }
    }
  }, [gameState]);

  // Start Camera AR flow directly to game with mode selection
  const handleStartGame = (mode?: GameMode) => {
    const selectedMode = mode || gameMode;
    if (mode) {
      setGameMode(mode);
    }
    if (selectedMode === 'infinite') {
      bgm.startInfiniteModeShuffle();
    } else {
      bgm.playTrackForLevel(1);
    }
    targetStateAfterCamera.current = 'JUGANDO';
    setGameState('CAMARA');
    initCameraAndTracker();
  };

  // Optional calibration from menu
  const handleStartCalibration = () => {
    targetStateAfterCamera.current = 'CALIBRACION';
    setGameState('CAMARA');
    initCameraAndTracker();
  };

  // Switch camera (front / rear) on mobile or multi-camera devices
  const handleSwitchCamera = async () => {
    if (trackerRef.current) {
      try {
        const newMode = await trackerRef.current.switchCamera();
        setFacingMode(newMode);
      } catch (err) {
        console.error('Error switching camera:', err);
      }
    }
  };

  // When calibration is satisfied
  const handleFinishCalibration = () => {
    sound.playCorrect();
    if (gameMode === 'infinite') {
      bgm.startInfiniteModeShuffle();
    } else {
      bgm.playTrackForLevel(1);
    }
    setGameState('JUGANDO');
  };

  // When game completes 10 rounds
  const handleGameOver = (score: number, errors: number, history: RoundResult[]) => {
    setFinalScore(score);
    setFinalErrors(errors);
    setFinalHistory(history);
    setGameState('FINAL');
  };

  // Restart match from beginning
  const handleRestartMatch = () => {
    setFinalScore(0);
    setFinalErrors(0);
    setFinalHistory([]);
    if (gameMode === 'infinite') {
      bgm.startInfiniteModeShuffle();
    } else {
      bgm.playTrackForLevel(1);
    }
    setGameState('JUGANDO');
  };

  // Return to main menu
  const handleReturnToMenu = () => {
    setGameState('MENU');
    setCameraError(null);
  };

  // Recalibrate trigger during game
  const handleReCalibrate = () => {
    setGameState('CALIBRACION');
  };

  // Cleanup camera stream and RAF when unmounting
  useEffect(() => {
    return () => {
      if (handRafIdRef.current !== null) {
        cancelAnimationFrame(handRafIdRef.current);
      }
      if (trackerRef.current) {
        trackerRef.current.stop();
      }
    };
  }, []);

  return (
    <main className="min-h-screen w-full bg-slate-950 text-slate-100 flex flex-col items-center justify-center relative overflow-hidden select-none">
      {/* Background layer: Real-time AR video and tracking canvas */}
      <div
        className={`fixed inset-0 w-full h-full z-0 transition-opacity duration-300 overflow-hidden ${
          gameState === 'JUGANDO'
            ? 'opacity-100 pointer-events-auto'
            : 'opacity-0 pointer-events-none'
        }`}
      >
        <div className="absolute inset-0 bg-slate-950" />

        {/* Video stream for AR */}
        <video
          ref={videoRef}
          playsInline
          muted
          autoPlay
          className={`absolute inset-0 w-full h-full object-cover z-[1] brightness-105 contrast-105 ${
            facingMode === 'user' ? '-scale-x-100' : 'scale-x-100'
          }`}
        />
        <canvas
          ref={canvasRef}
          width={1280}
          height={720}
          className="absolute inset-0 w-full h-full object-cover pointer-events-none z-[2]"
        />
      </div>

      {/* 1. MAIN MENU SCREEN */}
      {gameState === 'MENU' && (
        <MenuScreen
          onStart={handleStartGame}
          onCalibrate={handleStartCalibration}
          soundEnabled={soundEnabled}
          onToggleSound={handleToggleSound}
        />
      )}

      {/* 2. CAMERA PERMISSION & LOADING MODAL */}
      {gameState === 'CAMARA' && (
        <CameraPermissionModal
          isLoading={isCameraLoading}
          hasError={!!cameraError}
          errorMessage={cameraError || undefined}
          onRetry={initCameraAndTracker}
          onBack={handleReturnToMenu}
          videoRef={videoRef}
          onContinueWithoutCamera={() => {
            setIsCameraLoading(false);
            setGameState(targetStateAfterCamera.current);
          }}
        />
      )}

      {/* 3. CALIBRATION SCREEN */}
      {gameState === 'CALIBRACION' && (
        <CalibrationScreen
          handDetected={handData.detected}
          normX={handData.normX}
          normY={handData.normY}
          isPinching={handData.isPinching}
          videoRef={videoRef}
          canvasRef={canvasRef}
          onStartGame={handleFinishCalibration}
          onBackToMenu={handleReturnToMenu}
        />
      )}

      {/* 4. ACTIVE GAMEPLAY (LEVELS & INFINITE MODES) */}
      {gameState === 'JUGANDO' && (
        <GameArea
          handDetected={handData.detected}
          normX={handData.normX}
          normY={handData.normY}
          isPinching={handData.isPinching}
          pinchDistance={handData.pinchDistance}
          videoRef={videoRef}
          canvasRef={canvasRef}
          onGameOver={handleGameOver}
          onExitToMenu={handleReturnToMenu}
          soundEnabled={soundEnabled}
          onToggleSound={handleToggleSound}
          onReCalibrate={handleReCalibrate}
          onSwitchCamera={handleSwitchCamera}
          facingMode={facingMode}
          initialMode={gameMode}
        />
      )}

      {/* 5. GAME OVER SUMMARY MODAL (FOR 10-LEVEL RUN) */}
      {gameState === 'FINAL' && (
        <GameOverModal
          score={finalScore}
          errors={finalErrors}
          totalRounds={10}
          history={finalHistory}
          onRestart={handleRestartMatch}
          onHome={handleReturnToMenu}
        />
      )}
    </main>
  );
}
